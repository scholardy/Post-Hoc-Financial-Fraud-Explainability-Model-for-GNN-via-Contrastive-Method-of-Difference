#!/bin/bash
# Run on Kaggle (2 x T4).  usage:  bash kaggle/run_kaggle.sh pilot|full [hours_budget]
# GPU 0: IEEE-CIS (all stages, incl. sensitivity and scalability); GPU 1: Credit Card, then PaySim.
# Finished targets are skipped on re-run (resumable).
set -u
PROFILE=${1:-pilot}
BUDGET_H=${2:-11}
cd "$(dirname "$0")/.."
DEADLINE=$(( $(date +%s) + ${BUDGET_H%.*} * 3600 ))
mkdir -p logs
echo "== profile=$PROFILE, no new stage after ${BUDGET_H} h"
CUDA_VISIBLE_DEVICES=0 python -u scripts/run_xai.py --profile "$PROFILE" --datasets ieee --deadline $DEADLINE \
    > "logs/${PROFILE}_gpu0_ieee.log" 2>&1 &
CUDA_VISIBLE_DEVICES=1 python -u scripts/run_xai.py --profile "$PROFILE" --datasets creditcard paysim --deadline $DEADLINE \
    > "logs/${PROFILE}_gpu1_cc_paysim.log" 2>&1 &
wait
grep -v -i "warn\|sparse_csr" logs/${PROFILE}_gpu*.log | grep "==\|Error\|error" | tail -40
if [ "$PROFILE" = "pilot" ]; then python -u scripts/estimate_budget.py; fi
echo "== done"
