"""Create ../xai_code_for_kaggle.zip (code, configs, trained GNN checkpoints; no data, no results)."""
import os
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(os.path.dirname(ROOT), "xai_code_for_kaggle.zip")
INCLUDE = ["README.md", "configs", "src", "scripts", "kaggle", "models"]
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for item in INCLUDE:
        p = os.path.join(ROOT, item)
        if os.path.isfile(p):
            z.write(p, os.path.join("xai_experiments", item))
            continue
        for dp, dn, fn in os.walk(p):
            dn[:] = [d for d in dn if d != "__pycache__"]
            for f in fn:
                if f.endswith((".pyc", ".tmp")):
                    continue
                full = os.path.join(dp, f)
                z.write(full, os.path.join("xai_experiments", os.path.relpath(full, ROOT)))
print("wrote", OUT, os.path.getsize(OUT) // 1024, "KB")
