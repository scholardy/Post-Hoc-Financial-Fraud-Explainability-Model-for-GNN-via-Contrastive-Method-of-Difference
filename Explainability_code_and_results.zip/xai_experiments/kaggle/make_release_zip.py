"""Create '../For Tosin - Explainability/Explainability_code_and_results.zip' (code, configs, trained GNN checkpoints,
raw per-transaction results, tables, figures, logs, the original manuscript). Raw datasets are not included."""
import os
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(os.path.dirname(ROOT), "For Tosin - Explainability", "Explainability_code_and_results.zip")
INCLUDE = ["README.md", "configs", "src", "scripts", "kaggle", "models", "results", "tables", "figures", "logs"]
n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for item in INCLUDE:
        p = os.path.join(ROOT, item)
        if os.path.isfile(p):
            z.write(p, os.path.join("xai_experiments", item)); n += 1
            continue
        for dp, dn, fn in os.walk(p):
            dn[:] = [d for d in dn if d != "__pycache__"]
            for f in fn:
                if f.endswith((".pyc", ".tmp")) or "pilot" in f:
                    continue
                full = os.path.join(dp, f)
                z.write(full, os.path.join("xai_experiments", os.path.relpath(full, ROOT))); n += 1
    z.write(os.path.join(ROOT, "paper", "Explainability_manuscript_original.docx"),
            "xai_experiments/paper/Explainability_manuscript_original.docx"); n += 1
print(f"wrote {OUT}: {n} files, {os.path.getsize(OUT) / 2**20:.1f} MB")
