"""Run the explainability experiments for one or more datasets.

python scripts/run_xai.py --profile smoke|pilot|full --datasets ieee [--stages perf main arch ablation sensitivity scalability]
       [--data-profile local]   (local: reuse ../lsgat_experiments/data; Kaggle: default 'full')

Writes one JSON file per (stage, dataset, model, target transaction) under results/<stage>/...
A finished file is skipped when the script is run again (resumable).

Stages
  perf         test-set performance of the explained GNNs (all seeds): ROC-AUC, PR-AUC, F1, precision at 90% recall
  main         all explainers on the main model (GraphSAGE): quality at the default budget, fidelity-sparsity
               curves, feature-level fidelity, run time, peak GPU memory, stability (first n_stability targets)
  arch         all explainers on GCN and GAT (quality at the default budget, run time)
  ablation     variants of the proposed explainer (quality + stability)
  sensitivity  tau, m and k_frac of the proposed explainer (one at a time)
  scalability  run time / memory as the computation subgraph grows (2, 3, 4 hops)
"""
import argparse
import copy
import json
import math
import os
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

import numpy as np  # noqa: E402
import torch  # noqa: E402
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score  # noqa: E402

from lsgat.config import load_config  # noqa: E402
from lsgat.utils import get_device, save_json, set_seed  # noqa: E402
from xai import explainers as X  # noqa: E402
from xai.core import load_setup, make_instance, perturbed  # noqa: E402
from xai.evaluate import quality, stability  # noqa: E402

METHODS = ["ours", "gnnexplainer", "pgexplainer", "subgraphx", "gradcam", "random"]
ABLATIONS = {
    "full": {},
    "no_contrast": {"contrastive": False},
    "unsigned": {"signed": False},
    "no_ensemble": {"m": 1},
    "random_attr": {"mode": "random"},
    "no_budget": {"use_budget": False},
    "no_pruning": {"use_pruning": False},
    "exact": {"mode": "exact"},
}


def _merge(base, over):
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _merge(base[k], v)
        else:
            base[k] = copy.deepcopy(v)
    return base


def load_xai_config(profile):
    with open(os.path.join(ROOT, "configs", "xai.json")) as f:
        c = json.load(f)
    prof = c.pop("profiles")
    if profile != "full":
        _merge(c, prof[profile])
    c["profile"] = profile
    return c


class Meter:
    """Wall time and peak GPU memory above the baseline (MB) of one call."""

    def __init__(self, device):
        self.device = device

    def run(self, fn):
        cuda = self.device.type == "cuda"
        if cuda:
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            base = torch.cuda.memory_allocated()
        t0 = time.perf_counter()
        out = fn()
        if cuda:
            torch.cuda.synchronize()
        dt = time.perf_counter() - t0
        mem = (torch.cuda.max_memory_allocated() - base) / 2 ** 20 if cuda else None
        return out, dt, mem


def target_instances(S, n, min_edges, seed):
    """Correctly detected frauds of the test period (true positives at the validation-tuned threshold), in random
    order. Targets whose computation subgraph has at least `min_edges` edges are taken first; if there are fewer
    than n of them, targets with at least one edge fill the remaining places (PaySim frauds often come from new
    accounts with almost no history)."""
    y = S.g["y"].numpy()
    te = S.g["test_idx"].numpy()
    tp = te[(y[te] == 1) & (S.probs[te] >= S.threshold)]
    order = np.random.default_rng(seed).permutation(tp)
    rich, poor = [], []
    for gid in order:
        inst = make_instance(S, int(gid))
        if inst.e >= min_edges:
            rich.append(inst)
            if len(rich) >= n:
                break
        elif inst.e >= 1:
            poor.append(inst)
    return rich + poor[:max(0, n - len(rich))], int(len(tp))


def pg_train_instances(S, n, seed):
    """PGExplainer training targets: transactions of the training and validation periods flagged by the model
    (never test-period transactions)."""
    pre = np.concatenate([S.g["train_idx"].numpy(), S.g["val_idx"].numpy()])
    flagged = pre[S.probs[pre] >= S.threshold]
    order = np.random.default_rng(seed + 1).permutation(flagged)
    out = []
    for gid in order:
        inst = make_instance(S, int(gid))
        if inst.e >= 1:
            out.append(inst)
        if len(out) >= n:
            break
    return out


def explain(name, S, inst, pool, pg, C, seed=0, k_frac=None):
    k = C["ours"]["k_frac"] if k_frac is None else k_frac
    if name == "ours":
        o = C["ours"]
        return X.ours(S, inst, pool, m=o["m"], tau=o["tau"], k_frac=k, seed=seed)
    if name == "gnnexplainer":
        return X.gnnexplainer(S, inst, k_frac=k, seed=seed, **C["gnnexplainer"])
    if name == "pgexplainer":
        return pg.explain(inst, k_frac=k)
    if name == "subgraphx":
        return X.subgraphx(S, inst, k_frac=k, seed=seed, budgets=tuple(C["budgets"]), **C["subgraphx"])
    if name == "gradcam":
        return X.gradcam(S, inst, k_frac=k)
    if name == "random":
        return X.random_expl(S, inst, k_frac=k, seed=seed)
    raise ValueError(name)


def feature_level(S, inst, feat_score, frac=0.2):
    """Feature explanation: keep only the top `frac` features (others set to their training mean) -> sufficiency;
    set only the top features to the mean -> necessity."""
    d = inst.d
    k = max(1, int(math.ceil(frac * d)))
    top = torch.as_tensor(np.argsort(-np.asarray(feat_score))[:k], device=inst.x.device)
    keep = torch.zeros(d, device=inst.x.device)
    keep[top] = 1.0
    from xai.core import prob_variants
    xs = torch.stack([inst.x * keep[None], inst.x * (1 - keep)[None]])
    p_keep, p_drop = prob_variants(S, inst, xs).cpu().numpy().tolist()
    return {"feat_fidelity": 1 - abs(inst.p - p_keep) / max(inst.p, 1e-12), "feat_fid_plus": inst.p - p_drop,
            "top_features": [S.g["feature_names"][int(i)] for i in top.cpu().numpy()[:10]]}


def inst_record(S, inst, pool):
    rids, sims = pool.nearest(inst, 1)
    return {"gid": inst.gid, "n": inst.n, "e": inst.e, "d": inst.d, "p": inst.p, "threshold": S.threshold,
            "hop_counts": np.bincount(inst.hop).tolist(),
            "edges_by_relation": np.bincount(inst.etype, minlength=len(S.g["relation_names"])).tolist(),
            "nearest_ref": rids[0], "nearest_ref_sim": sims[0]}, pool.counterpart(inst, rids[0])


def curve(S, inst, ex, xr, C):
    out = {}
    o = C["ours"]
    for b in C["budgets"]:
        if ex.method == "ours":
            ek = X.prune(S, inst, torch.as_tensor(ex.node_score, device=inst.x.device),
                         torch.as_tensor(ex.edge_score, device=inst.x.device),
                         torch.as_tensor(ex.feat_score, device=inst.x.device), o["tau"], b)[1]
        elif ex.method == "subgraphx":
            ek = ex.extra["per_budget"][b]
        else:
            ek = X.budget_edges(inst, ex.edge_score, b)
        q = quality(S, inst, ek, xr)
        out[str(b)] = {k: q[k] for k in ("fidelity", "fid_plus", "sparsity", "disc_power", "flip")}
    return out


def save_details(ex, inst):
    return {"node_score": np.round(ex.node_score, 5).tolist(), "edge_score": np.round(ex.edge_score, 5).tolist(),
            "edge_keep": ex.edge_keep.cpu().numpy().astype(int).tolist(),
            "feat_score": None if ex.feat_score is None else np.round(ex.feat_score, 5).tolist(),
            "feat_keep": ex.feat_keep.cpu().numpy().astype(int).tolist()}


# ------------------------------------------------------------------ stages
def stage_perf(cfg, C, ds, device, out_dir):
    for model in ["gcn", "sage", "gat"]:
        for seed in range(C["perf_seeds"]):
            path = os.path.join(out_dir, "perf", ds, f"{model}_s{seed}.json")
            if os.path.exists(path):
                continue
            S = load_setup(cfg, ds, model, seed, device)
            te = S.g["test_idx"].numpy()
            y, p = S.g["y"].numpy()[te], S.probs[te]
            prec, rec, _ = precision_recall_curve(y, p)
            pred = p >= S.threshold
            tp = int((pred & (y == 1)).sum()); fp = int((pred & (y == 0)).sum()); fn = int((~pred & (y == 1)).sum())
            pr_, rc_ = tp / max(tp + fp, 1), tp / max(tp + fn, 1)
            res = {"dataset": ds, "model": model, "seed": seed, "roc_auc": float(roc_auc_score(y, p)),
                   "pr_auc": float(average_precision_score(y, p)),
                   "precision_at_90_recall": float(prec[rec >= 0.9].max()),
                   "f1": 2 * pr_ * rc_ / max(pr_ + rc_, 1e-12), "precision": pr_, "recall": rc_,
                   "threshold": S.threshold, "stored_test_metrics": S.ck["test_metrics"]}
            save_json(res, path)
            print(f"[perf] {ds} {model} s{seed}: PR-AUC {res['pr_auc']:.4f} (stored "
                  f"{S.ck['test_metrics']['pr_auc']:.4f}) P@90R {res['precision_at_90_recall']:.4f}", flush=True)


def stage_main(cfg, C, ds, model, device, out_dir, methods, with_curves=True, n=None, stage="main"):
    set_seed(C["seed"])
    meter = Meter(device)
    S = load_setup(cfg, ds, model, C["seed"], device)
    pool = X.ReferencePool(S, C["pool_size"], C["seed"])
    insts, n_tp = target_instances(S, n or C["n_instances"], C["min_edges"], C["seed"])
    pg = None
    if "pgexplainer" in methods:
        meta_p = os.path.join(out_dir, stage, ds, model, "_meta.json")
        pgc = C["pgexplainer"]
        tr = pg_train_instances(S, pgc["n_train"], C["seed"])
        (pg, _, _) = meter.run(lambda: X.PGExplainer(S, epochs=pgc["epochs"], lr=pgc["lr"], seed=C["seed"]).fit(tr))
        save_json({"dataset": ds, "model": model, "test_true_positives": n_tp, "targets": len(insts),
                   "pg_train_instances": len(tr), "pg_train_seconds": pg.train_seconds,
                   "relation_names": S.g["relation_names"], "threshold": S.threshold}, meta_p)
    for i, inst in enumerate(insts):
        path = os.path.join(out_dir, stage, ds, model, f"{inst.gid}.json")
        if os.path.exists(path):
            continue
        rec, xr = inst_record(S, inst, pool)
        rec.update({"dataset": ds, "model": model, "stage": stage, "methods": {}})
        if stage == "main":
            rec["nodes"] = inst.nodes.tolist()
            rec["hop"] = inst.hop.tolist()
            rec["edge_index"] = inst.ei.cpu().numpy().tolist()
            rec["edge_type"] = inst.etype.tolist()
        for mname in methods:
            ex, dt, mem = meter.run(lambda: explain(mname, S, inst, pool, pg, C, seed=C["seed"]))
            r = {"seconds": dt, "mem_mb": mem, "quality": quality(S, inst, ex.edge_keep, xr)}
            if mname == "ours":
                r["refs"] = ex.extra["refs"]; r["ref_sims"] = ex.extra["ref_sims"]
                r["n_forward"] = ex.extra["n_forward"]; r["attr_seconds"] = ex.extra["attr_seconds"]
                r["feat_kept"] = int(ex.feat_keep.sum())
            if mname == "subgraphx":
                r["tree_size"] = ex.extra["tree_size"]
            if with_curves:
                r["curves"] = curve(S, inst, ex, xr, C)
            if ex.feat_score is not None:
                r["features"] = feature_level(S, inst, ex.feat_score)
            if stage == "main":
                r["details"] = save_details(ex, inst)
            if stage == "main" and i < C["n_stability"]:
                runs = [ex]
                for k in range(1, C["stability"]["runs"] + 1):
                    pin = perturbed(S, inst, C["stability"]["noise"], seed=1000 * k + inst.gid)
                    runs.append(explain(mname, S, pin, pool, pg, C, seed=C["seed"] + k))
                r["stability"] = stability(inst, runs)
            rec["methods"][mname] = r
        save_json(rec, path)
        q = rec["methods"][methods[0]]["quality"]
        print(f"[{stage}] {ds} {model} {i + 1}/{len(insts)} gid {inst.gid} n={inst.n} e={inst.e} "
              + " ".join(f"{m}:{rec['methods'][m]['seconds']:.2f}s" for m in methods)
              + f" | {methods[0]} fid {q['fidelity']:.3f} dp {q['disc_power']:.3f}", flush=True)


def stage_ablation(cfg, C, ds, model, device, out_dir):
    meter = Meter(device)
    S = load_setup(cfg, ds, model, C["seed"], device)
    pool = X.ReferencePool(S, C["pool_size"], C["seed"])
    insts, _ = target_instances(S, C["n_ablation"], C["min_edges"], C["seed"])
    o = C["ours"]
    for i, inst in enumerate(insts):
        path = os.path.join(out_dir, "ablation", ds, model, f"{inst.gid}.json")
        if os.path.exists(path):
            continue
        rec, xr = inst_record(S, inst, pool)
        rec.update({"dataset": ds, "model": model, "variants": {}})
        for vname, over in ABLATIONS.items():
            kw = dict(m=o["m"], tau=o["tau"], k_frac=o["k_frac"])
            kw.update(over)

            def run(I, seed=C["seed"], kw=kw):
                return X.ours(S, I, pool, seed=seed, **kw)

            ex, dt, mem = meter.run(lambda: run(inst))
            r = {"seconds": dt, "mem_mb": mem, "quality": quality(S, inst, ex.edge_keep, xr)}
            if i < C["n_stability"]:
                runs = [ex] + [run(perturbed(S, inst, C["stability"]["noise"], seed=1000 * k + inst.gid),
                                   seed=C["seed"] + k) for k in range(1, C["stability"]["runs"] + 1)]
                r["stability"] = stability(inst, runs)
            if ex.feat_score is not None:
                r["features"] = feature_level(S, inst, ex.feat_score)
            rec["variants"][vname] = r
        save_json(rec, path)
        print(f"[ablation] {ds} {i + 1}/{len(insts)} gid {inst.gid} "
              + " ".join(f"{v}:{rec['variants'][v]['quality']['disc_power']:.3f}" for v in ABLATIONS), flush=True)


def stage_sensitivity(cfg, C, ds, model, device, out_dir):
    sc = C["sensitivity"]
    S = load_setup(cfg, ds, model, C["seed"], device)
    pool = X.ReferencePool(S, C["pool_size"], C["seed"])
    insts, _ = target_instances(S, sc["n"], C["min_edges"], C["seed"])
    o = C["ours"]
    grid = [("tau", v) for v in sc["tau"]] + [("m", v) for v in sc["m"]] + [("k_frac", v) for v in sc["k_frac"]]
    for i, inst in enumerate(insts):
        path = os.path.join(out_dir, "sensitivity", ds, model, f"{inst.gid}.json")
        if os.path.exists(path):
            continue
        rec, xr = inst_record(S, inst, pool)
        rec.update({"dataset": ds, "model": model, "settings": []})
        for par, val in grid:
            kw = dict(m=o["m"], tau=o["tau"], k_frac=o["k_frac"])
            kw[par] = val
            t0 = time.perf_counter()
            ex = X.ours(S, inst, pool, seed=C["seed"], **kw)
            rec["settings"].append({"param": par, "value": val, "seconds": time.perf_counter() - t0,
                                    "quality": quality(S, inst, ex.edge_keep, xr)})
        save_json(rec, path)
        print(f"[sensitivity] {ds} {i + 1}/{len(insts)}", flush=True)


def stage_scalability(cfg, C, ds, model, device, out_dir, methods):
    sc = C["scalability"]
    meter = Meter(device)
    S = load_setup(cfg, ds, model, C["seed"], device)
    pool = X.ReferencePool(S, C["pool_size"], C["seed"])
    insts, _ = target_instances(S, sc["n"], C["min_edges"], C["seed"])
    pgc = C["pgexplainer"]
    pg = X.PGExplainer(S, epochs=pgc["epochs"], lr=pgc["lr"], seed=C["seed"]).fit(
        pg_train_instances(S, pgc["n_train"], C["seed"]))
    for i, base in enumerate(insts):
        for hops in sc["hops"]:
            path = os.path.join(out_dir, "scalability", ds, model, f"{base.gid}_h{hops}.json")
            if os.path.exists(path):
                continue
            inst = make_instance(S, base.gid, hops=hops)
            if inst.n > sc["max_nodes"]:
                continue
            rec = {"gid": inst.gid, "hops": hops, "n": inst.n, "e": inst.e, "methods": {}}
            for mname in methods:
                if mname == "subgraphx" and inst.n > sc["subgraphx_max_nodes"]:
                    continue
                ex, dt, mem = meter.run(lambda: explain(mname, S, inst, pool, pg, C, seed=C["seed"]))
                rec["methods"][mname] = {"seconds": dt, "mem_mb": mem}
            save_json(rec, path)
            print(f"[scalability] {ds} {i + 1}/{len(insts)} hops {hops} n={inst.n} "
                  + " ".join(f"{m}:{v['seconds']:.2f}s" for m, v in rec["methods"].items()), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="full", choices=["smoke", "pilot", "full"])
    ap.add_argument("--data-profile", default="full", help="lsgat config profile for data paths ('local' = reuse "
                                                            "../lsgat_experiments/data)")
    ap.add_argument("--datasets", nargs="+", default=None)
    ap.add_argument("--stages", nargs="+", default=["perf", "main", "arch", "ablation", "sensitivity", "scalability"])
    ap.add_argument("--device", default="auto")
    ap.add_argument("--deadline", type=float, default=None, help="unix time after which no new stage starts")
    args = ap.parse_args()
    C = load_xai_config(args.profile)
    cfg = load_config(args.data_profile)
    device = get_device(args.device)
    out_dir = os.path.join(ROOT, "results" if args.profile == "full" else f"results_{args.profile}")
    print(f"profile={args.profile} device={device} out={out_dir}", flush=True)
    for ds in args.datasets or C["datasets"]:
        for st in args.stages:
            if args.deadline and time.time() > args.deadline:
                print("deadline reached, stopping", flush=True)
                return
            t0 = time.perf_counter()
            if st == "perf":
                stage_perf(cfg, C, ds, device, out_dir)
            elif st == "main":
                stage_main(cfg, C, ds, C["main_model"], device, out_dir, METHODS)
            elif st == "arch":
                for model in C["arch_models"]:
                    stage_main(cfg, C, ds, model, device, out_dir, METHODS, with_curves=False, n=C["n_arch"],
                               stage="arch")
            elif st == "ablation":
                stage_ablation(cfg, C, ds, C["main_model"], device, out_dir)
            elif st == "sensitivity" and ds == C["sensitivity"]["dataset"]:
                stage_sensitivity(cfg, C, ds, C["main_model"], device, out_dir)
            elif st == "scalability" and ds == C["scalability"]["dataset"]:
                stage_scalability(cfg, C, ds, C["main_model"], device, out_dir, METHODS)
            else:
                continue
            print(f"== {ds} {st} done in {time.perf_counter() - t0:.0f} s", flush=True)


if __name__ == "__main__":
    main()
