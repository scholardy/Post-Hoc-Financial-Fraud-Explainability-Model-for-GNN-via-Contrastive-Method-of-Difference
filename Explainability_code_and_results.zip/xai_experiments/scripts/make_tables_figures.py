"""results/ -> tables/*.csv, figures/*.png and tables/summary.json (all numbers used in the paper).

python scripts/make_tables_figures.py [--profile full|pilot|smoke]
"""
import argparse
import glob
import json
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy.stats import wilcoxon  # noqa: E402

DS = ["creditcard", "ieee", "paysim"]
DS_NAME = {"creditcard": "CCF", "ieee": "IEEE-CIS", "paysim": "PaySim"}
METHODS = ["gnnexplainer", "pgexplainer", "subgraphx", "gradcam", "random", "ours"]
M_NAME = {"gnnexplainer": "GNNExplainer", "pgexplainer": "PGExplainer", "subgraphx": "SubgraphX",
          "gradcam": "Grad-CAM", "random": "Random", "ours": "Ours"}
M_COLOR = {"gnnexplainer": "#1f77b4", "pgexplainer": "#2ca02c", "subgraphx": "#ff7f0e", "gradcam": "#9467bd",
           "random": "#7f7f7f", "ours": "#d62728"}
MODEL_NAME = {"gcn": "GCN", "sage": "GraphSAGE", "gat": "GAT"}
ABL = ["full", "no_contrast", "unsigned", "no_ensemble", "random_attr", "no_budget", "no_pruning", "exact"]
ABL_NAME = {"full": "Full model", "no_contrast": "w/o contrastive reference (mean baseline)",
            "unsigned": "w/o signed evidence (absolute scores)", "no_ensemble": "w/o ensemble (m = 1)",
            "random_attr": "w/o gradient attribution (random scores)", "no_budget": "w/o sparsity constraint",
            "no_pruning": "w/o pruning (top-scored elements)", "exact": "exact switches instead of gradients"}
QM = ["fidelity", "fid_plus", "sparsity", "disc_power", "flip"]


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    run = 0.0
    m = len(p)
    for r, i in enumerate(order):
        run = max(run, (m - r) * p[i])
        adj[i] = min(1.0, run)
    return adj


def ms(a, nd=3):
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return ""
    return f"{a.mean():.{nd}f} ± {a.std(ddof=1) if a.size > 1 else 0.0:.{nd}f}"


def load(res, stage, ds, model):
    out = []
    for f in sorted(glob.glob(os.path.join(res, stage, ds, model, "*.json"))):
        if os.path.basename(f).startswith("_"):
            continue
        out.append(json.load(open(f)))
    return out


def meta(res, stage, ds, model):
    p = os.path.join(res, stage, ds, model, "_meta.json")
    return json.load(open(p)) if os.path.exists(p) else {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="full")
    args = ap.parse_args()
    sfx = "" if args.profile == "full" else f"_{args.profile}"
    res = os.path.join(ROOT, "results" + sfx)
    tdir = os.path.join(ROOT, "tables" + sfx)
    fdir = os.path.join(ROOT, "figures" + sfx)
    os.makedirs(tdir, exist_ok=True)
    os.makedirs(fdir, exist_ok=True)
    S = {"profile": args.profile}

    # ---------------- Table 1: datasets
    rows = []
    for ds in DS:
        st = json.load(open(os.path.join(ROOT, "results", "dataset_stats", f"{ds}.json")))
        rows.append({"Dataset": DS_NAME[ds], "Nodes": st["nodes"], "Edges": st["edges_directed_stored"],
                     "Features": st["features"], "Fraud rate (%)": 100 * st["fraud_rate"],
                     "Transactions": st["nodes"], "Avg. degree": st["avg_degree"],
                     "Relations": "; ".join(f"{k} ({v:,})" for k, v in st["edges_by_relation"].items()),
                     "Frauds": st["frauds"], "Split": st["split_sizes"], "Split frauds": st["split_frauds"]})
    t1 = pd.DataFrame(rows)
    t1.to_csv(os.path.join(tdir, "table1_datasets.csv"), index=False)
    S["datasets"] = rows

    # ---------------- Table 2: GNN performance
    rows = []
    for ds in DS:
        for model in ["gcn", "sage", "gat"]:
            R = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(res, "perf", ds, f"{model}_s*.json")))]
            if not R:
                continue
            rows.append({"Model": MODEL_NAME[model], "Dataset": DS_NAME[ds], "ds": ds, "model": model, "seeds": len(R),
                         **{k: ms([r[k] for r in R], 3) for k in ("roc_auc", "pr_auc", "precision_at_90_recall", "f1")},
                         **{k + "_mean": float(np.mean([r[k] for r in R])) for k in
                            ("roc_auc", "pr_auc", "precision_at_90_recall", "f1")}})
    t2 = pd.DataFrame(rows)
    t2.to_csv(os.path.join(tdir, "table2_gnn_performance.csv"), index=False)
    S["perf"] = rows

    # ---------------- main: quality, stability, time
    main_rows, stab_rows, time_rows, sig_rows, feat_rows = [], [], [], [], []
    per = {}
    for ds in DS:
        R = load(res, "main", ds, "sage")
        if not R:
            continue
        mt = meta(res, "main", ds, "sage")
        per[ds] = R
        S.setdefault("main_meta", {})[ds] = {**mt, "targets": len(R),
                                             "mean_nodes": float(np.mean([r["n"] for r in R])),
                                             "mean_edges": float(np.mean([r["e"] for r in R])),
                                             "median_nodes": float(np.median([r["n"] for r in R])),
                                             "targets_ge3_edges": int(sum(r["e"] >= 3 for r in R))}
        for m in METHODS:
            Q = [r["methods"][m]["quality"] for r in R if m in r["methods"]]
            st = [r["methods"][m]["stability"] for r in R if "stability" in r["methods"].get(m, {})]
            row = {"Method": M_NAME[m], "Dataset": DS_NAME[ds], "ds": ds, "method": m, "n": len(Q)}
            for k in QM:
                row[k] = ms([q[k] for q in Q])
                row[k + "_mean"] = float(np.mean([q[k] for q in Q]))
            row["stability"] = ms([s["stability"] for s in st]) if st else ""
            row["stability_mean"] = float(np.mean([s["stability"] for s in st])) if st else np.nan
            main_rows.append(row)
            if st:
                stab_rows.append({"Method": M_NAME[m], "Dataset": DS_NAME[ds], "ds": ds, "method": m, "n": len(st),
                                  **{k: ms([s[k] for s in st], 3 if k != "edit_distance" else 2) for k in
                                     ("jaccard", "spearman", "edit_distance", "stability")},
                                  **{k + "_mean": float(np.mean([s[k] for s in st])) for k in
                                     ("jaccard", "spearman", "edit_distance", "stability")}})
            secs = np.array([r["methods"][m]["seconds"] for r in R])
            nodes = np.array([r["n"] for r in R])
            mem = [r["methods"][m]["mem_mb"] for r in R if r["methods"][m].get("mem_mb") is not None]
            time_rows.append({"Method": M_NAME[m], "Dataset": DS_NAME[ds], "ds": ds, "method": m,
                              "seconds_mean": float(secs.mean()), "seconds_median": float(np.median(secs)),
                              "mem_mb_mean": float(np.mean(mem)) if mem else np.nan,
                              "mem_mb_max": float(np.max(mem)) if mem else np.nan,
                              "nodes_per_second": float(nodes.sum() / secs.sum())})
            f = [r["methods"][m]["features"] for r in R if "features" in r["methods"].get(m, {})]
            if f:
                feat_rows.append({"Method": M_NAME[m], "Dataset": DS_NAME[ds],
                                  "feat_fidelity": ms([x["feat_fidelity"] for x in f]),
                                  "feat_fid_plus": ms([x["feat_fid_plus"] for x in f]),
                                  "feat_fidelity_mean": float(np.mean([x["feat_fidelity"] for x in f])),
                                  "feat_fid_plus_mean": float(np.mean([x["feat_fid_plus"] for x in f]))})
        # significance: ours vs each baseline (paired Wilcoxon over targets), Holm within dataset
        tests = []
        for m in [x for x in METHODS if x != "ours"]:
            for k in ("fidelity", "fid_plus", "disc_power"):
                a = np.array([r["methods"]["ours"]["quality"][k] for r in R])
                b = np.array([r["methods"][m]["quality"][k] for r in R])
                d = a - b
                p = wilcoxon(a, b).pvalue if np.any(d != 0) else 1.0
                tests.append({"Dataset": DS_NAME[ds], "ds": ds, "Baseline": M_NAME[m], "baseline": m, "Metric": k,
                              "ours_mean": a.mean(), "baseline_mean": b.mean(), "median_diff": float(np.median(d)),
                              "wins": int((d > 0).sum()), "ties": int((d == 0).sum()), "losses": int((d < 0).sum()),
                              "p": float(p)})
        adj = holm([t["p"] for t in tests])
        for t, a in zip(tests, adj):
            t["p_holm"] = float(a)
            t["direction"] = ("Ours better" if t["ours_mean"] > t["baseline_mean"] else "Baseline better") \
                if a < 0.05 else "No significant difference"
        sig_rows += tests
    t3 = pd.DataFrame(main_rows)
    t3.to_csv(os.path.join(tdir, "table3_quality.csv"), index=False)
    pd.DataFrame(stab_rows).to_csv(os.path.join(tdir, "table4_stability.csv"), index=False)
    pd.DataFrame(time_rows).to_csv(os.path.join(tdir, "table7_time_by_dataset.csv"), index=False)
    pd.DataFrame(sig_rows).to_csv(os.path.join(tdir, "tableA3_significance.csv"), index=False)
    pd.DataFrame(feat_rows).to_csv(os.path.join(tdir, "feature_level.csv"), index=False)
    S["quality"], S["stability"], S["significance"], S["features"] = main_rows, stab_rows, sig_rows, feat_rows

    # Table 7: computational performance (all main targets pooled)
    rows = []
    for m in METHODS:
        secs, nodes, mem = [], [], []
        for ds, R in per.items():
            for r in R:
                secs.append(r["methods"][m]["seconds"]); nodes.append(r["n"])
                if r["methods"][m].get("mem_mb") is not None:
                    mem.append(r["methods"][m]["mem_mb"])
        if not secs:
            continue
        secs, nodes = np.array(secs), np.array(nodes)
        rows.append({"Method": M_NAME[m], "method": m, "avg_seconds": float(secs.mean()), "sd_seconds": float(secs.std()),
                     "median_seconds": float(np.median(secs)),
                     "mem_mb": float(np.mean(mem)) if mem else np.nan,
                     "mem_mb_max": float(np.max(mem)) if mem else np.nan,
                     "nodes_per_second": float(nodes.sum() / secs.sum())})
    pg_train = {ds: S["main_meta"][ds].get("pg_train_seconds") for ds in S.get("main_meta", {})}
    t7 = pd.DataFrame(rows)
    t7.to_csv(os.path.join(tdir, "table7_computational.csv"), index=False)
    S["computational"] = rows
    S["pg_train_seconds"] = pg_train

    # ---------------- Table 5: other architectures
    rows = []
    for ds in DS:
        for model in ["gcn", "gat"]:
            R = load(res, "arch", ds, model)
            if not R:
                continue
            S.setdefault("arch_meta", {})[f"{ds}_{model}"] = {**meta(res, "arch", ds, model), "targets": len(R),
                                                             "targets_ge3_edges": int(sum(r["e"] >= 3 for r in R))}
            for m in METHODS:
                Q = [r["methods"][m]["quality"] for r in R]
                rows.append({"Model": MODEL_NAME[model], "Dataset": DS_NAME[ds], "Method": M_NAME[m], "ds": ds,
                             "model": model, "method": m, "n": len(Q),
                             **{k: ms([q[k] for q in Q]) for k in QM},
                             **{k + "_mean": float(np.mean([q[k] for q in Q])) for k in QM},
                             "seconds_mean": float(np.mean([r["methods"][m]["seconds"] for r in R]))})
    pd.DataFrame(rows).to_csv(os.path.join(tdir, "table5_architectures.csv"), index=False)
    S["arch"] = rows

    # ---------------- Table 6: ablation
    rows = []
    for ds in DS:
        R = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(res, "ablation", ds, "sage", "*.json")))]
        if not R:
            continue
        tests = []
        full = np.array([r["variants"]["full"]["quality"]["disc_power"] for r in R])
        for v in ABL:
            Q = [r["variants"][v]["quality"] for r in R]
            st = [r["variants"][v]["stability"]["stability"] for r in R if "stability" in r["variants"][v]]
            row = {"Variant": ABL_NAME[v], "Dataset": DS_NAME[ds], "ds": ds, "variant": v, "n": len(Q),
                   **{k: ms([q[k] for q in Q]) for k in QM},
                   **{k + "_mean": float(np.mean([q[k] for q in Q])) for k in QM},
                   "stability": ms(st) if st else "", "stability_mean": float(np.mean(st)) if st else np.nan,
                   "seconds_mean": float(np.mean([r["variants"][v]["seconds"] for r in R]))}
            if v != "full":
                b = np.array([q["disc_power"] for q in Q])
                d = full - b
                row["p_dp"] = float(wilcoxon(full, b).pvalue) if np.any(d != 0) else 1.0
                tests.append(row)
            rows.append(row)
        adj = holm([t["p_dp"] for t in tests])
        for t, a in zip(tests, adj):
            t["p_dp_holm"] = float(a)
    pd.DataFrame(rows).to_csv(os.path.join(tdir, "table6_ablation.csv"), index=False)
    S["ablation"] = rows

    # ---------------- sensitivity
    rows = []
    for f in sorted(glob.glob(os.path.join(res, "sensitivity", "*", "sage", "*.json"))):
        r = json.load(open(f))
        for s in r["settings"]:
            rows.append({"param": s["param"], "value": s["value"], "seconds": s["seconds"], **s["quality"]})
    sens = pd.DataFrame(rows)
    if len(sens):
        agg = sens.groupby(["param", "value"])[["fidelity", "fid_plus", "sparsity", "disc_power", "flip",
                                                 "seconds"]].mean().reset_index()
        agg.to_csv(os.path.join(tdir, "sensitivity.csv"), index=False)
        S["sensitivity"] = agg.to_dict("records")

    # ---------------- scalability
    rows = []
    for f in sorted(glob.glob(os.path.join(res, "scalability", "*", "sage", "*.json"))):
        r = json.load(open(f))
        for m, v in r["methods"].items():
            rows.append({"gid": r["gid"], "hops": r["hops"], "n": r["n"], "e": r["e"], "method": m, **v})
    scal = pd.DataFrame(rows)
    if len(scal):
        scal.to_csv(os.path.join(tdir, "scalability_raw.csv"), index=False)
        sagg = scal.groupby(["method", "hops"]).agg(n=("n", "mean"), seconds=("seconds", "mean"),
                                                    mem_mb=("mem_mb", "mean"), count=("n", "size")).reset_index()
        sagg.to_csv(os.path.join(tdir, "scalability.csv"), index=False)
        S["scalability"] = sagg.to_dict("records")
        # log-log slope of time vs nodes per method
        S["scalability_slope"] = {}
        for m in scal.method.unique():
            d = scal[scal.method == m]
            if d.n.nunique() > 2:
                S["scalability_slope"][m] = float(np.polyfit(np.log(d.n), np.log(d.seconds), 1)[0])

    # ================= figures
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    # Fig 2: radar charts
    dsets = [d for d in DS if d in per]
    if dsets:
        labels = ["Fidelity", "Necessity", "Sparsity", "Stability", "Disc. power", "Flip rate"]
        keys = ["fidelity", "fid_plus", "sparsity", "stability", "disc_power", "flip"]
        fig, axes = plt.subplots(1, len(dsets), figsize=(4.0 * len(dsets), 3.9), subplot_kw={"polar": True})
        axes = np.atleast_1d(axes)
        ang = np.linspace(0, 2 * np.pi, len(keys), endpoint=False).tolist()
        for ax, ds in zip(axes, dsets):
            d = t3[t3.ds == ds].set_index("method")
            for m in METHODS:
                vals = []
                for k in keys:
                    col = d[k + "_mean"].astype(float)
                    lo, hi = np.nanmin(col.values), np.nanmax(col.values)
                    v = float(d.loc[m, k + "_mean"])
                    vals.append(0.1 + 0.9 * (v - lo) / (hi - lo) if hi > lo else 1.0)
                ax.plot(ang + ang[:1], vals + vals[:1], color=M_COLOR[m], lw=2.2 if m == "ours" else 1.2,
                        label=M_NAME[m])
                if m == "ours":
                    ax.fill(ang + ang[:1], vals + vals[:1], color=M_COLOR[m], alpha=0.12)
            ax.set_xticks(ang)
            ax.set_xticklabels(labels, fontsize=8)
            ax.set_yticklabels([])
            ax.set_ylim(0, 1.05)
            ax.set_title(DS_NAME[ds], pad=14, fontsize=10, fontweight="bold")
        h, l = axes[0].get_legend_handles_labels()
        fig.legend(h, l, loc="lower center", ncol=6, frameon=False, fontsize=8)
        fig.subplots_adjust(left=0.05, right=0.95, top=0.85, bottom=0.14, wspace=0.45)
        fig.savefig(os.path.join(fdir, "fig2_radar.png"), dpi=300)
        plt.close(fig)

        # Fig 3: fidelity / discriminative power vs sparsity
        fig, axes = plt.subplots(2, len(dsets), figsize=(4.0 * len(dsets), 6.2))
        axes = np.array(axes).reshape(2, -1)
        for j, ds in enumerate(dsets):
            for m in METHODS:
                xs, ys, zs = [], [], []
                for b in sorted({float(k) for r in per[ds] for k in r["methods"][m].get("curves", {})}):
                    C = [r["methods"][m]["curves"][str(b)] for r in per[ds] if str(b) in r["methods"][m].get("curves", {})]
                    xs.append(np.mean([c["sparsity"] for c in C]))
                    ys.append(np.mean([c["fidelity"] for c in C]))
                    zs.append(np.mean([c["disc_power"] for c in C]))
                o = np.argsort(xs)
                kw = dict(color=M_COLOR[m], marker="o", ms=3.5, lw=2.2 if m == "ours" else 1.2, label=M_NAME[m])
                axes[0, j].plot(np.array(xs)[o], np.array(ys)[o], **kw)
                axes[1, j].plot(np.array(xs)[o], np.array(zs)[o], **kw)
            axes[0, j].set_title(DS_NAME[ds], fontweight="bold")
            axes[1, j].set_xlabel("Sparsity")
        axes[0, 0].set_ylabel("Fidelity")
        axes[1, 0].set_ylabel("Discriminative power")
        axes[0, 0].legend(frameon=False, fontsize=7.5)
        fig.tight_layout()
        fig.savefig(os.path.join(fdir, "fig3_tradeoff.png"), dpi=300, bbox_inches="tight")
        plt.close(fig)

    # Fig 6: scalability
    if len(scal):
        fig, ax = plt.subplots(figsize=(5.6, 3.8))
        for m in METHODS:
            d = scal[scal.method == m]
            if not len(d):
                continue
            ax.scatter(d.n, d.seconds, s=9, color=M_COLOR[m], alpha=0.35)
            g = d.groupby("hops").agg(n=("n", "median"), s=("seconds", "median")).reset_index()
            ax.plot(g.n, g.s, color=M_COLOR[m], marker="o", lw=2.2 if m == "ours" else 1.2, label=M_NAME[m])
        ax.set_xscale("log")
        ax.set_yscale("log")
        from matplotlib.ticker import FuncFormatter, NullFormatter
        ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
        ax.set_xlabel("Nodes in the explained subgraph")
        ax.set_ylabel("Explanation time (s)")
        ax.legend(frameon=False, fontsize=7.5, ncol=2)
        fig.tight_layout()
        fig.savefig(os.path.join(fdir, "fig6_scalability.png"), dpi=300, bbox_inches="tight")
        plt.close(fig)

    # Fig A2: sensitivity
    if len(sens):
        params = [("tau", "Fidelity threshold τ"), ("m", "Ensemble size m"), ("k_frac", "Sparsity budget k")]
        fig, axes = plt.subplots(1, 3, figsize=(11, 3.2))
        for ax, (p, lab) in zip(axes, params):
            d = agg[agg.param == p].sort_values("value")
            for k, c, nm in [("fidelity", "#1f77b4", "Fidelity"), ("sparsity", "#2ca02c", "Sparsity"),
                             ("disc_power", "#d62728", "Disc. power"), ("flip", "#9467bd", "Flip rate")]:
                ax.plot(d.value, d[k], marker="o", color=c, label=nm)
            ax.axvline({"tau": 0.05, "m": 3, "k_frac": 0.2}[p], color="k", ls=":", lw=0.8)
            ax.set_xlabel(lab)
        axes[0].set_xscale("log")
        axes[0].legend(frameon=False, fontsize=7.5)
        fig.tight_layout()
        fig.savefig(os.path.join(fdir, "figA2_sensitivity.png"), dpi=300, bbox_inches="tight")
        plt.close(fig)

    with open(os.path.join(tdir, "summary.json"), "w") as f:
        json.dump(S, f, indent=1, default=lambda o: o if not isinstance(o, np.generic) else o.item())
    print("tables ->", tdir, "| figures ->", fdir)
    print(t3[["Dataset", "Method", "fidelity", "fid_plus", "sparsity", "stability", "disc_power", "flip"]]
          .to_string(index=False))


if __name__ == "__main__":
    main()
