"""Case study (paper Sec. 4.6, Figure 5): one IEEE-CIS fraud explained by the proposed method.

Picks, from results/main/ieee/sage, a correctly detected fraud whose contrastive explanation flips the decision,
whose computation subgraph has 8-30 transactions and at least two relation types. Needs the local IEEE-CIS data
(raw CSV + cached graph) to report readable attributes.

python scripts/case_study.py [--profile full|pilot] [--data-profile local] [--gid N]
"""
import argparse
import glob
import json
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import networkx as nx  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402

from lsgat.config import load_config, resolve_path  # noqa: E402
from lsgat.data.graph import load_or_build  # noqa: E402

REL_COLOR = ["#1f77b4", "#2ca02c", "#ff7f0e"]


def pick(records):
    cands = []
    for r in records:
        o = r["methods"]["ours"]
        rel = set(r["edge_type"])
        if 8 <= r["n"] <= 30 and len(rel) >= 2 and o["quality"]["flip"] == 1 and o["quality"]["n_edges"] >= 2:
            cands.append((o["quality"]["disc_power"], r))
    cands.sort(key=lambda t: -t[0])
    return cands[0][1] if cands else max(records, key=lambda r: r["methods"]["ours"]["quality"]["disc_power"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="full")
    ap.add_argument("--data-profile", default="local")
    ap.add_argument("--gid", type=int, default=None)
    args = ap.parse_args()
    sfx = "" if args.profile == "full" else f"_{args.profile}"
    res = os.path.join(ROOT, "results" + sfx, "main", "ieee", "sage")
    recs = [json.load(open(f)) for f in glob.glob(os.path.join(res, "*.json")) if not f.endswith("_meta.json")]
    r = next(x for x in recs if x["gid"] == args.gid) if args.gid else pick(recs)
    meta = json.load(open(os.path.join(res, "_meta.json")))
    cfg = load_config(args.data_profile)
    g, _ = load_or_build(cfg, "ieee", torch.device("cpu"))
    fn = g["feature_names"]
    y = g["y"].numpy()
    nodes = np.array(r["nodes"])
    o = r["methods"]["ours"]
    det = o["details"]
    ref = o["refs"][0]

    # readable attributes from the raw data (same time order as the graph)
    cds = cfg["datasets"]["ieee"]
    cols = ["TransactionID", "TransactionDT", "TransactionAmt", "ProductCD", "card4", "card6", "P_emaildomain", "addr1"]
    raw = pd.read_csv(resolve_path(cds["raw"]["transaction"]), usecols=cols + ["isFraud"])
    idn = pd.read_csv(resolve_path(cds["raw"]["identity"]), usecols=["TransactionID", "DeviceType", "DeviceInfo"])
    raw = raw.merge(idn, on="TransactionID", how="left").sort_values("TransactionDT", kind="stable").reset_index(drop=True)
    assert (raw["isFraud"].values == y).all()
    sub = raw.iloc[nodes].copy()
    sub["hop"] = r["hop"]
    sub["label"] = y[nodes]
    sub["node_score"] = det["node_score"]

    # graph panels
    ei = np.array(r["edge_index"])
    et = np.array(r["edge_type"])
    keep = np.array(det["edge_keep"]).astype(bool)
    G = nx.DiGraph()
    G.add_nodes_from(range(len(nodes)))
    for k in range(ei.shape[1]):
        G.add_edge(int(ei[0, k]), int(ei[1, k]), k=k)
    hop = np.array(r["hop"])
    pos = {}
    for h in sorted(set(hop)):
        idx = np.flatnonzero(hop == h)
        for j, v in enumerate(idx):
            pos[int(v)] = (-h, (j - (len(idx) - 1) / 2) * (1.0 if h else 0))
    in_expl = np.zeros(len(nodes), bool)
    in_expl[0] = True
    in_expl[ei[0, keep]] = True
    in_expl[ei[1, keep]] = True

    fig = plt.figure(figsize=(13, 4.6))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 1.15, 1.1])
    rels = meta["relation_names"]
    for pi, (title, show) in enumerate([("(A) Computation subgraph of the target", False),
                                        ("(B) Contrastive explanation", True)]):
        ax = fig.add_subplot(gs[0, pi])
        for k in range(ei.shape[1]):
            u, v = int(ei[0, k]), int(ei[1, k])
            on = keep[k] if show else True
            ax.annotate("", xy=pos[v], xytext=pos[u],
                        arrowprops=dict(arrowstyle="-|>", color=REL_COLOR[et[k] % 3], lw=2.4 if (show and on) else 1.0,
                                        alpha=1.0 if on else 0.12, shrinkA=7, shrinkB=7, connectionstyle="arc3,rad=0.08"))
        for v in range(len(nodes)):
            face = "#d62728" if v == 0 else ("#fbb4ae" if y[nodes[v]] == 1 else "#dddddd")
            alpha = 1.0 if (not show or in_expl[v]) else 0.2
            ax.scatter(*pos[v], s=260 if v == 0 else 120, color=face, edgecolor="k", lw=0.8, zorder=3, alpha=alpha)
        ax.set_title(title, fontsize=10)
        ax.axis("off")
        if pi == 0:
            hs = [plt.Line2D([], [], color=REL_COLOR[i], lw=2, label=rels[i]) for i in sorted(set(et))]
            hs += [plt.Line2D([], [], marker="o", ls="", color="#d62728", mec="k", label="target (fraud)"),
                   plt.Line2D([], [], marker="o", ls="", color="#fbb4ae", mec="k", label="earlier fraud"),
                   plt.Line2D([], [], marker="o", ls="", color="#dddddd", mec="k", label="earlier legitimate")]
            fig.legend(handles=hs, loc="lower center", bbox_to_anchor=(0.36, -0.02), ncol=len(hs), fontsize=7.5,
                       frameon=False)
        ymin = min(p_[1] for p_ in pos.values())
        for h in sorted(set(hop)):
            ax.text(-h, ymin - 1.2, "target" if h == 0 else f"hop {h}", ha="center", fontsize=8, color="0.35")
        ax.set_ylim(ymin - 1.8, -ymin + 0.6)
    # feature contrast panel
    ax = fig.add_subplot(gs[0, 2])
    fs = np.array(det["feat_score"])
    xt = g["x"][int(nodes[0])].numpy()
    xr = g["x"][int(ref)].numpy()
    # highest contrastive scores among features on which the target differs from its nearest legitimate reference
    order = [i for i in np.argsort(-fs) if abs(xt[i] - xr[i]) > 0.1]
    top = np.array(order[:8])[::-1]
    yy = np.arange(len(top))
    ax.barh(yy + 0.2, xt[top], height=0.38, color="#d62728", label="target fraud")
    ax.barh(yy - 0.2, xr[top], height=0.38, color="#1f77b4", label="nearest legitimate")
    ax.set_yticks(yy)
    ax.set_yticklabels([fn[i] for i in top], fontsize=8)
    ax.axvline(0, color="k", lw=0.6)
    ax.set_xlabel("standardised value (0 = training mean)")
    ax.set_title("(C) Top contrastive features", fontsize=10)
    ax.legend(frameon=False, fontsize=7.5, loc="lower right")
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    fdir = os.path.join(ROOT, "figures" + sfx)
    os.makedirs(fdir, exist_ok=True)
    fig.savefig(os.path.join(fdir, "fig5_case_study.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)

    t = sub.iloc[0]
    rref = raw.iloc[int(ref)]
    kept_rel = np.bincount(et[keep], minlength=len(rels)).tolist()
    all_rel = np.bincount(et, minlength=len(rels)).tolist()
    nb = sub.iloc[1:]
    expl_nodes = sub[in_expl].iloc[1:]
    out = {
        "gid": int(r["gid"]), "transaction_id": int(t.TransactionID), "amount": float(t.TransactionAmt),
        "product": t.ProductCD, "card4": t.card4, "card6": t.card6, "email": t.P_emaildomain,
        "device_type": t.DeviceType, "device_info": t.DeviceInfo, "p": r["p"], "threshold": r["threshold"],
        "n": r["n"], "e": r["e"], "edges_by_relation": dict(zip(rels, all_rel)),
        "explanation_edges_by_relation": dict(zip(rels, kept_rel)),
        "explanation_nodes": int(in_expl.sum()), "explanation_edges": int(keep.sum()),
        "earlier_frauds_in_subgraph": int(nb.label.sum()), "earlier_in_subgraph": int(len(nb)),
        "earlier_frauds_in_explanation": int(expl_nodes.label.sum()), "earlier_in_explanation": int(len(expl_nodes)),
        "neighbour_amounts_in_explanation": expl_nodes.TransactionAmt.round(2).tolist(),
        "hours_before_target_in_explanation": ((t.TransactionDT - expl_nodes.TransactionDT) / 3600).round(1).tolist(),
        "minutes_before_target_in_explanation": ((t.TransactionDT - expl_nodes.TransactionDT) / 60).round(1).tolist(),
        "ref_gid": int(ref), "ref_transaction_id": int(rref.TransactionID), "ref_sim": o["ref_sims"][0],
        "ref_amount": float(rref.TransactionAmt), "ref_product": rref.ProductCD,
        "quality": o["quality"], "top_features": [fn[i] for i in top[::-1]],
        "top_feature_values": {fn[i]: [float(xt[i]), float(xr[i])] for i in top[::-1]},
        "feat_kept": o["feat_kept"], "seconds": o["seconds"],
        "gnnexplainer_flip": r["methods"]["gnnexplainer"]["quality"]["flip"],
    }
    tdir = os.path.join(ROOT, "tables" + sfx)
    with open(os.path.join(tdir, "case_study.json"), "w") as f:
        json.dump(out, f, indent=1, default=str)
    print(json.dumps(out, indent=1, default=str))


if __name__ == "__main__":
    main()
