"""Write the submission version of the explainability manuscript: the authors' draft
(paper/Explainability_manuscript_original.docx, never modified) filled with the measured tables, figures and
data-driven text.

python scripts/update_paper.py [--profile full|pilot] [--out path.docx]
Needs: tables<sfx>/summary.json (make_tables_figures.py), tables<sfx>/case_study.json (case_study.py), figures<sfx>/.
"""
import argparse
import json
import math
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import docx  # noqa: E402
from docx.enum.text import WD_ALIGN_PARAGRAPH  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.shared import Pt  # noqa: E402

from docx_helpers import (_cell, add_figure, build_table, has_math, new_par_after, remove, set_text,  # noqa: E402,F401
                          swap_table)

SRC = os.path.join(ROOT, "paper", "Explainability_manuscript_original.docx")
DS = ["creditcard", "ieee", "paysim"]
DN = {"creditcard": "CCF", "ieee": "IEEE-CIS", "paysim": "PaySim"}
METHODS = ["gnnexplainer", "pgexplainer", "subgraphx", "gradcam", "random", "ours"]
MN = {"gnnexplainer": "GNNExplainer", "pgexplainer": "PGExplainer", "subgraphx": "SubgraphX", "gradcam": "Grad-CAM",
      "random": "Random", "ours": "Ours"}
BASE = [m for m in METHODS if m not in ("ours", "random")]

# words whose hyphen / dash was lost in the draft (run-level replacement, whole words)
HYPHEN = {
    "PostHoc": "Post-Hoc", "Posthoc": "Post-hoc", "posthoc": "post-hoc", "blackbox": "black-box",
    "decisionmaking": "decision-making", "GNNbased": "GNN-based", "gradientbased": "gradient-based",
    "realworld": "real-world", "rulebased": "rule-based", "stateoftheart": "state-of-the-art",
    "multilayer": "multi-layer", "messagepassing": "message-passing", "nondiscriminative": "non-discriminative",
    "graphstructured": "graph-structured", "endtoend": "end-to-end", "GradientBased": "Gradient-Based",
    "PerturbationBased": "Perturbation-Based", "DecompositionBased": "Decomposition-Based", "GradCAM": "Grad-CAM",
    "coarsegrained": "coarse-grained", "instancelevel": "instance-level", "modellevel": "model-level",
    "instancespecific": "instance-specific", "highscoring": "high-scoring", "taskspecific": "task-specific",
    "humancentered": "human-centered", "khop": "k-hop", "ddimensional": "d-dimensional",
    "AlvarezMelis": "Alvarez-Melis", "antimoney": "anti-money", "Antimoney": "Anti-money", "topm": "top-m",
    "lowimportance": "low-importance", "fidelitysparsity": "fidelity–sparsity", "FidelitySparsity": "Fidelity–Sparsity",
    "tradeoff": "trade-off", "Tradeoff": "Trade-off", "highvariance": "high-variance", "highstakes": "high-stakes",
    "externalfacing": "external-facing", "fidelityprivacy": "fidelity–privacy", "FairnessAware": "Fairness-Aware",
    "CrossDomain": "Cross-Domain", "nontechnical": "non-technical", "multiscale": "multi-scale",
    "methodofdifference": "method-of-difference", "Semisupervised": "Semi-supervised",
    "semisupervised": "semi-supervised", "DíazRodríguez": "Díaz-Rodríguez", "GilLópez": "Gil-López",
    "PereiraFariña": "Pereira-Fariña", "CFGNNExplainer": "CF-GNNExplainer", "nearestneighbor": "nearest-neighbor",
    "prototypebased": "prototype-based", "crossentropy": "cross-entropy", "AUCPR": "AUC-PR", "AUCROC": "AUC-ROC",
    "pretrained": "pre-trained", "ensemblebased": "ensemble-based", "realtime": "real-time",
    "domainspecific": "domain-specific", "Dataset Specific": "Dataset-Specific", "decision making": "decision-making",
    "multiinstance": "multi-instance", "AIbased": "AI-based", "privacypreserving": "privacy-preserving",
    "graphbased": "graph-based", "tradeoffs": "trade-offs", "Tradeoffs": "Trade-offs",
    "Huang et al., 2022": "Huang et al., 2023", "Yuan et al., 2022": "Yuan et al., 2023",
    "Karimi et al., 2021": "Karimi et al., 2022", "Karimi et al. (2021)": "Karimi et al. (2022)",
    "Wu et al., 2020": "Wu et al., 2021", "humanin": "human-in", "Nonlinear": "Non-linear",
}
# placeholders / dummy content of the draft that must not survive
STALE = ["you can use the previous result", "[Table", "[Figure", "M=6.5", "142857", "47 compromised", "V100", "5.1 trillion",
         "0.52 seconds", "12 seconds", "1520%", "50100", "Ubuntu 20.04", "PyTorch 1.12", "human evaluation by domain",
         "Human evaluation results demonstrate", "12 financial fraud analysts", "three critical gaps", "Babaei",
         "Key player identification", "AIES", "Caption:", "70%), validation (15%)", "Likert", " "]


class Ctx:
    def __init__(self, S, case, fdir, profile):
        self.S, self.case, self.fdir, self.profile = S, case, fdir, profile
        self.q = {(r["ds"], r["method"]): r for r in S["quality"]}
        self.st = {(r["ds"], r["method"]): r for r in S.get("stability", [])}
        self.sig = {(r["ds"], r["baseline"], r["Metric"]): r for r in S.get("significance", [])}
        self.comp = {r["method"]: r for r in S.get("computational", [])}
        self.abl = {(r["ds"], r["variant"]): r for r in S.get("ablation", [])}
        self.perf = {(r["ds"], r["model"]): r for r in S.get("perf", [])}
        self.meta = S.get("main_meta", {})

    def v(self, ds, m, k):
        return float(self.q[(ds, m)][k + "_mean"])

    def best_base(self, ds, k):
        return max(BASE, key=lambda m: self.v(ds, m, k))

    def p(self, ds, base, k):
        return self.sig[(ds, base, k)]["p_holm"]


def f3(x):
    return f"{x:.3f}"


def pct(x):
    return f"{100 * x:.0f}%"


def pfmt(p):
    return "< 0.001" if p < 0.001 else f"= {p:.3f}"


def ratio(a, b):
    r = a / b
    return f"{r:.0f}" if r >= 10 else f"{r:.1f}"


# ------------------------------------------------------------------ data-driven text
def sig_all(C, ds, k):
    """ours significantly better than every other method (incl. random) on metric k."""
    return all(C.sig[(ds, m, k)]["direction"] == "Ours better" for m in METHODS if m != "ours")


def abstract(C):
    ie, cc = "ieee", "creditcard"
    assert sig_all(C, ie, "disc_power") and sig_all(C, cc, "disc_power"), "abstract claim no longer holds"
    t = {m: C.comp[m]["avg_seconds"] for m in C.comp}
    fl_b = max(C.v(ie, m, "flip") for m in BASE)
    n_t = sum(C.meta[d]["targets"] for d in DS)
    npr = C.abl[(ie, "no_pruning")]
    return (
        "Graph Neural Networks (GNNs) detect financial fraud well by exploiting relational patterns among transactions, "
        "but their black-box nature limits adoption in regulated institutions that must justify each decision. This study "
        "proposes a post-hoc explainability model for GNN-based fraud detectors built on a contrastive method of difference. "
        "Each flagged transaction is compared with its nearest legitimate counterparts in the model's embedding space, and "
        "every node, feature and message of its computation subgraph is scored by how much the fraud score would fall if "
        "that element were switched to its legitimate counterpart. Contrastive gradient attribution, an ensemble over the "
        "nearest references and fidelity-constrained pruning yield a small explanation subgraph and feature mask. We "
        "explained GraphSAGE, GCN and GAT detectors trained on strictly time-ordered transaction graphs of three public "
        f"datasets (IEEE-CIS, ULB Credit Card and PaySim; {n_t} correctly detected test-period frauds for the main model) "
        "and compared the framework with GNNExplainer, PGExplainer, SubgraphX, Grad-CAM and a random baseline at equal "
        "explanation size. On IEEE-CIS and Credit Card, our explanations had significantly higher discriminative power and "
        "necessity than every baseline (Holm-corrected Wilcoxon tests): switching the explanation to its legitimate "
        f"counterpart lowered the fraud probability by {f3(C.v(ie, 'ours', 'disc_power'))} and "
        f"{f3(C.v(cc, 'ours', 'disc_power'))} on average and, on IEEE-CIS, flipped {pct(C.v(ie, 'ours', 'flip'))} of "
        f"decisions to legitimate, against at most {pct(fl_b)} for the baselines. On PaySim, where detected frauds have "
        "almost no transaction history, all methods performed alike. Fidelity was at least "
        f"{math.floor(100 * min(C.v(d, 'ours', 'fidelity') for d in DS)) / 100:.2f} on every dataset. An explanation took {t['ours']:.2f} s on a "
        f"T4 GPU (GNNExplainer {t['gnnexplainer']:.2f} s, SubgraphX {t['subgraphx']:.2f} s), and a variant without "
        f"pruning reached the same discriminative power in {npr['seconds_mean']:.3f} s. Ablations identify the signed "
        "contrast with legitimate references as the decisive component. A case study shows that the explanations point "
        "investigators to concrete evidence, such as bursts of identical charges on a shared card and device. The "
        "framework is model-agnostic and requires no retraining.")


def contributions(C):
    return [
        ("Theoretical Framework: ", "We formalize contrastive explanation for GNN-based fraud detection as a constrained "
         "optimization that balances fidelity, sparsity and contrastiveness, and operationalize Mill's method of "
         "difference by comparing each element of a flagged transaction's computation subgraph with its counterpart in "
         "the nearest legitimate transactions (hop-matched features and messages)."),
        ("Algorithmic Development: ", "We derive a contrastive gradient attribution that estimates, for every node, "
         "feature and message, the drop in the fraud score when that element is switched to its legitimate counterpart, "
         "and combine it with reference ensembling and fidelity-constrained pruning. The method works with any "
         "message-passing GNN, needs one backward pass per transaction and no retraining."),
        ("Empirical Validation: ", "We explain GraphSAGE, GCN and GAT detectors on three public fraud datasets and "
         "compare against GNNExplainer, PGExplainer, SubgraphX, Grad-CAM and a random baseline at equal explanation size, "
         "with paired significance tests, stability tests, ablations, sensitivity and scalability analyses and a case "
         "study. Code, trained models and per-transaction results are released."),
    ]


def quality_text(C):
    cc, ie, ps = "creditcard", "ieee", "paysim"
    assert sig_all(C, ie, "disc_power") and sig_all(C, ie, "fid_plus") and sig_all(C, ie, "fidelity")
    assert sig_all(C, cc, "disc_power") and sig_all(C, cc, "fid_plus")
    bi = C.best_base(ie, "disc_power")
    bc = C.best_base(cc, "disc_power")
    cc_fid_worse = [MN[m] for m in BASE if C.sig[(cc, m, "fidelity")]["direction"] == "Baseline better"]
    ps_sig = [MN[m] for m in METHODS if m != "ours" and C.sig[(ps, m, "disc_power")]["direction"] == "Ours better"]
    return (
        "On IEEE-CIS, our explanations were significantly better than those of every baseline on all three faithfulness "
        f"measures (Table 3; Appendix Table A3): discriminative power {f3(C.v(ie, 'ours', 'disc_power'))} against "
        f"{f3(C.v(ie, bi, 'disc_power'))} for the strongest baseline ({MN[bi]}), necessity "
        f"{f3(C.v(ie, 'ours', 'fid_plus'))} against at most {f3(max(C.v(ie, m, 'fid_plus') for m in BASE))}, and fidelity "
        f"{f3(C.v(ie, 'ours', 'fidelity'))} against at most {f3(max(C.v(ie, m, 'fidelity') for m in BASE))} (all "
        "Holm-adjusted p < 0.001). Switching our explanation to its legitimate counterpart flipped "
        f"{pct(C.v(ie, 'ours', 'flip'))} of the decisions to legitimate, against "
        f"{pct(min(C.v(ie, m, 'flip') for m in BASE))}–{pct(max(C.v(ie, m, 'flip') for m in BASE))} for the baselines. "
        f"On Credit Card, discriminative power ({f3(C.v(cc, 'ours', 'disc_power'))} against "
        f"{f3(C.v(cc, bc, 'disc_power'))} for {MN[bc]}) and necessity ({f3(C.v(cc, 'ours', 'fid_plus'))} against "
        f"{f3(C.v(cc, C.best_base(cc, 'fid_plus'), 'fid_plus'))}) were again significantly higher than for every baseline, "
        f"whereas fidelity was slightly lower ({f3(C.v(cc, 'ours', 'fidelity'))} against "
        f"{f3(C.v(cc, C.best_base(cc, 'fidelity'), 'fidelity'))}; significantly lower than "
        f"{' and '.join(cc_fid_worse)}): the contrastive explanation keeps the elements that separate the fraud from its "
        "legitimate counterpart, not every element that supports the score. On PaySim all methods performed alike "
        f"(discriminative power {min(C.v(ps, m, 'disc_power') for m in METHODS):.3f}–"
        f"{max(C.v(ps, m, 'disc_power') for m in METHODS):.3f}; ours significantly higher only than "
        f"{' and '.join(ps_sig) if ps_sig else 'none'}). Because every method has the same explanation size, the random "
        "baseline shows how much of each score is due to size alone.")


def paysim_note(C):
    m = C.meta["paysim"]
    return (f"PaySim deserves a comment. Only {m['targets']} of the {m['test_true_positives']} frauds correctly detected "
            "by GraphSAGE in the test period have any earlier linked transaction (median computation subgraph: "
            f"{m['median_nodes']:.0f} nodes), because most fraudulent transfers come from accounts with no earlier "
            "activity. The detector therefore relies almost entirely on the target transaction's own features, removing "
            "edges barely changes its output (necessity close to zero for every method), and structural explanations "
            "can add little; the feature-level explanation remains informative (Section 4.3).")


def stability_text(C):
    o = {d: C.st[(d, "ours")] for d in DS}
    g = {d: C.st[(d, "gnnexplainer")] for d in DS}
    best_ie = max((m for m in METHODS), key=lambda m: C.st[("ieee", m)]["jaccard_mean"])
    return (f"Our explanations were the most stable on Credit Card (Jaccard {f3(o['creditcard']['jaccard_mean'])}) and "
            f"PaySim ({f3(o['paysim']['jaccard_mean'])}). On IEEE-CIS, where the computation subgraphs are larger and "
            f"more varied, {MN[best_ie]} was more stable in Jaccard terms ({f3(C.st[('ieee', best_ie)]['jaccard_mean'])} "
            f"against {f3(o['ieee']['jaccard_mean'])}), although the rank correlation of our edge scores remained "
            f"{f3(o['ieee']['spearman_mean'])}: small perturbations re-order nearly tied edges at the budget boundary "
            "rather than change the ranking. GNNExplainer, whose mask optimization starts from a random initialization, "
            f"was the least stable non-random method (Jaccard {f3(g['creditcard']['jaccard_mean'])}, "
            f"{f3(g['ieee']['jaccard_mean'])} and {f3(g['paysim']['jaccard_mean'])}).")


def arch_text(C):
    A = {(r["ds"], r["model"], r["method"]): r for r in C.S["arch"]}
    combos = [(d, m) for d in DS for m in ("gcn", "gat") if (d, m, "ours") in A]
    wins = [(d, m) for d, m in combos
            if A[(d, m, "ours")]["disc_power_mean"] >= max(A[(d, m, b)]["disc_power_mean"] for b in BASE)]
    lost = ""
    for d, m in [c for c in combos if c not in wins]:
        b = max(BASE, key=lambda x: A[(d, m, x)]["disc_power_mean"])
        lost += (f" On {DN[d]} with {m.upper()}, {MN[b]} was marginally higher "
                 f"({f3(A[(d, m, b)]['disc_power_mean'])} against {f3(A[(d, m, 'ours')]['disc_power_mean'])}).")
    nec = sum(A[(d, m, "ours")]["fid_plus_mean"] >= max(A[(d, m, b)]["fid_plus_mean"] for b in BASE) for d, m in combos)
    return ("To test whether the explainer depends on the architecture, we repeated the comparison on the GCN and GAT "
            "detectors without changing any setting (Table 5). Our explanations had the highest discriminative power in "
            f"{len(wins)} of the {len(combos)} model–dataset combinations and the highest necessity in {nec}." + lost +
            " PaySim is not included: none of the frauds detected by GCN or GAT on PaySim has an earlier linked "
            "transaction, so their computation subgraphs contain no edges to explain.")


def ablation_text(C):
    def a(ds, v, k="disc_power"):
        return C.abl[(ds, v)][k + "_mean"]

    def ph(ds, v):
        return C.abl[(ds, v)].get("p_dp_holm", 1.0)

    ie, cc = "ieee", "creditcard"
    return (
        "Using absolute instead of signed contributions reduced discriminative power significantly on every dataset "
        f"(on IEEE-CIS {f3(a(ie, 'full'))} → {f3(a(ie, 'unsigned'))}, flip rate {pct(a(ie, 'full', 'flip'))} → "
        f"{pct(a(ie, 'unsigned', 'flip'))}; on Credit Card {f3(a(cc, 'full'))} → {f3(a(cc, 'unsigned'))}; p < 0.001): an "
        "explanation of why a transaction is fraud must exclude elements that argue for legitimacy. On IEEE-CIS and "
        "Credit Card, random scores and dropping the size constraint (which yields very small explanations) also reduced "
        "discriminative power significantly. Replacing the legitimate references by the training mean reduced discriminative power and the "
        f"flip rate on IEEE-CIS ({f3(a(ie, 'no_contrast'))}, {pct(a(ie, 'no_contrast', 'flip'))}; p "
        f"{pfmt(ph(ie, 'no_contrast'))}), and a single reference instead of three had a similar effect "
        f"({f3(a(ie, 'no_ensemble'))}; p {pfmt(ph(ie, 'no_ensemble'))}); on Credit Card and PaySim neither change made a "
        "significant difference. Exact "
        f"one-at-a-time switches gave the same results as the gradient estimate (IEEE-CIS {f3(a(ie, 'exact'))}; p "
        f"{pfmt(ph(ie, 'exact'))}), confirming the first-order approximation. Finally, skipping the pruning and taking "
        f"the top-scored elements directly gave comparable discriminative power ({f3(a(ie, 'no_pruning'))} on IEEE-CIS) "
        f"in {C.abl[(ie, 'no_pruning')]['seconds_mean']:.3f} s instead of {C.abl[(ie, 'full')]['seconds_mean']:.2f} s; "
        "the pruning step mainly guarantees that the explanation alone reproduces the prediction (fidelity "
        f"{f3(a(ie, 'full', 'fidelity'))} against {f3(a(ie, 'no_pruning', 'fidelity'))} on IEEE-CIS and "
        f"{f3(a('paysim', 'full', 'fidelity'))} against {f3(a('paysim', 'no_pruning', 'fidelity'))} on PaySim).")


def efficiency_text(C):
    o, g, s = (C.comp[m] for m in ("ours", "gnnexplainer", "subgraphx"))
    pgt = C.S["pg_train_seconds"]
    sc = {(r["method"], r["hops"]): r for r in C.S["scalability"]}
    return (f"Our explainer needed {o['avg_seconds']:.2f} s per transaction on average (median {o['median_seconds']:.2f} s), "
            f"against {g['avg_seconds']:.2f} s for GNNExplainer and {s['avg_seconds']:.2f} s for SubgraphX, and needed less "
            f"than {math.ceil(o['mem_mb_max'])} MB of GPU memory in addition to the trained model and graph. Grad-CAM, PGExplainer and the random baseline need a single "
            "forward or backward pass and are faster at inference, but PGExplainer must first be trained "
            f"({', '.join(f'{v:.0f} s on {DN[d]}' for d, v in pgt.items())}) and both gave markedly less discriminative "
            "explanations (Table 3). Nearly all of our time is spent in the greedy pruning, one forward pass per candidate "
            "element; the attribution itself costs one backward pass, and the pruning-free variant takes about 0.01 s "
            "(Table 6). As the explained neighborhood grows from 2 to 4 hops (on average "
            f"{sc[('ours', 2)]['n']:.0f} to {sc[('ours', 4)]['n']:.0f} nodes), our time rises from "
            f"{sc[('ours', 2)]['seconds']:.2f} s to {sc[('ours', 4)]['seconds']:.2f} s and SubgraphX's from "
            f"{sc[('subgraphx', 2)]['seconds']:.2f} s to {sc[('subgraphx', 4)]['seconds']:.2f} s, while GNNExplainer, "
            f"which runs a fixed number of optimization steps, stays near {sc[('gnnexplainer', 4)]['seconds']:.2f} s "
            "(Figure 5).")


def feature_text(C):
    F = {(r["Dataset"], r["Method"]): r for r in C.S["features"]}
    fid = "; ".join(f"{DN[d]} {F[(DN[d], 'Ours')]['feat_fidelity_mean']:.3f} against "
                    f"{F[(DN[d], 'GNNExplainer')]['feat_fidelity_mean']:.3f}" for d in DS)
    nec = "; ".join(f"{DN[d]} {F[(DN[d], 'Ours')]['feat_fid_plus_mean']:.3f} against "
                    f"{F[(DN[d], 'GNNExplainer')]['feat_fid_plus_mean']:.3f}" for d in DS)
    return ("Feature-level explanations. Keeping only the 20% of features with the highest contrastive scores (the "
            "others set to their training mean) preserved the prediction better than keeping the top 20% of "
            f"GNNExplainer's feature mask on every dataset (feature fidelity {fid}), and removing them lowered the fraud "
            f"probability more (feature necessity {nec}).")


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="full")
    ap.add_argument("--out", default=None)
    ap.add_argument("--env", default="PyTorch 2.11.0 (CUDA 13.0) and PyTorch Geometric 2.8.1")
    args = ap.parse_args()
    sfx = "" if args.profile == "full" else f"_{args.profile}"
    tdir, fdir = os.path.join(ROOT, "tables" + sfx), os.path.join(ROOT, "figures" + sfx)
    S = json.load(open(os.path.join(tdir, "summary.json")))
    case = json.load(open(os.path.join(tdir, "case_study.json")))
    C = Ctx(S, case, fdir, args.profile)
    out = args.out or os.path.join(os.path.dirname(ROOT), "For Tosin - Explainability",
                                   "Explainability manuscript - FINAL.docx" if args.profile == "full"
                                   else f"Explainability manuscript - {args.profile.upper()} PREVIEW.docx")
    os.makedirs(os.path.dirname(out), exist_ok=True)

    d = docx.Document(SRC)
    pars = list(d.paragraphs)

    def P(prefix, nth=0):
        hits = [p for p in pars if p.text.strip().startswith(prefix)]
        if len(hits) <= nth:
            raise KeyError(prefix)
        return hits[nth]

    # ---- capture every paragraph we touch BEFORE text normalisation (prefixes match the draft)
    K = {}
    for key, prefix in {
        "title": "A PostHoc Financial Fraud", "abstract": "Graph Neural Networks (GNNs) have demonstrated",
        "intro1": "Financial fraud represents", "intro2": "GNNs achieve", "ce1": "Contrastive explanation explaining",
        "contrib_lead": "The key contributions", "c1": "Theoretical Framework:", "c2": "Algorithmic Development:",
        "c3": "Empirical Validation:", "org": "The remainder of this paper", "lit2": "In financial fraud detection, GNNs",
        "lit3": "Despite these advances", "grad": "GradientBased Methods", "contrastg": "Contrastive Explanation for Graphs",
        "mod": "Method of Difference: Mill", "gap": "Our review identifies three", "gapfix": "Our model addresses these gaps",
        "frame": "Our framework consists of four", "fig1cap": "[Figure 1:", "comp1": "For each target fraudulent instance",
        "cos": "We use cosine similarity", "comp2": "We compute gradientbased importance", "foreach": "For each node v",
        "foredge": "For each edge e", "forfeat": "For feature dimensions", "cgx": "CG_x^k", "capture": "These gradients capture",
        "prune_intro": "To generate sparse explanations", "tau": "The threshold τ controls", "stab1": "To address explanation instability",
        "stab2": "For a target instance Gᵢ, we select", "stab3": "This ensemble approach", "time": "For typical financial transaction",
        "hyper": "We set default hyperparameters", "hyper2": "These values balance", "integ": "Our framework operates as a",
        "integ2": "The modular design enables", "ds_intro": "We evaluated our framework on three", "ccf": "Dataset 1: Credit Card",
        "ieeeds": "Dataset 2: IEEE_CIS", "paysim": "Dataset 3: PaySIM", "split": "All datasets were split",
        "t1cap": "[Table 1:", "gnn_intro": "We trained three stateoftheart", "gcn": "Graph Convolutional Network (GCN)",
        "gat": "Graph Attention Network (GAT)", "sage": "GraphSAGE (Hamilton", "train": "Models were trained using Adam",
        "t2cap": "[Table 2:", "xb_intro": "We compared our framework against four", "b_gnn": "GNNExplainer (Ying",
        "b_pg": "PGExplainer (Luo", "b_sx": "SubgraphX (Yuan", "b_gc": "GradCAM (Selvaraju", "b_all": "All baselines were implemented",
        "met_intro": "We assessed explanation quality", "qm": "Quantitative Metrics:", "fid_lab": "Fidelity: Measures how well",
        "fid_hi": "Higher values indicate better fidelity", "sp_lab": "Sparsity: Measures explanation", "sta_lab": "Stability: Measures consistency",
        "dp_lab": "Discriminative Power: Measures", "human": "Human Evaluation: We recruited", "t3cap": "[Table 3:",
        "t3note": "Note: Values represent mean ± standard deviation across test", "fig2": "[Figure 2:",
        "tr_text": "A critical consideration for practical", "fig3": "[Figure 3:", "stab_text": "Explanation stability is crucial",
        "t4cap": "[Table 4:", "abl_text": "To validate design choices", "t5cap": "[Table 5:", "keyf": "Key findings:",
        "he_text": "Financial analysts’ ratings", "t6cap": "[Table 6:", "t6note": "Note: Values represent mean ± standard deviation across 12",
        "fig4": "[Figure 4:", "cs_intro": "We present three representative", "cs_head": "Case Study 1:", "cs1": "A fraudulent transaction (ID",
        "cs2": "Contrastive explanation highlighted", "cs3": "The nearest legitimate neighbor (similarity", "fig5": "[Figure 5:",
        "eff1": "Production deployment requires", "t7cap": "[Table 7:", "eff2": "Our framework achieves a favorable",
        "fig6": "[Figure 6:", "find": "This study introduced a novel", "stabth": "Stability Through Ensemble",
        "trust": "Trust and Adoption:", "lim_ref": "Reference Selection Sensitivity", "lim_ds": "Dataset Specific Evaluation",
        "fut_int": "Interactive Explanation Refinement", "concl2": "Comprehensive evaluation on three", "concl3": "The contrastive approach addresses",
        "concl4": "Future work will extend", "refs_first": "Abdallah, A., Maarof", "figA1": "[Figure A1:", "figA2": "[Figure A2:",
        "tA1cap": "[Table A1:", "tA2cap": "[Table A2:", "alg3": "def generate_contrastive_explanation", "soft": "Software and Hardware",
        "ack": "We thank the financial institutions", "authc": "Author Contributions", "dav": "Data Availability",
        "rq": "Regulatory Compliance:", "concl1": "This paper presented a novel",
        "mdnn": "Method of Difference for Neural Networks", "emb": "Embedding Space Assumptions",
        "cfx": "Counterfactual Explanation: Counterfactual", "proposes": "This paper proposes a novel",
        "maskop": "where ⊙ denotes masking", "alg2": "Input: Gᵢ, Gⱼ, f, contrastive",
    }.items():
        K[key] = P(prefix)
    heads = {p.text.strip(): p for p in pars if p.style.name.startswith("Heading")}
    eq = {"cgv": P("For each node v")._p.getnext(), "cge": P("For each edge e")._p.getnext()}
    dp_eq = P("Discriminative Power: Measures")._p.getnext()
    T = list(d.tables)
    refs = [p for p in pars[pars.index(P("Abdallah, A., Maarof")):pars.index(P("Zhou, J., Cui, G.")) + 1]]

    # ---- 1. make all text black and restore lost hyphens
    for p in d.paragraphs + [c.paragraphs[0] for t in T for r in t.rows for c in r.cells]:
        for r in p._p.iter(qn("w:r")):
            t = r.find(qn("w:t"))
            if t is not None and t.text:
                s = t.text
                for a, b in HYPHEN.items():
                    s = re.sub(rf"(?<![\w-]){re.escape(a)}(?![\w])", b, s)
                t.text = s

    def ST(key, text, bold=None):
        set_text(K[key], text, bold_label=bold)

    def after(par, text, like=None, bold=None, align=None, size=None):
        p = new_par_after(par._p, like=like or par, text="")
        set_text(p, text, bold_label=bold, size=size)
        if align is not None:
            p.alignment = align
        return p

    # ---- 2. title, headings
    ST("title", "A Post-Hoc Financial Fraud Explainability Model for Graph Neural Networks via Contrastive Method of "
                "Difference")
    renum = {"Background and Motivation": "1.1 Background and Motivation",
             "The Explainability Challenge in Financial Contexts": "1.2 The Explainability Challenge in Financial Contexts",
             "Contrastive Explanation as a Solution Paradigm": "1.3 Contrastive Explanation as a Solution Paradigm",
             "Research Objectives and Contributions": "1.4 Research Objectives and Contributions",
             "Paper Organization": "1.5 Paper Organization",
             "PostHoc Explainability Methods for GNNs": "2.2 Post-Hoc Explainability Methods for GNNs",
             "Contrastive and Counterfactual Explanation Methods": "2.3 Contrastive and Counterfactual Explanation Methods",
             "Research Gap Analysis": "2.4 Research Gap Analysis", "Problem Formalization": "3.1 Problem Formalization",
             "Proposed Framework Architecture": "3.2 Proposed Framework Architecture",
             "Implementation Details": "3.3 Implementation Details", "Results": "4.0 Results",
             "Experimental Setup": "4.1 Experimental Setup", "Quantitative Results": "4.2 Quantitative Results",
             "Ablation Studies": "4.3 Ablation Studies", "Case Study Analysis": "4.4 Case Study Analysis",
             "Computational Efficiency Analysis": "4.5 Computational Efficiency Analysis", "Discussion": "5.0 Discussion",
             "Principal Findings": "5.1 Principal Findings", "Theoretical Implications": "5.2 Theoretical Implications",
             "Practical Implications for Financial Institutions": "5.3 Practical Implications for Financial Institutions",
             "Limitations and Boundary Conditions": "5.4 Limitations and Boundary Conditions",
             "Future Research Directions": "5.5 Future Research Directions",
             "Broader Impact Considerations": "5.6 Broader Impact Considerations", "Conclusion": "6.0 Conclusion",
             "GNNBased Fraud Detection Model": "GNN-Based Fraud Detection Model",
             "FidelitySparsity Tradeoff Analysis": "Fidelity–Sparsity Trade-off Analysis",
             "Baseline GNN Models": "Explained GNN Models"}
    for old, new in renum.items():
        if old in heads:
            set_text(heads[old], new)

    # ---- 3. abstract, introduction
    ST("abstract", abstract(C))
    ST("intro1", "Financial fraud represents a persistent and evolving threat to economic stability: organizations are "
                 "estimated to lose about 5% of their revenue to fraud every year (Association of Certified Fraud "
                 "Examiners, 2024). Traditional rule-based fraud detection systems struggle to adapt to sophisticated "
                 "schemes that exploit complex relational patterns across transaction networks (Abdallah et al., 2016; "
                 "Hilal et al., 2022). Machine learning approaches, particularly Graph Neural Networks (GNNs), have emerged "
                 "as powerful tools for modeling the inherent graph structure of financial transactions, capturing both "
                 "node attributes and topological relationships (Liu et al., 2021; Weber et al., 2019).")
    ST("intro2", "GNNs achieve state-of-the-art performance in fraud detection by aggregating information from neighboring "
                 "nodes through message-passing mechanisms, enabling the identification of collusive fraud rings, money "
                 "laundering networks and coordinated attack patterns (Wang et al., 2019; Dou et al., 2020). However, the "
                 "multi-layer aggregation process creates complex non-linear transformations that obscure the "
                 "decision-making rationale, rendering these models “black boxes” (Ying et al., 2019). This opacity poses "
                 "significant challenges for deployment in regulated financial environments where model decisions must be "
                 "auditable, contestable and aligned with legal frameworks such as the European Union’s General Data "
                 "Protection Regulation (GDPR) and the United States’ Fair Credit Reporting Act (FCRA) (Goodman & Flaxman, "
                 "2017; Wachter et al., 2017).")
    ST("ce1", "Contrastive explanation, which explains why a prediction is class A rather than class B, aligns with human "
              "cognitive processes and provides actionable insights by highlighting discriminative features (Miller, 2019; "
              "Stepin et al., 2021). In the context of financial fraud, contrastive explanations answer: “What makes this "
              "transaction fraudulent rather than legitimate?” This formulation naturally focuses on the minimal set of "
              "features and relationships that distinguish fraud from normal behavior, producing sparse and interpretable "
              "explanations.")
    ST("contrib_lead", "The key contributions of this research are threefold:")
    for key, (lab, txt) in zip(("c1", "c2", "c3"), contributions(C)):
        ST(key, lab + txt, bold=lab)
    ST("org", "The remainder of this paper is organized as follows. Section 2 reviews related work on GNN-based fraud "
              "detection, GNN explainability and contrastive explanation. Section 3 formalizes the problem and presents the "
              "proposed framework and its implementation. Section 4 describes the experimental setup and reports the "
              "quantitative comparison, stability, ablation, case-study and efficiency results. Section 5 discusses "
              "implications, limitations and future research directions, and Section 6 concludes the paper.")

    # ---- 4. literature review
    ST("lit2", "In financial fraud detection, GNNs leverage transaction networks where nodes represent entities "
               "(accounts, customers, merchants) or transactions and edges represent relationships (transfers, shared "
               "attributes, social connections) (Liu et al., 2021). Weber et al. (2019) applied graph convolutional networks "
               "to anti-money laundering on the Elliptic Bitcoin transaction graph and showed that graph-derived "
               "representations add information beyond tabular features. Wang et al. (2019) proposed SemiGNN, a "
               "semi-supervised attentive network over a heterogeneous multi-view graph for financial fraud detection, and "
               "Dou et al. (2020) made GNN fraud detectors robust to fraudsters who camouflage their features and "
               "relations. Temporal graph networks extend these models to evolving transaction streams (Rossi et al., 2020).")
    ST("lit3", "Despite these advances, the interpretability gap remains a critical barrier to adoption. Financial "
               "institutions require not only accurate predictions but also transparent reasoning that can be validated "
               "against regulatory requirements and domain expertise (Bussmann et al., 2021).")
    g = K["grad"]
    g.runs[-1].text = g.runs[-1].text.rstrip() + (" Attention weights of attention-based GNNs are sometimes read as "
                                                    "explanations as well, but they need not reflect what drives a "
                                                    "prediction (Jain & Wallace, 2019).")
    ST("contrastg", "Contrastive Explanation for Graphs: Recent work has begun exploring contrastive and counterfactual "
                    "approaches for graph data. Tan et al. (2022) combined counterfactual and factual reasoning to learn and "
                    "evaluate GNN explanations, and Bajaj et al. (2021) proposed RCExplainer, which derives robust "
                    "counterfactual explanations from the decision regions of a GNN. Lucic et al. (2022) search for minimal "
                    "edge deletions that flip a GNN prediction. However, these methods do not address the specific "
                    "challenges of financial fraud detection, including extreme class imbalance, time-ordered transaction "
                    "graphs and regulatory requirements.", bold="Contrastive Explanation for Graphs:")
    ST("mod", "Method of Difference: Mill’s (1843) method of difference, a foundational principle of causal inference, "
              "states that if an outcome occurs when a factor is present and does not occur when it is absent (holding all "
              "else constant), that factor is causally related to the outcome. We adapt this principle to GNN explanations "
              "by contrasting fraudulent transactions with their nearest legitimate counterparts, isolating discriminative "
              "patterns. Reference-based attribution methods such as DeepLIFT (Shrikumar et al., 2017) and Integrated "
              "Gradients (Sundararajan et al., 2017) also explain a prediction relative to a baseline input; our framework "
              "differs in choosing the baseline as the nearest legitimate transactions in the model's own embedding space, "
              "in matching the two computation subgraphs hop by hop, and in applying the comparison to messages as well as "
              "features.", bold="Method of Difference:")
    ST("gap", "Our review identifies two critical gaps in the current literature:")
    ST("gapfix", "Our model addresses these gaps by (1) formalizing contrastive GNN explanation as a method-of-difference "
                 "optimization problem, (2) developing an efficient gradient-based algorithm that compares every element of "
                 "a flagged transaction's computation subgraph with its counterpart in the nearest legitimate transactions, "
                 "and (3) evaluating it on three financial fraud datasets against four established explainers.")

    # ---- 5. methodology
    ST("frame", "Our framework consists of four main components (Figure 1):")
    K["fig1cap"].alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_text(K["fig1cap"], "Figure 1: Overview of the contrastive method-of-difference explainer: (1) extraction of the "
                           "target's computation subgraph, (2) selection of the nearest legitimate references in the "
                           "embedding space, (3) contrastive gradient attribution and scoring, (4) fidelity-constrained "
                           "pruning and explanation generation.", italic=True, size=9)
    ST("comp1", "For each target fraudulent transaction with computation subgraph Gᵢ, we identify a reference set of "
                "legitimate transactions that are similar in the model's representation space but classified differently. "
                "The pool L consists of legitimate transactions from the validation period that the model classifies as "
                "legitimate (2,000 sampled per dataset); because the validation period precedes the test period, a "
                "reference never comes from the target's future. This ensures meaningful contrastive comparisons.")
    ST("cos", "We use cosine similarity in the final message-passing layer (l = L), i.e. the representation the "
              "classifier head receives, as this layer captures the high-level semantics the decision is based on. Because "
              "the target and a reference have different neighborhoods, we match their elements by hop distance: the "
              "counterpart of the target node is the reference transaction itself, and the counterpart of a node at hop h "
              "is the average of the reference's nodes at hop h. This gives a legitimate counterpart x̃ᵥ for every node "
              "feature vector and m̃ₑ⁽ˡ⁾ for every message sent along an edge e in layer l.")
    ST("comp2", "We compute gradient-based importance scores that estimate how much the fraud score would fall if an "
                "element of Gᵢ were switched to its legitimate counterpart. Since f(Gⱼ) does not depend on Gᵢ, the "
                "gradient of the difference f(Gᵢ) − f(Gⱼ) equals the gradient of f(Gᵢ); the contrast therefore enters "
                "through the difference between each element and its counterpart, giving a first-order (Taylor) estimate "
                "of f(Gᵢ) − f(Gᵢ with the element switched). We use the pre-sigmoid fraud logit f to avoid gradient "
                "saturation and keep only positive contributions, i.e. evidence for fraud rather than legitimacy.")
    ST("foreach", "For each node v ∈ Vᵢ, the contrastive node score is:")
    for key, text_ in (("cgv", "CG_v = max(0, Σₖ ∂f(Gᵢ)/∂x_v^k · (x_v^k − x̃_v^k))"),
                       ("cge", "CG_e = max(0, Σₗ ⟨∂f(Gᵢ)/∂mₑ⁽ˡ⁾, mₑ⁽ˡ⁾ − m̃ₑ⁽ˡ⁾⟩)")):
        el = eq[key]
        from docx.text.paragraph import Paragraph
        ep = Paragraph(el, K["foreach"]._parent)
        newp = after(ep, text_, like=K["cgx"], align=WD_ALIGN_PARAGRAPH.CENTER)
        remove(el)
        eq[key] = newp
    ST("foredge", "For each edge e = (u → v) ∈ Eᵢ, we compare the message mₑ⁽ˡ⁾ that u sends to v in every layer l with "
                  "the message m̃ₑ⁽ˡ⁾ sent by the reference's nodes at the same hop (the reference does not contain the "
                  "edge itself):")
    ST("forfeat", "For feature dimensions, we compute:")
    set_text(K["cgx"], "CG_x^k = max(0, Σ_{v∈Vᵢ} ∂f(Gᵢ)/∂x_v^k · (x_v^k − x̃_v^k))")
    K["cgx"].alignment = WD_ALIGN_PARAGRAPH.CENTER
    ST("capture", "All three scores need a single backward pass through the trained model. Setting x̃ = 0 (the training "
                  "mean of the standardized features) and m̃ = 0 removes the contrast and reduces the scores to plain "
                  "gradient × input, which we use as an ablation; replacing the first-order estimate by re-running the "
                  "model for every switched element gives the exact method-of-difference scores, which we use to check the "
                  "approximation.")
    ST("tau", "The threshold τ controls the fidelity–sparsity trade-off, ensuring that the explanation keeps the model's "
              "prediction while minimizing size. Scores of each element type are normalized by their maximum before "
              "ranking, the target node is never removed, and |Gₛ| counts the explanation's nodes and edges, with "
              "k = ⌈k_frac · (|Vᵢ| + |Eᵢ|)⌉.")
    ST("stab1", "To address explanation instability, we employ ensemble averaging over multiple legitimate references.")
    ST("stab2", "For a target instance Gᵢ, we select the top-m nearest legitimate references {Gⱼ₁, …, Gⱼₘ}, compute the "
                "contrastive scores against each of them, and average the (max-normalized) scores before pruning:")
    ST("time", f"In our experiments the computation subgraphs of the explained frauds contain "
               f"{', '.join(f'{C.meta[x]['median_nodes']:.0f} ({DN[x]})' for x in DS)} nodes at the median, and one "
               f"explanation takes {C.comp['ours']['avg_seconds']:.2f} s on average on a single T4 GPU (Section 4.5), "
               "which is suitable for interactive investigation workflows.")
    ST("hyper", "Default hyperparameters: fidelity threshold τ = 0.05, ensemble size m = 3, sparsity budget "
                "k_frac = 20% of the subgraph's nodes plus edges, and a reference pool of 2,000 legitimate validation "
                "transactions. Algorithm 2 solves the optimization of Section 3.1 in its constrained form (maximize "
                "sparsity subject to a fidelity loss below τ and a size of at least k), so the weights α, β and γ do not "
                "need to be tuned.")
    ST("hyper2", "Their sensitivity is analyzed in Appendix A (Figure A1): the results are robust to τ and m, while "
                 "the budget k trades sparsity for discriminative power.")
    ST("integ", "Our framework operates as a post-hoc module that interfaces with any trained message-passing GNN. It "
                "requires the trained parameters, gradients of the model output with respect to node features and to the "
                "messages of each layer (obtained by automatic differentiation), and a set of legitimate reference "
                "transactions. For the GCN, GraphSAGE and GAT detectors studied here we implement this with a functional "
                "forward pass that reuses the trained weights and reproduces the original predictions exactly (maximum "
                "difference below 10⁻⁴ on every dataset).")

    # ---- 6. experimental setup
    st = {r["Dataset"]: r for r in S["datasets"]}
    ST("ds_intro", "We evaluated our framework on three public financial fraud datasets (two real-world, one simulated) "
                   "representing diverse fraud scenarios. In every dataset, nodes are transactions in time order and edges "
                   "link a transaction to earlier transactions that share an entity, pointing from the earlier to the later "
                   "transaction, so that a transaction only receives information from its past:")
    cc, ie, ps = st["CCF"], st["IEEE-CIS"], st["PaySim"]
    ST("ccf", f"Dataset 1: Credit Card Fraud (CCF). Source: European cardholders, September 2013 (Dal Pozzolo et al., "
              f"2015). Transactions: {cc['Transactions']:,}; fraud rate: {cc['Fraud rate (%)']:.3f}%. Features: 28 "
              f"anonymized PCA components, log amount and the hour of day (sine/cosine), {cc['Features']} in total. Graph "
              "construction: the data contain no card or merchant identifiers, so each transaction is linked to the "
              "three preceding transactions (temporal adjacency) and to its five most similar earlier transactions in "
              f"the PCA feature space. Average node degree: {cc['Avg. degree']:.1f}.", bold="Dataset 1: Credit Card Fraud (CCF).")
    ST("ieeeds", f"Dataset 2: IEEE-CIS. Source: Vesta Corporation e-commerce transactions (IEEE Computational Intelligence "
                 f"Society, 2019). Transactions: {ie['Transactions']:,}; fraud rate: {ie['Fraud rate (%)']:.2f}%. Features: "
                 f"{ie['Features']} numeric features from the transaction and identity tables (amount, time of day, "
                 "distances, the C, D and M fields, low-missingness V fields, product, card and device type, e-mail domain); "
                 "identifiers are used only to build edges, never as features. Graph construction: three relations link a "
                 "transaction to the three preceding transactions with the same card (card1–card6), the same billing "
                 "address and purchaser e-mail domain, and the same device (device information and browser/OS fields). "
                 f"Average node degree: {ie['Avg. degree']:.1f}.", bold="Dataset 2: IEEE-CIS.")
    ST("paysim", f"Dataset 3: PaySim. Source: mobile-money simulator calibrated on real logs of an African mobile-money "
                 f"service (Lopez-Rojas et al., 2016). We use the TRANSFER and CASH_OUT transactions, the only types that "
                 f"contain fraud, and keep the earliest {ps['Transactions']:,} of them; fraud rate: "
                 f"{ps['Fraud rate (%)']:.2f}%. Features: log amount, the origin and destination balances before and after "
                 f"the transaction, the transaction type and the hour of day ({ps['Features']} in total). Graph "
                 "construction: transactions are linked to the three preceding transactions of the same origin account and "
                 f"of the same destination account. Average node degree: {ps['Avg. degree']:.1f}.",
       bold="Dataset 3: PaySim.")
    ST("split", "All datasets were split temporally into training (first 60%), validation (next 20%) and test (last 20%) "
                "periods. Feature scaling and every data-driven preprocessing choice use the training period only. "
                "Explanations are computed for correctly detected frauds of the test period.")
    set_text(K["t1cap"], "Table 1: Dataset statistics of the transaction graphs")
    rows = []
    for r in S["datasets"]:
        rows.append([r["Dataset"], f"{r['Transactions']:,}", f"{r['Edges']:,}", r["Features"], f"{r['Frauds']:,}",
                     f"{r['Fraud rate (%)']:.3f}%", f"{r['Avg. degree']:.1f}",
                     {"CCF": "temporal adjacency; feature kNN", "IEEE-CIS": "shared card; address + e-mail; device",
                      "PaySim": "shared origin; shared destination account"}[r["Dataset"]]])
    t = build_table(C_doc := type("D", (), {"d": d})(), ["Dataset", "Transactions (nodes)", "Edges", "Features",
                                                         "Frauds", "Fraud rate", "Avg. degree", "Relations"],
                    rows, T[0].style, size=8)
    booktabs(t, [0.7, 0.85, 0.75, 0.6, 0.55, 0.6, 0.6, 1.85])
    swap_table(T[0], t)

    # explained GNN models
    ST("gnn_intro", "We explain three GNN detectors trained in our earlier work on the same graphs (ten seeds each; the "
                    "seed-0 models are explained). All share an input projection, two message-passing layers with 64 hidden "
                    "units and dropout 0.3, and a two-layer MLP head that outputs a fraud logit:")
    ST("gcn", "Graph Convolutional Network (GCN) (Kipf & Welling, 2017): symmetric-normalized aggregation with self-loops, "
              "ReLU activation.", bold="Graph Convolutional Network (GCN)")
    ST("gat", "Graph Attention Network (GAT) (Veličković et al., 2018): 8 attention heads of 8 units, ELU activation.",
       bold="Graph Attention Network (GAT)")
    ST("sage", "GraphSAGE (Hamilton et al., 2017): mean aggregation with a separate root transform, ReLU activation.",
       bold="GraphSAGE")
    ST("train", "Models were trained full-batch with Adam (learning rate 0.005, weight decay 5 × 10⁻⁴, cosine schedule) "
                "and focal loss (α = 0.75, γ = 2) to address class imbalance (Lin et al., 2017), with early stopping on "
                "validation AUC-PR (patience 30, at most 300 epochs); the decision threshold maximizes F1 on the validation "
                "period. GraphSAGE has the highest AUC-PR of the three on every dataset (Table 2) and is the main model "
                "explained; GCN and GAT are used to test architecture independence (Section 4.2).")
    set_text(K["t2cap"], "Table 2: Test-period performance of the explained GNN detectors (mean ± SD over 10 seeds)")
    rows = []
    for ds in DS:
        for mdl in ["gcn", "sage", "gat"]:
            r = C.perf[(ds, mdl)]
            rows.append([r["Model"], DN[ds], r["roc_auc"], r["pr_auc"], r["precision_at_90_recall"], r["f1"]])
    t = build_table(C_doc, ["Model", "Dataset", "AUC-ROC", "AUC-PR", "Precision@90% Recall", "F1-score"], rows,
                    T[1].style, size=8)
    booktabs(t, [0.9, 0.8, 1.15, 1.15, 1.25, 1.15])
    swap_table(T[1], t)
    p2 = after(K["t2cap"], "", like=K["train"])
    remove(p2._p)

    ST("xb_intro", "We compared our framework against four established GNN explanation methods and a random baseline, "
                   "all adapted to explain the prediction for one target transaction and run on the same model and "
                   "computation subgraph:")
    ST("b_gnn", "GNNExplainer (Ying et al., 2019): learns soft edge and feature masks by maximizing the mutual information "
                "with the prediction (100 epochs, learning rate 0.01, PyTorch Geometric's default regularization).",
       bold="GNNExplainer")
    ST("b_pg", "PGExplainer (Luo et al., 2020): an MLP over the embeddings of an edge's endpoints and of the target "
               "predicts the edge mask; trained once per dataset on up to 300 flagged transactions of the training and "
               "validation periods (30 epochs).", bold="PGExplainer")
    ST("b_sx", "SubgraphX (Yuan et al., 2021): Monte Carlo tree search over connected subgraphs that contain the target, "
               "scored by Monte Carlo Shapley values (20 rollouts, 6 children per expansion, 50 samples).", bold="SubgraphX")
    ST("b_gc", "Grad-CAM (Selvaraju et al., 2017; Pope et al., 2019): gradient-weighted activations of the node "
               "embeddings; an edge receives the mean score of its endpoints.", bold="Grad-CAM")
    rnd = after(K["b_gc"], "Random: random edge scores, a reference for explanations unrelated to the model.",
                bold="Random:")
    ST("b_all", "For a fair comparison, every method receives the same explanation size: the highest-scoring edges (with "
                "their endpoints) are added until the explanation holds 20% of the subgraph's nodes plus edges, the same "
                "budget k that bounds our pruning; SubgraphX selects its best subgraph within the same budget.")
    del rnd
    # metrics
    ST("met_intro", "We assessed explanation quality with five quantitative metrics, computed per target transaction:")
    nec = after(K["fid_hi"], "Necessity (Fidelity+): f(G) − f(G ∖ Eₛ), the drop in fraud probability when the "
                             "explanation's edges are removed from the subgraph; higher values indicate that the explanation "
                             "is needed for the prediction.", bold="Necessity (Fidelity+):")
    ST("sta_lab", "Stability: Measures consistency of the explanation under small input perturbations: every target is "
                  "explained again on three copies with Gaussian noise (σ = 0.05 standard deviations) added to all node "
                  "features and a different random seed; we report the variance-based score below, the Jaccard similarity "
                  "and Spearman rank correlation with the original explanation, and the edit distance (number of nodes and "
                  "edges that change) (Alvarez-Melis & Jaakkola, 2018).", bold="Stability:")
    set_text(K["dp_lab"], "Discriminative Power: Measures how much of the decision the explanation accounts for relative "
                          "to the legitimate reference: the explanation's nodes take the (hop-matched) feature values of "
                          "the nearest legitimate reference Gⱼ* and its edges are removed; DP is the resulting drop in fraud "
                          "probability, and the flip rate is the share of targets whose prediction falls below the "
                          "decision threshold:", bold_label="Discriminative Power:")
    dpp = docx.text.paragraph.Paragraph(dp_eq, K["dp_lab"]._parent)
    newdp = after(dpp, "DP = f(Gᵢ) − f(Gᵢ[Eₛ ← Gⱼ*])", like=K["cgx"], align=WD_ALIGN_PARAGRAPH.CENTER)
    remove(dp_eq)
    del newdp, nec
    mm = C.meta
    set_text(K["human"], "Targets and statistics: for the main model we explain up to 300 randomly ordered correctly "
                         "detected frauds of the test period per dataset ("
                         + ", ".join(f"{DN[x]} {mm[x]['targets']} of {mm[x]['test_true_positives']}" for x in DS)
                         + "), preferring targets with at least three edges in their computation subgraph. Methods are "
                           "compared with paired Wilcoxon signed-rank tests over targets, with Holm correction within "
                           "each dataset (Wilcoxon, 1945; Holm, 1979; Appendix Table A3).")

    # ---- 7. quantitative results
    set_text(K["t3cap"], "Table 3: Explanation quality of each method on the GraphSAGE detector (mean ± SD over targets; "
                         "equal explanation size)")
    rows, bold = [], []
    for i, ds in enumerate(DS):
        for j, m in enumerate(METHODS):
            r = C.q[(ds, m)]
            rows.append([DN[ds] if j == 0 else "", MN[m], r["fidelity"], r["fid_plus"], r["sparsity"], r["stability"] or "–",
                         r["disc_power"], f"{100 * r['flip_mean']:.0f}%"])
            for col, k in ((2, "fidelity"), (3, "fid_plus"), (5, "stability"), (6, "disc_power"), (7, "flip")):
                vals = [C.q[(ds, mm_)][k + "_mean"] for mm_ in METHODS]
                if r[k + "_mean"] == max(vals) and max(vals) > min(vals) + 1e-9:
                    bold.append((len(rows) - 1, col))
    t = build_table(C_doc, ["Dataset", "Method", "Fidelity", "Necessity", "Sparsity", "Stability", "Disc. power",
                            "Flip rate"], rows, T[2].style, size=7.5, bold=bold)
    booktabs(t, [0.65, 0.85, 0.85, 0.85, 0.85, 0.85, 0.85, 0.55])
    swap_table(T[2], t)
    ST("t3note", "Note: Values are mean ± standard deviation across targets (stability: first 50 targets). Bold marks the "
                 "best value per dataset. Every explanation holds 20% of the subgraph's nodes plus edges, so sparsity "
                 "differs only where a method keeps fewer elements (SubgraphX), our pruning keeps more to stay within "
                 "the fidelity threshold, or the subgraph is too small for the budget (PaySim, where at least one edge "
                 "is always kept).")
    qt = after(K["t3note"], quality_text(C), like=K["tr_text"])
    after(qt, paysim_note(C), like=K["tr_text"])
    add_figure(C_doc, K["fig2"], os.path.join(fdir, "fig2_radar.png"),
               "Figure 2: Radar charts of explanation quality on the three datasets (each axis scaled to the range of the "
               "six methods; outer is better). Our contrastive framework is shown in red.", width=6.3)
    ST("tr_text", "A critical consideration for practical deployment is balancing explanation fidelity and sparsity. We "
                  "analyzed this trade-off by varying the size budget k from 5% to 50% of the subgraph's nodes plus edges "
                  "for every method (Figure 3). On IEEE-CIS our method had the highest fidelity and discriminative power "
                  "for explanations of up to about a third of the subgraph (sparsity of 0.65 and above); when explanations "
                  "cover half of it, Grad-CAM and PGExplainer keep slightly higher fidelity, and GNNExplainer and even the "
                  "random baseline reach slightly higher discriminative power, because switching most nodes to legitimate "
                  "values lowers the score whichever nodes are chosen. On "
                  "Credit Card our discriminative power was the highest at every size, while GNNExplainer kept the "
                  "highest fidelity for the largest explanations. On PaySim the curves are close together.")
    add_figure(C_doc, K["fig3"], os.path.join(fdir, "fig3_tradeoff.png"),
               "Figure 3: Fidelity (top) and discriminative power (bottom) against sparsity when the explanation budget "
               "varies from 5% to 50% of the subgraph's nodes plus edges. Our method is shown in red.", width=6.3)
    ST("stab_text", "Explanation stability is crucial for building user trust. We measured it by explaining every target "
                    "again on three slightly perturbed copies (Gaussian feature noise, σ = 0.05) with a new random seed and "
                    "comparing the explanations (Table 4).")
    set_text(K["t4cap"], "Table 4: Explanation stability under small input perturbations (mean ± SD over targets)")
    rows = []
    for ds in DS:
        for j, m in enumerate(METHODS):
            r = C.st.get((ds, m))
            if r is None:
                continue
            rows.append([DN[ds] if j == 0 else "", MN[m], r["jaccard"], r["spearman"], r["edit_distance"]])
    t = build_table(C_doc, ["Dataset", "Method", "Jaccard similarity", "Rank correlation", "Edit distance"], rows,
                    T[3].style, size=8)
    booktabs(t, [0.8, 1.0, 1.5, 1.5, 1.5])
    swap_table(T[3], t)
    st_par = after(K["t4cap"], "", like=K["stab_text"])
    t._tbl.addnext(st_par._p)
    set_text(st_par, stability_text(C))
    # architectures (new Table 5)
    h = after(st_par, "Generalization Across GNN Architectures", like=heads["Stability Analysis"])
    ap_ = after(h, arch_text(C), like=K["stab_text"])
    cap5 = after(ap_, "Table 5: Explanation quality on the GCN and GAT detectors (means over targets)", like=K["t4cap"])
    A = {(r["ds"], r["model"], r["method"]): r for r in S.get("arch", [])}
    rows = []
    for ds in DS:
        first = True
        for mdl in ["gcn", "gat"]:
            if (ds, mdl, "ours") not in A:
                continue
            for j, m in enumerate(METHODS):
                r = A[(ds, mdl, m)]
                rows.append([DN[ds] if first else "", ("GCN" if mdl == "gcn" else "GAT") if j == 0 else "", MN[m],
                             f3(r["fidelity_mean"]), f3(r["fid_plus_mean"]), f3(r["disc_power_mean"]),
                             f"{100 * r['flip_mean']:.0f}%", f"{r['seconds_mean']:.2f}"])
                first = False
    t5 = build_table(C_doc, ["Dataset", "Model", "Method", "Fidelity", "Necessity", "Disc. power", "Flip rate",
                             "Time (s)"], rows, T[3].style, size=7.5)
    booktabs(t5, [0.7, 0.55, 1.0, 0.75, 0.75, 0.8, 0.65, 0.6])
    cap5._p.addnext(t5._tbl)
    # ablation (Table 6)
    ST("abl_text", "To validate design choices, we removed or replaced one component at a time on the GraphSAGE detector "
                   "(same targets as Table 3; Table 6). Significance is tested on discriminative power against the full "
                   "model (paired Wilcoxon, Holm-corrected within each dataset).")
    set_text(K["t5cap"], "Table 6: Ablation study of the proposed explainer (GraphSAGE; means over targets)")
    rows = []
    order = ["full", "no_contrast", "unsigned", "no_ensemble", "random_attr", "no_budget", "no_pruning", "exact"]
    for ds in DS:
        for j, v in enumerate(order):
            r = C.abl.get((ds, v))
            if r is None:
                continue
            ph = r.get("p_dp_holm")
            rows.append([DN[ds] if j == 0 else "", r["Variant"], f3(r["fidelity_mean"]), f3(r["sparsity_mean"]),
                         "–" if r["stability_mean"] != r["stability_mean"] else f3(r["stability_mean"]),
                         f3(r["disc_power_mean"]), f"{100 * r['flip_mean']:.0f}%",
                         "–" if ph is None else ("< 0.001" if ph < 0.001 else f"{ph:.3f}")])
    t6 = build_table(C_doc, ["Dataset", "Variant", "Fidelity", "Sparsity", "Stability", "Disc. power", "Flip rate",
                             "p (DP, Holm)"], rows, T[4].style, size=7.5)
    booktabs(t6, [0.6, 2.25, 0.6, 0.6, 0.6, 0.65, 0.55, 0.6])
    swap_table(T[4], t6)
    ST("keyf", "Key findings: " + ablation_text(C), bold="Key findings:")
    after(K["keyf"], feature_text(C), like=K["keyf"], bold="Feature-level explanations.")

    # ---- 8. remove the human evaluation (no such study was run)
    for key in ("he_text", "t6cap", "t6note", "fig4"):
        remove(K[key]._p)
    remove(T[5]._tbl)
    remove(heads["Human Evaluation Results"]._p)

    # ---- 9. case study
    cs = C.case
    ST("cs_intro", "We present a representative case from IEEE-CIS, chosen automatically as the correctly detected test "
                   "fraud with the largest discriminative power whose computation subgraph has 8–30 transactions and at "
                   "least two relation types (Figure 4).")
    ST("cs_head", "Case study: repeated charges on a shared card and device (IEEE-CIS)")
    rel = cs["explanation_edges_by_relation"]
    hrs = cs["hours_before_target_in_explanation"]
    amts = cs["neighbour_amounts_in_explanation"]
    same_amt = sum(abs(a - cs["amount"]) < 0.005 for a in amts)
    def ok(v):
        return v is not None and str(v) not in ("nan", "NaN", "None", "")
    attrs = [f"${cs['amount']:.2f}", f"product {cs['product']}"]
    if ok(cs["card4"]) and ok(cs["card6"]):
        attrs.append(f"{cs['card4']} {cs['card6']} card")
    if ok(cs["email"]):
        attrs.append(f"{cs['email']} e-mail")
    if ok(cs["device_type"]):
        attrs.append(f"{cs['device_type']} device" + (f" ({cs['device_info']})" if ok(cs["device_info"]) else ""))
    ST("cs1", f"Transaction {cs['transaction_id']} ({', '.join(attrs)}) was flagged with "
              f"fraud probability {cs['p']:.2f} (threshold {cs['threshold']:.2f}). Its computation subgraph contains "
              f"{cs['n']} transactions and {cs['e']} edges ("
              + ", ".join(f"{v} {k}" for k, v in cs["edges_by_relation"].items() if v) + ").")
    ST("cs2", f"The contrastive explanation kept {cs['explanation_nodes']} transactions and {cs['explanation_edges']} edges "
              f"(" + ", ".join(f"{v} {k}" for k, v in rel.items() if v) + f"). The {cs['earlier_in_explanation']} earlier "
              f"transactions it retained were made within {math.ceil(max(cs['minutes_before_target_in_explanation']))} minutes "
              "before the target, "
              + (f"all for exactly the same amount (${cs['amount']:.2f})" if same_amt == len(amts) else
                 f"{same_amt} of them for exactly the same amount")
              + (", and all of them were" if cs['earlier_frauds_in_explanation'] == cs['earlier_in_explanation'] else
                 f", and {cs['earlier_frauds_in_explanation']} of them were")
              + f" later confirmed as fraud ({cs['earlier_frauds_in_subgraph']} of the {cs['earlier_in_subgraph']} earlier "
              "transactions in the whole subgraph). The explanation therefore points an investigator to a burst of "
              "repeated charges on the same card and device, a typical card-testing or account-takeover pattern.")
    tf = ", ".join(cs["top_features"][:5])
    ST("cs3", f"The nearest legitimate reference (transaction {cs['ref_transaction_id']}, ${cs['ref_amount']:.2f}, "
              f"cosine similarity {cs['ref_sim']:.2f}) differs most in the features {tf} (Figure 4C); in IEEE-CIS the C "
              "fields count, for example, the addresses and payment cards associated with the purchaser. Switching the explanation to this reference lowered the fraud probability from "
              f"{cs['quality']['p']:.2f} to {cs['quality']['p_cf']:.2f}, below the decision threshold, while the explanation "
              f"alone kept the prediction (fidelity {cs['quality']['fidelity']:.3f}). The explanation took "
              f"{cs['seconds']:.2f} s and retained {cs['feat_kept']} of {S['datasets'][1]['Features']} features.")
    add_figure(C_doc, K["fig5"], os.path.join(fdir, "fig5_case_study.png"),
               "Figure 4: Case study on IEEE-CIS. (A) Computation subgraph of the flagged transaction (edge colors: "
               "relation; node colors: later-confirmed fraud or legitimate). (B) Contrastive explanation (highlighted). "
               "(C) Features with the largest contrastive scores on which the target differs from its nearest legitimate "
               "reference (standardized values).", width=6.4)

    # ---- 10. efficiency
    ST("eff1", "Production deployment requires fast explanation generation. We measured wall-clock time and peak GPU "
               "memory per explanation on one NVIDIA Tesla T4 (16 GB) in a Kaggle notebook (Table 7), and the growth of "
               "the time with subgraph size by explaining 20 IEEE-CIS frauds on their 2-, 3- and 4-hop neighborhoods "
               "(Figure 5).")
    set_text(K["t7cap"], "Table 7: Computational performance per explanation (all main targets pooled; T4 GPU)")
    rows = []
    for m in METHODS:
        r = C.comp[m]
        rows.append([MN[m], f"{r['avg_seconds']:.3f}", f"{r['median_seconds']:.3f}",
                     "–" if r["mem_mb"] != r["mem_mb"] else f"{r['mem_mb']:.1f}", f"{r['nodes_per_second']:,.0f}"])
    t7 = build_table(C_doc, ["Method", "Avg. time (s)", "Median time (s)", "Peak extra memory (MB)", "Throughput (nodes/s)"],
                     rows, T[6].style, size=8)
    booktabs(t7, [1.2, 1.1, 1.2, 1.3, 1.5])
    swap_table(T[6], t7)
    ST("eff2", efficiency_text(C))
    add_figure(C_doc, K["fig6"], os.path.join(fdir, "fig6_scalability.png"),
               "Figure 5: Explanation time against the number of nodes in the explained subgraph (20 IEEE-CIS frauds on "
               "their 2-, 3- and 4-hop neighborhoods; points are explanations, lines connect the medians per hop count).",
               width=4.8)

    # ---- 11. discussion
    ST("find", "This study introduced a post-hoc explainability framework for GNN-based fraud detection that compares "
               "each flagged transaction with its nearest legitimate counterparts. Our key findings are: (1) at equal "
               "explanation size, the contrastive explanations were significantly more faithful and more discriminative than "
               "those of four established explainers on the datasets where the graph carries signal (IEEE-CIS and Credit "
               "Card; Table 3), while on PaySim, where detected frauds have almost no history, all methods were alike; (2) "
               "the signed contrast is the decisive design choice, and the legitimate references and their ensemble add a "
               "smaller but significant gain on IEEE-CIS (Table 6); (3) the method transfers unchanged to GCN and GAT "
               "detectors (Table 5); (4) it takes well under a second per transaction and its explanations are stable "
               "under small input perturbations (Tables 4 and 7).")
    ST("stabth", "Stability Through Ensemble Contrasts: averaging the contrast over several legitimate references makes "
                 "the explanation less dependent on any single reference. In our experiments three references improved "
                 "discriminative power over one on IEEE-CIS (Table 6), and larger ensembles changed little (Figure A1); "
                 "the explanations were stable under small input perturbations (Table 4).", bold="Stability Through Ensemble Contrasts:")
    ST("trust", "Trust and Adoption: The contrastive format answers the question investigators ask (“why this transaction "
                "and not a similar legitimate one?”) and points to verifiable evidence, as in the case study. Whether this "
                "translates into higher analyst trust and faster investigations must be established in a user study with "
                "fraud analysts, which we leave to future work.", bold="Trust and Adoption:")
    ST("mdnn", "Method of Difference for Neural Networks: We operationalize Mill’s (1843) method of difference, a "
               "foundational principle of causal inference, for deep learning models. By contrasting similar instances "
               "with different outcomes, element by element, we isolate discriminative features and relations, providing "
               "explanations aligned with human causal reasoning (Miller, 2019).", bold="Method of Difference for Neural Networks:")
    ST("emb", "Embedding Space Assumptions: We assume that proximity in the final-layer embedding space corresponds to "
              "semantic similarity. For poorly calibrated models or datasets with complex class boundaries this assumption "
              "may not hold, and the hop-matched counterparts are averages rather than exact correspondences. "
              "Incorporating uncertainty estimation or optimal-transport matching could improve reference selection.",
       bold="Embedding Space Assumptions:")
    lim = K["lim_ds"]
    ST("lim_ds", "Dataset-Specific Evaluation: Our evaluation covers three public datasets with transaction-level labels; "
                 "on PaySim the graph carries little information beyond the target transaction itself, which limits "
                 "what any structural explanation can show. Generalization to other domains (e.g., social "
                 "networks, biological networks) requires validation.", bold="Dataset-Specific Evaluation:")
    l2 = after(lim, "No Human Evaluation: Explanation quality was measured with model-based metrics only; we did not run a "
                    "study with fraud analysts, so claims about interpretability for humans remain to be validated.",
               bold="No Human Evaluation:")
    after(l2, "First-Order Approximation: The contrastive scores are first-order estimates of the effect of switching "
              "one element; they agreed closely with exact one-at-a-time switches in our ablation, but interactions "
              "between elements are captured only through the greedy pruning.", bold="First-Order Approximation:")
    K["fut_int"].runs[-1].text = K["fut_int"].runs[-1].text.rstrip() + (" A controlled user study with fraud analysts "
                                                                          "should quantify clarity, actionability and "
                                                                          "trust.")

    # ---- 12. conclusion
    ST("concl1", "This paper presented a post-hoc explainability framework for GNN-based financial fraud detection that "
                 "applies Mill's method of difference: each flagged transaction is compared with its nearest legitimate "
                 "counterparts, and every node, feature and message is scored by how much the fraud score would fall if it "
                 "were switched to its legitimate counterpart. Reference ensembling and fidelity-constrained pruning turn "
                 "these scores into small, stable explanation subgraphs and feature masks.")
    ST("concl2", "Evaluated on three public fraud datasets and three GNN architectures against four established explainers "
                 "and a random baseline at equal explanation size, the framework " + concl_result(C) + " An explanation "
                 f"takes {C.comp['ours']['avg_seconds']:.2f} s on average on a single GPU, which allows interactive use.")
    ST("concl3", "The contrastive approach addresses critical barriers to GNN adoption in regulated financial environments "
                 "by providing transparent, auditable explanations that support regulatory compliance, investigation "
                 "workflows and model validation. The case study shows how an explanation can lead an investigator to "
                 "concrete evidence, such as repeated identical charges on a shared card and device.")
    ST("concl4", "Future work will extend the framework to temporal GNNs and heterogeneous graphs, validate the "
                 "explanations in a user study with fraud analysts, and incorporate interactive refinement based on "
                 "investigator feedback. As financial fraud continues to evolve in sophistication, explainable AI systems "
                 "that combine predictive accuracy with transparent reasoning will be essential for protecting financial "
                 "systems while maintaining trust and accountability.")

    # ---- 12b. corrections found on proof-reading
    ST("cfx", "Counterfactual Explanation: Counterfactual methods generate alternative instances that flip the model "
              "prediction with minimal perturbations (Wachter et al., 2017). Mothilal et al. (2020) proposed DiCE, which "
              "generates diverse counterfactual explanations through optimization. Karimi et al. (2022) reviewed how "
              "counterfactuals support recourse, i.e. actions users can take on the explanation. However, these methods "
              "focus on tabular or image data, with limited adaptation to graph structures.",
       bold="Counterfactual Explanation:")
    ST("proposes", "This paper proposes a post-hoc explainability framework for GNN-based fraud detection that uses "
                   "contrastive reasoning to generate method-of-difference explanations. The framework identifies the "
                   "subgraph structures and feature patterns that distinguish fraudulent transactions from their nearest "
                   "legitimate counterparts, providing concise and actionable explanations for financial analysts and "
                   "auditors.")
    ST("maskop", "where ⊙ denotes the masking operation. This is a fidelity loss, so lower values indicate higher "
                 "fidelity; for evaluation we report the normalized form 1 − |f(G) − f(G ⊙ E)| / f(G), for which higher "
                 "is better (Section 4.1).")
    set_text(K["alg2"], "Input: Gᵢ, reference set {Gⱼ}, f, contrastive scores CG, sparsity budget k\n"
                        "Output: Explanation subgraph Gₛ, feature mask Mₓ\n\n"
                        "1. Initialize: Gₛ = Gᵢ, Mₓ = 1^d\n"
                        "2. Rank elements by CG scores: R = sort({CG_v, CG_e, CG_x})\n"
                        "3. For each element r in R (ascending order):\n"
                        "4.     Temporarily remove r from Gₛ or Mₓ\n"
                        "5.     Compute fidelity loss: Δf = |f(Gᵢ) − f(Gₛ)|\n"
                        "6.     If Δf < τ and |Gₛ| > k:\n"
                        "7.         Permanently remove r\n"
                        "8.     Else:\n"
                        "9.         Restore r\n"
                        "10. Return Gₛ, Mₓ")
    ST("stab3", "Averaging over several references makes the explanation less dependent on the choice of any single "
                "reference while keeping its discriminative focus (Table 6).")

    # ---- 13. references (APA 7, alphabetical)
    write_references(d, refs)

    # ---- 14. appendix
    remove(K["figA1"]._p)
    add_figure(C_doc, K["figA2"], os.path.join(fdir, "figA2_sensitivity.png"),
               "Figure A1: Sensitivity of the proposed explainer to the fidelity threshold τ, the ensemble size m and the "
               "sparsity budget k (IEEE-CIS, GraphSAGE; means over targets; dotted lines mark the defaults).", width=6.3)
    set_text(K["tA1cap"], "Table A1: Data preprocessing and graph construction")
    rows = [["CCF", "none", "z-score (training period); log amount; cyclic hour",
             "temporal adjacency (3 preceding) + 5 most similar earlier transactions (V1–V28)", "temporal 60/20/20"],
            ["IEEE-CIS", "training-period mean + missing indicators; V fields with > 1% missing dropped",
             "z-score (training period); signed log", "shared card, address + e-mail and device (3 preceding each)",
             "temporal 60/20/20"],
            ["PaySim", "none", "z-score (training period); signed log balances",
             "shared origin and destination account (3 preceding each)", "temporal 60/20/20"]]
    t = build_table(C_doc, ["Dataset", "Missing values", "Normalization", "Graph construction", "Train/Val/Test split"],
                    rows, T[7].style, size=8)
    booktabs(t, [0.7, 1.55, 1.5, 1.9, 0.85])
    swap_table(T[7], t)
    set_text(K["tA2cap"], "Table A2: Hyperparameters of the explained GNN detectors")
    rows = [[m, "2", h_, "0.3", "0.005", "full batch", "≤ 300 (early stopping, patience 30)"] for m, h_ in
            (("GCN", "64"), ("GAT", "64 (8 heads × 8)"), ("GraphSAGE", "64"))]
    t = build_table(C_doc, ["Model", "Layers", "Hidden units", "Dropout", "Learning rate", "Batch size", "Epochs"], rows,
                    T[8].style, size=8)
    booktabs(t, [0.85, 0.5, 1.1, 0.6, 0.85, 0.8, 1.8])
    swap_table(T[8], t)
    capA3 = after(type("X", (), {"_p": t._tbl})(), "Table A3: Paired Wilcoxon tests of our explainer against each "
                                                   "baseline (Holm-corrected within each dataset)", like=K["tA2cap"])
    rows = []
    for ds in DS:
        for m in [x for x in METHODS if x != "ours"]:
            for k, kn in (("disc_power", "Disc. power"), ("fid_plus", "Necessity")):
                r = C.sig[(ds, m, k)]
                rows.append([DN[ds], MN[m], kn, f3(r["ours_mean"]), f3(r["baseline_mean"]),
                             f"{r['wins']}/{r['ties']}/{r['losses']}",
                             "< 0.001" if r["p_holm"] < 0.001 else f"{r['p_holm']:.3f}", r["direction"]])
    tA3 = build_table(C_doc, ["Dataset", "Baseline", "Metric", "Ours", "Baseline", "W/T/L", "p (Holm)", "Result"], rows,
                      T[8].style, size=7)
    booktabs(tA3, [0.65, 0.9, 0.75, 0.55, 0.65, 0.65, 0.65, 1.7])
    capA3._p.addnext(tA3._tbl)
    set_text(K["alg3"], ALG3)
    ST("soft", f"Software and Hardware Specifications: Python 3; {args.env}; explanations computed on one NVIDIA Tesla T4 "
               "GPU (16 GB) per dataset in a Kaggle notebook (2 × T4 in total). Code, trained models, per-transaction "
               "results and the scripts that produce every table and figure are released with the paper.",
       bold="Software and Hardware Specifications:")

    # ---- 15. back matter
    ST("ack", "We thank Vesta Corporation and the IEEE Computational Intelligence Society, the Machine Learning Group of "
              "the Université Libre de Bruxelles, and the authors of PaySim for making their datasets publicly available.")
    dav = K["dav"]
    after(dav, "All three datasets are publicly available on Kaggle (IEEE-CIS Fraud Detection; Credit Card Fraud Detection, "
               "mlg-ulb/creditcardfraud; Synthetic Financial Datasets for Fraud Detection, ealaxi/paysim1). The code, the "
               "trained GNN checkpoints and all per-transaction explanation results are available from the corresponding "
               "author and in the supplementary material.", like=K["ack"])

    blacken(d)
    for r in K["alg3"].runs:  # plain monospace-looking code, no token colouring / bold
        rpr = r._r.find(qn("w:rPr"))
        if rpr is not None:
            for tag in ("w:rStyle", "w:b", "w:bCs"):
                for e in rpr.findall(qn(tag)):
                    rpr.remove(e)
    d.save(out)
    check(out)


def blacken(d):
    """Every run, paragraph mark (list numbers) and table cell in black."""
    from docx.oxml import OxmlElement

    def set_black(rpr_parent, tag="w:rPr"):
        rpr = rpr_parent.find(qn(tag))
        if rpr is None:
            rpr = OxmlElement(tag)
            rpr_parent.insert(0, rpr)
        for e in rpr.findall(qn("w:color")):
            rpr.remove(e)
        c = OxmlElement("w:color")
        c.set(qn("w:val"), "000000")
        rpr.append(c)

    body = d.element.body
    for r in body.iter(qn("w:r")):
        set_black(r)
    for ppr in body.iter(qn("w:pPr")):
        set_black(ppr)


def booktabs(t, widths):
    """Clean academic table: rules above and below the header and at the bottom, fixed column widths (inches)."""
    from docx.oxml import OxmlElement
    from docx.shared import Inches
    tbl = t._tbl
    tblPr = tbl.tblPr
    for e in tblPr.findall(qn("w:tblStyle")):
        tblPr.remove(e)
    lay = OxmlElement("w:tblLayout")
    lay.set(qn("w:type"), "fixed")
    tblPr.append(lay)
    b = OxmlElement("w:tblBorders")
    for side in ("top", "bottom"):
        e = OxmlElement(f"w:{side}")
        e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "8"); e.set(qn("w:space"), "0"); e.set(qn("w:color"), "000000")
        b.append(e)
    tblPr.append(b)
    for c in t.rows[0].cells:
        tcPr = c._tc.get_or_add_tcPr()
        bd = OxmlElement("w:tcBorders")
        e = OxmlElement("w:bottom")
        e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "6"); e.set(qn("w:space"), "0"); e.set(qn("w:color"), "000000")
        bd.append(e)
        tcPr.append(bd)
    grid = tbl.tblGrid
    for gc, w in zip(grid.findall(qn("w:gridCol")), widths):
        gc.set(qn("w:w"), str(int(w * 1440)))
    size = None
    for r in t.rows[0].cells[0].paragraphs[0].runs:
        size = r.font.size
    for row in t.rows:
        for c, w in zip(row.cells, widths):
            c.width = Inches(w)
            for p in c.paragraphs:  # paragraph mark in the table font size (empty cells otherwise add height)
                ppr = p._p.get_or_add_pPr()
                rpr = ppr.find(qn("w:rPr"))
                if rpr is None:
                    rpr = OxmlElement("w:rPr")
                    ppr.append(rpr)
                for tag in ("w:sz", "w:szCs"):
                    e = OxmlElement(tag)
                    e.set(qn("w:val"), str(int(size.pt * 2)) if size else "16")
                    rpr.append(e)
            for p in c.paragraphs:
                for r in p.runs:
                    if r.text.startswith("-") and r.text[1:2].isdigit():
                        r.text = ("" if re.fullmatch(r"-0\.0+( ± .*)?", r.text) else "−") + r.text[1:]
    return t


def concl_result(C):
    return ("gave significantly more discriminative and more necessary explanations than every baseline on IEEE-CIS "
            "and Credit Card, with fidelity of at least "
            f"{math.floor(100 * min(C.v(d, 'ours', 'fidelity') for d in DS)) / 100:.2f} and high stability under input "
            "perturbations; on PaySim, "
            "whose detected frauds have almost no transaction history, all methods performed alike. Ablations showed that "
            "the signed contrast with legitimate references is the decisive component.")


ALG3 = '''def explain(G_target, model, legit_pool, m=3, tau=0.05, k_frac=0.20):
    """Contrastive method-of-difference explanation of one flagged transaction."""
    # Component 1: nearest legitimate references (final-layer embeddings, cosine similarity)
    z = model.embed(G_target)[target]
    refs = legit_pool.nearest(z, m)
    # Component 2: contrastive gradient attribution (one backward pass)
    logit, messages = model.forward_with_messages(G_target)
    g_x, g_msg = grad(logit, [G_target.x, messages])
    scores = []
    for G_ref in refs:                                  # Component 4: ensemble over references
        x_ref, msg_ref = hop_matched_counterparts(G_target, G_ref)
        node = relu(sum_k(g_x * (G_target.x - x_ref)))
        feat = relu(sum_v(g_x * (G_target.x - x_ref)))
        edge = relu(sum_layers(dot(g_msg, messages - msg_ref)))
        scores.append(normalize(node, edge, feat))
    node, edge, feat = mean(scores)
    # Component 3: greedy fidelity-constrained pruning (Algorithm 2)
    return prune(G_target, node, edge, feat, model, tau, k=ceil(k_frac * (n_nodes + n_edges)))'''


REFS = [
    "Abdallah, A., Maarof, M. A., & Zainal, A. (2016). Fraud detection system: A survey. Journal of Network and Computer Applications, 68, 90–113. https://doi.org/10.1016/j.jnca.2016.04.007",
    "Alvarez-Melis, D., & Jaakkola, T. S. (2018). On the robustness of interpretability methods. ICML 2018 Workshop on Human Interpretability in Machine Learning. https://arxiv.org/abs/1806.08049",
    "Arrieta, A. B., Díaz-Rodríguez, N., Del Ser, J., Bennetot, A., Tabik, S., Barbado, A., García, S., Gil-López, S., Molina, D., Benjamins, R., Chatila, R., & Herrera, F. (2020). Explainable artificial intelligence (XAI): Concepts, taxonomies, opportunities and challenges toward responsible AI. Information Fusion, 58, 82–115. https://doi.org/10.1016/j.inffus.2019.12.012",
    "Association of Certified Fraud Examiners. (2024). Occupational fraud 2024: A report to the nations. ACFE.",
    "Bajaj, M., Chu, L., Xue, Z. Y., Pei, J., Wang, L., Lam, P. C. H., & Zhang, Y. (2021). Robust counterfactual explanations on graph neural networks. Advances in Neural Information Processing Systems, 34, 5644–5655.",
    "Bussmann, N., Giudici, P., Marinelli, D., & Papenbrock, J. (2021). Explainable machine learning in credit risk management. Computational Economics, 57(1), 203–216. https://doi.org/10.1007/s10614-020-10042-0",
    "Chen, T., Kornblith, S., Norouzi, M., & Hinton, G. (2020). A simple framework for contrastive learning of visual representations. Proceedings of the 37th International Conference on Machine Learning, 1597–1607.",
    "Dal Pozzolo, A., Caelen, O., Johnson, R. A., & Bontempi, G. (2015). Calibrating probability with undersampling for unbalanced classification. 2015 IEEE Symposium Series on Computational Intelligence, 159–166. https://doi.org/10.1109/SSCI.2015.33",
    "Dou, Y., Liu, Z., Sun, L., Deng, Y., Peng, H., & Yu, P. S. (2020). Enhancing graph neural network-based fraud detectors against camouflaged fraudsters. Proceedings of the 29th ACM International Conference on Information and Knowledge Management, 315–324. https://doi.org/10.1145/3340531.3411903",
    "Goodman, B., & Flaxman, S. (2017). European Union regulations on algorithmic decision-making and a “right to explanation”. AI Magazine, 38(3), 50–57. https://doi.org/10.1609/aimag.v38i3.2741",
    "Hamilton, W. L., Ying, R., & Leskovec, J. (2017). Inductive representation learning on large graphs. Advances in Neural Information Processing Systems, 30, 1024–1034.",
    "He, K., Fan, H., Wu, Y., Xie, S., & Girshick, R. (2020). Momentum contrast for unsupervised visual representation learning. Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 9729–9738. https://doi.org/10.1109/CVPR42600.2020.00975",
    "Hilal, W., Gadsden, S. A., & Yawney, J. (2022). Financial fraud: A review of anomaly detection techniques and recent advances. Expert Systems with Applications, 193, 116429. https://doi.org/10.1016/j.eswa.2021.116429",
    "Holm, S. (1979). A simple sequentially rejective multiple test procedure. Scandinavian Journal of Statistics, 6(2), 65–70.",
    "Huang, Q., Yamada, M., Tian, Y., Singh, D., & Chang, Y. (2023). GraphLIME: Local interpretable model explanations for graph neural networks. IEEE Transactions on Knowledge and Data Engineering, 35(7), 6968–6972. https://doi.org/10.1109/TKDE.2022.3187455",
    "IEEE Computational Intelligence Society & Vesta Corporation. (2019). IEEE-CIS fraud detection [Data set]. Kaggle. https://www.kaggle.com/c/ieee-fraud-detection",
    "Jain, S., & Wallace, B. C. (2019). Attention is not explanation. Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics, 3543–3556. https://doi.org/10.18653/v1/N19-1357",
    "Karimi, A. H., Barthe, G., Schölkopf, B., & Valera, I. (2022). A survey of algorithmic recourse: Contrastive explanations and consequential recommendations. ACM Computing Surveys, 55(5), 1–29. https://doi.org/10.1145/3527848",
    "Kipf, T. N., & Welling, M. (2017). Semi-supervised classification with graph convolutional networks. Proceedings of the 5th International Conference on Learning Representations.",
    "Lin, T.-Y., Goyal, P., Girshick, R., He, K., & Dollár, P. (2017). Focal loss for dense object detection. Proceedings of the IEEE International Conference on Computer Vision, 2980–2988. https://doi.org/10.1109/ICCV.2017.324",
    "Lipton, P. (1990). Contrastive explanation. Royal Institute of Philosophy Supplements, 27, 247–266. https://doi.org/10.1017/S1358246100005130",
    "Liu, Y., Ao, X., Qin, Z., Chi, J., Feng, J., Yang, H., & He, Q. (2021). Pick and choose: A GNN-based imbalanced learning approach for fraud detection. Proceedings of the Web Conference 2021, 3168–3177. https://doi.org/10.1145/3442381.3449989",
    "Lopez-Rojas, E. A., Elmir, A., & Axelsson, S. (2016). PaySim: A financial mobile money simulator for fraud detection. Proceedings of the 28th European Modeling and Simulation Symposium, 249–255.",
    "Lucic, A., Ter Hoeve, M. A., Tolomei, G., De Rijke, M., & Silvestri, F. (2022). CF-GNNExplainer: Counterfactual explanations for graph neural networks. Proceedings of the 25th International Conference on Artificial Intelligence and Statistics, 4499–4511.",
    "Luo, D., Cheng, W., Xu, D., Yu, W., Zong, B., Chen, H., & Zhang, X. (2020). Parameterized explainer for graph neural network. Advances in Neural Information Processing Systems, 33, 19620–19631.",
    "Mill, J. S. (1843). A system of logic, ratiocinative and inductive. John W. Parker.",
    "Miller, T. (2019). Explanation in artificial intelligence: Insights from the social sciences. Artificial Intelligence, 267, 1–38. https://doi.org/10.1016/j.artint.2018.07.007",
    "Molnar, C. (2022). Interpretable machine learning: A guide for making black box models explainable (2nd ed.). https://christophm.github.io/interpretable-ml-book/",
    "Mothilal, R. K., Sharma, A., & Tan, C. (2020). Explaining machine learning classifiers through diverse counterfactual explanations. Proceedings of the 2020 Conference on Fairness, Accountability, and Transparency, 607–617. https://doi.org/10.1145/3351095.3372850",
    "Pope, P. E., Kolouri, S., Rostami, M., Martin, C. E., & Hoffmann, H. (2019). Explainability methods for graph convolutional neural networks. Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 10772–10781. https://doi.org/10.1109/CVPR.2019.01103",
    "Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). “Why should I trust you?” Explaining the predictions of any classifier. Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, 1135–1144. https://doi.org/10.1145/2939672.2939778",
    "Rossi, E., Chamberlain, B., Frasca, F., Eynard, D., Monti, F., & Bronstein, M. (2020). Temporal graph networks for deep learning on dynamic graphs. arXiv preprint arXiv:2006.10637.",
    "Schlichtkrull, M., De Cao, N., & Titov, I. (2021). Interpreting graph neural networks for NLP with differentiable edge masking. Proceedings of the 9th International Conference on Learning Representations.",
    "Selvaraju, R. R., Cogswell, M., Das, A., Vedantam, R., Parikh, D., & Batra, D. (2017). Grad-CAM: Visual explanations from deep networks via gradient-based localization. Proceedings of the IEEE International Conference on Computer Vision, 618–626. https://doi.org/10.1109/ICCV.2017.74",
    "Shrikumar, A., Greenside, P., & Kundaje, A. (2017). Learning important features through propagating activation differences. Proceedings of the 34th International Conference on Machine Learning, 3145–3153.",
    "Stepin, I., Alonso, J. M., Catala, A., & Pereira-Fariña, M. (2021). A survey of contrastive and counterfactual explanation generation methods for explainable artificial intelligence. IEEE Access, 9, 11974–12001. https://doi.org/10.1109/ACCESS.2021.3051315",
    "Sundararajan, M., Taly, A., & Yan, Q. (2017). Axiomatic attribution for deep networks. Proceedings of the 34th International Conference on Machine Learning, 3319–3328.",
    "Tan, J., Geng, S., Fu, Z., Ge, Y., Xu, S., Li, Y., & Zhang, Y. (2022). Learning and evaluating graph neural network explanations based on counterfactual and factual reasoning. Proceedings of the ACM Web Conference 2022, 1018–1027. https://doi.org/10.1145/3485447.3511948",
    "Veličković, P., Cucurull, G., Casanova, A., Romero, A., Liò, P., & Bengio, Y. (2018). Graph attention networks. Proceedings of the 6th International Conference on Learning Representations.",
    "Wachter, S., Mittelstadt, B., & Russell, C. (2017). Counterfactual explanations without opening the black box: Automated decisions and the GDPR. Harvard Journal of Law & Technology, 31(2), 841–887. https://doi.org/10.2139/ssrn.3063289",
    "Wang, D., Lin, J., Cui, P., Jia, Q., Wang, Z., Fang, Y., Yu, Q., Zhou, J., Yang, S., & Qi, Y. (2019). A semi-supervised graph attentive network for financial fraud detection. 2019 IEEE International Conference on Data Mining, 598–607. https://doi.org/10.1109/ICDM.2019.00070",
    "Weber, M., Domeniconi, G., Chen, J., Weidele, D. K. I., Bellei, C., Robinson, T., & Leiserson, C. E. (2019). Anti-money laundering in bitcoin: Experimenting with graph convolutional networks for financial forensics. KDD Workshop on Anomaly Detection in Finance. https://arxiv.org/abs/1908.02591",
    "Wilcoxon, F. (1945). Individual comparisons by ranking methods. Biometrics Bulletin, 1(6), 80–83. https://doi.org/10.2307/3001968",
    "Wu, Z., Pan, S., Chen, F., Long, G., Zhang, C., & Yu, P. S. (2021). A comprehensive survey on graph neural networks. IEEE Transactions on Neural Networks and Learning Systems, 32(1), 4–24. https://doi.org/10.1109/TNNLS.2020.2978386",
    "Xu, K., Hu, W., Leskovec, J., & Jegelka, S. (2019). How powerful are graph neural networks? Proceedings of the 7th International Conference on Learning Representations.",
    "Ying, R., Bourgeois, D., You, J., Zitnik, M., & Leskovec, J. (2019). GNNExplainer: Generating explanations for graph neural networks. Advances in Neural Information Processing Systems, 32, 9240–9251.",
    "Yuan, H., Yu, H., Gui, S., & Ji, S. (2023). Explainability in graph neural networks: A taxonomic survey. IEEE Transactions on Pattern Analysis and Machine Intelligence, 45(5), 5782–5799. https://doi.org/10.1109/TPAMI.2022.3204236",
    "Yuan, H., Yu, H., Wang, J., Li, K., & Ji, S. (2021). On explainability of graph neural networks via subgraph explorations. Proceedings of the 38th International Conference on Machine Learning, 12241–12252.",
    "Zhou, B., Khosla, A., Lapedriza, A., Oliva, A., & Torralba, A. (2016). Learning deep features for discriminative localization. Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, 2921–2929. https://doi.org/10.1109/CVPR.2016.319",
    "Zhou, J., Cui, G., Hu, S., Zhang, Z., Yang, C., Liu, Z., Wang, L., Li, C., & Sun, M. (2020). Graph neural networks: A review of methods and applications. AI Open, 1, 57–81. https://doi.org/10.1016/j.aiopen.2021.01.001",
]


def write_references(d, refs):
    like = refs[1]
    anchor = refs[0]
    set_text(anchor, REFS[0])
    last = anchor
    for r in REFS[1:]:
        p = new_par_after(last._p, like=like, text="")
        set_text(p, r)
        last = p
    for p in refs[1:]:
        remove(p._p)


def check(out):
    chk = docx.Document(out)
    paras = [p.text for p in chk.paragraphs]
    text = "\n".join(paras)
    stale = [s for s in STALE if s in text]
    caps_t = [m for m in re.findall(r"^Table (A?\d+):", text, flags=re.M)]
    caps_f = [m for m in re.findall(r"^Figure (A?\d+):", text, flags=re.M)]
    imgs = len(chk.inline_shapes)
    # every in-text citation (Author, year) must be in the reference list and vice versa
    refs_start = paras.index("References")
    ref_list = paras[refs_start + 1:]
    keys = set()
    for r in ref_list:
        m = re.match(r"^([^,(]+?)[,.(].*?\((\d{4})\)", r)
        if m:
            keys.add((m.group(1).split()[0].strip(","), m.group(2)))
    body = "\n".join(paras[:refs_start])
    missing = [k for k in sorted(keys) if not re.search(rf"{re.escape(k[0])}[^()]{{0,60}}?\(?{k[1]}", body)]
    cited = set(re.findall(r"([A-Z][A-Za-zÀ-ÿ-]+)(?: et al\.)?(?:,| &[^,()]+,| and [^,()]+)? \(?(\d{4})\)?", body))
    known = {k[0] for k in keys}
    unlisted = sorted({c for c in cited if c[0] not in known and c not in {(k[0], k[1]) for k in keys}
                       and c[0] not in ("Table", "Figure", "Section", "Appendix", "GDPR", "Article", "FCRA", "Equation",
                                        "Examiners", "Pozzolo", "September", "Society", "Transaction")})
    wrong_year = sorted({c for c in cited if c[0] in known and c not in keys})
    print(f"saved {out}")
    print("stale strings:", stale or "none")
    print("tables:", caps_t, "| tables in doc:", len(chk.tables))
    print("figures:", caps_f, "| images:", imgs)
    print("references never cited (check):", missing or "none")
    print("possible citations without reference (check):", unlisted[:30] or "none")
    print("citations whose year differs from the reference list:", wrong_year or "none")
    assert not stale, stale
    assert caps_t == ["1", "2", "3", "4", "5", "6", "7", "A1", "A2", "A3"], caps_t
    assert caps_f == ["1", "2", "3", "4", "5", "A1"], caps_f


if __name__ == "__main__":
    main()
