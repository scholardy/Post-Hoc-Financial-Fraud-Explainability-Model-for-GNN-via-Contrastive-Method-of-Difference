"""Word (.docx) editing helpers shared by update_paper.py (copied from the LS-GAT paper script)."""
import copy

import docx
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt
from docx.text.paragraph import Paragraph


# ------------------------------------------------------------------ docx helpers
class Doc:
    def __init__(self, path):
        self.d = docx.Document(path)

    def find(self, prefix):
        hits = [p for p in self.d.paragraphs if p.text.strip().startswith(prefix)]
        if not hits:
            raise KeyError(f"paragraph not found: {prefix!r}")
        return hits[0]


def has_math(p):
    return bool(p._p.findall(".//{http://schemas.openxmlformats.org/officeDocument/2006/math}oMath"))


def set_text(p, text, bold_label=None, italic=None, size=None):
    """Replace a paragraph's text, keeping its paragraph and font formatting. Refuses paragraphs with equations."""
    assert not has_math(p), f"refusing to overwrite equation paragraph: {p.text[:60]}"
    first_rpr = None
    runs_with_rpr = [r for r in p._p.iter(qn("w:r")) if r.find(qn("w:rPr")) is not None]
    texted = [r for r in runs_with_rpr if r.findtext(qn("w:t"))]
    for r in (texted or runs_with_rpr):
        rpr = r.find(qn("w:rPr"))
        if rpr is not None:
            first_rpr = copy.deepcopy(rpr)
            for tag in ("w:color", "w:highlight", "w:shd"):
                for e in first_rpr.findall(qn(tag)):
                    first_rpr.remove(e)
            break
    for child in list(p._p):
        if child.tag in (qn("w:r"), qn("w:hyperlink"), qn("w:ins"), qn("w:proofErr")):
            p._p.remove(child)

    def run(t):
        r = p.add_run(t)
        if first_rpr is not None:
            r._r.insert(0, copy.deepcopy(first_rpr))
        r.bold = None
        r.italic = None
        r.underline = None
        return r

    if bold_label and text.startswith(bold_label):
        run(bold_label).bold = True
        text = text[len(bold_label):]
    r = run(text)
    if italic is not None:
        r.italic = italic
    if size:
        for rr in p.runs:
            rr.font.size = Pt(size)
    return p


def new_par_after(anchor_el, like=None, text="", align=None, italic=None, size=None):
    el = OxmlElement("w:p")
    anchor_el.addnext(el)
    p = Paragraph(el, like._parent if like is not None else None)
    if like is not None and like._p.pPr is not None:
        ppr = copy.deepcopy(like._p.pPr)
        for numpr in ppr.findall(qn("w:numPr")):
            ppr.remove(numpr)
        el.insert(0, ppr)
    like_rpr = None
    if like is not None:
        for r0 in like._p.iter(qn("w:r")):
            if r0.find(qn("w:rPr")) is not None and r0.findtext(qn("w:t")):
                like_rpr = copy.deepcopy(r0.find(qn("w:rPr")))
                for tag in ("w:color", "w:highlight", "w:shd", "w:b", "w:i"):
                    for e in like_rpr.findall(qn(tag)):
                        like_rpr.remove(e)
                break
    r = p.add_run(text or "")
    if like_rpr is not None:
        r._r.insert(0, like_rpr)
    if italic is not None:
        r.italic = italic
    if size:
        r.font.size = Pt(size)
    if align is not None:
        p.alignment = align
    return p


def new_par_before(el, like, text, **kw):
    p = new_par_after(like._p, like=like, text=text, **kw)
    el.addprevious(p._p)
    return p


def add_figure(doc, caption_par, img, caption, width=5.8):
    """caption_par becomes the caption; the image goes in a new paragraph just above it."""
    el = OxmlElement("w:p")
    caption_par._p.addprevious(el)
    ip = Paragraph(el, caption_par._parent)
    ip.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ip.add_run().add_picture(str(img), width=Inches(width))
    set_text(caption_par, caption, italic=True, size=9)
    caption_par.alignment = WD_ALIGN_PARAGRAPH.CENTER


def build_table(doc, header, rows, style, size=8, bold=(), underline=()):
    t = doc.d.add_table(rows=1 + len(rows), cols=len(header))
    if style is not None:
        t.style = style
    for j, h in enumerate(header):
        _cell(t.rows[0].cells[j], h, size, bold=True)
    for i, row in enumerate(rows, 1):
        for j, v in enumerate(row):
            _cell(t.rows[i].cells[j], v, size, bold=(i - 1, j) in bold, underline=(i - 1, j) in underline)
    return t


def _cell(cell, text, size, bold=False, underline=False):
    p = cell.paragraphs[0]
    for r in list(p.runs):
        r._r.getparent().remove(r._r)
    r = p.add_run(str(text))
    r.font.size = Pt(size)
    r.font.name = "Times New Roman"
    r.bold = bold or None
    r.underline = underline or None
    pf = p.paragraph_format  # compact, uniform rows
    pf.space_before = Pt(1)
    pf.space_after = Pt(1)
    pf.line_spacing = 1.0


def swap_table(old, new):
    old._tbl.addprevious(new._tbl)
    old._tbl.getparent().remove(old._tbl)


def remove(el):
    el.getparent().remove(el)


def fmt(v, nd=3):
    if v is None or (isinstance(v, float) and v != v):
        return "–"
    return f"{v:.{nd}f}" if isinstance(v, (float, int)) else str(v)


