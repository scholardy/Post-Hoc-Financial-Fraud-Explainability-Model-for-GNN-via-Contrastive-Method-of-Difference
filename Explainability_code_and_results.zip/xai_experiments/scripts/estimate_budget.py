"""Estimate the full Kaggle run time from the pilot logs (logs/pilot_gpu*.log).

Each stage's pilot time is scaled by (full work units / pilot work units), where a work unit is one explained
target (stability targets count 1 + number of stability re-runs)."""
import glob
import json
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
C = json.load(open(os.path.join(ROOT, "configs", "xai.json")))
P = dict(C)
for k, v in C["profiles"]["pilot"].items():
    P[k] = v if not isinstance(v, dict) else {**C.get(k, {}), **v}


def units(c, stage):
    r = c["stability"]["runs"] if "stability" in c else C["stability"]["runs"]
    if stage == "perf":
        return c["perf_seeds"]
    if stage == "main":
        return c["n_instances"] + r * c["n_stability"]
    if stage == "arch":
        return c["n_arch"]
    if stage == "ablation":
        return c["n_ablation"] + r * c["n_stability"]
    if stage == "sensitivity":
        return c["sensitivity"]["n"]
    if stage == "scalability":
        return c["scalability"]["n"]
    return 1


total = {}
for log in sorted(glob.glob(os.path.join(ROOT, "logs", "pilot_gpu*.log"))):
    gpu = os.path.basename(log)
    for line in open(log, encoding="utf-8", errors="ignore"):
        m = re.match(r"== (\w+) (\w+) done in (\d+) s", line)
        if m:
            ds, st, sec = m.group(1), m.group(2), int(m.group(3))
            # credit card has only ~55 detected test frauds: main/ablation are capped there
            f = units(C, st) / max(units(P, st), 1)
            est = sec * f
            total[gpu] = total.get(gpu, 0) + est
            print(f"{gpu:28s} {ds:10s} {st:12s} pilot {sec:6d} s -> full ~{est / 3600:5.2f} h")
for gpu, sec in total.items():
    print(f"{gpu}: estimated full run ~{sec / 3600:.1f} h (upper bound; Credit Card has fewer targets)")
