"""Explanation methods for one target transaction (an Instance).

Every method returns an Explanation:
  node_score [n], edge_score [E], feat_score [d] or None  - importance scores (higher = more important)
  edge_keep [E] bool, feat_keep [d] bool                 - the explanation at the method's default budget
All methods run on the same MaskedGNN forward pass (same weights, same masking semantics).

Methods
  ours        Contrastive method-of-difference explainer (paper Sec. 3): nearest legitimate references in the
              final-layer embedding space, contrastive gradient x difference attribution, ensemble over m
              references, greedy fidelity-constrained pruning (Algorithm 2).
  gnnexplainer  Ying et al. (2019); loss and coefficients as in PyTorch Geometric's GNNExplainer.
  pgexplainer   Luo et al. (2020); MLP over [z_u, z_v, z_target], trained on validation-period instances;
                coefficients as in PyTorch Geometric's PGExplainer.
  subgraphx     Yuan et al. (2021); Monte-Carlo tree search over connected subgraphs that contain the target,
                scored by Monte-Carlo L-hop Shapley values with zero-filling (as in DIG's implementation).
  gradcam       Pope et al. (2019); Grad-CAM on the input node embeddings (the only layer whose every node
                influences the target's prediction in node classification).
  random        random edge scores (sanity baseline).
"""
import math
import time
from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn.functional as F

from .core import Instance, Setup, make_instance, prob_single, prob_variants, scatter_sum, target_embedding

EPS = 1e-15


@dataclass
class Explanation:
    method: str
    node_score: np.ndarray
    edge_score: np.ndarray
    feat_score: object
    edge_keep: torch.Tensor
    feat_keep: torch.Tensor
    seconds: float = 0.0
    extra: dict = field(default_factory=dict)


# ------------------------------------------------------------------ helpers
def topk_edges(inst: Instance, edge_score, frac):
    E = inst.e
    keep = torch.zeros(E, dtype=torch.bool, device=inst.x.device)
    if E == 0:
        return keep
    k = max(1, int(math.ceil(frac * E)))
    idx = torch.as_tensor(np.argsort(-np.asarray(edge_score), kind="stable")[:k], device=inst.x.device)
    keep[idx] = True
    return keep


def budget_edges(inst: Instance, edge_score, frac):
    """Explanation of a fixed size for edge-scoring methods: add edges in descending score (with their endpoint
    nodes) while |V_s| + |E_s| <= ceil(frac * (|V| + |E|)); V_s always contains the target. Every method is given
    the same element budget as Algorithm 2, so explanations of different methods have comparable size."""
    E = inst.e
    keep = torch.zeros(E, dtype=torch.bool, device=inst.x.device)
    if E == 0:
        return keep
    budget = int(math.ceil(frac * (inst.n + E)))
    src, dst = (t.cpu().numpy() for t in inst.ei)
    nodes = {0}
    size = 1
    for i in np.argsort(-np.asarray(edge_score), kind="stable"):
        new = {int(src[i]), int(dst[i])} - nodes
        if size + 1 + len(new) > budget:
            continue
        keep[int(i)] = True
        nodes |= new
        size += 1 + len(new)
        if size >= budget:
            break
    if not keep.any():  # budget smaller than one edge: keep the best edge
        keep[int(np.argmax(edge_score))] = True
    return keep


def edges_within(inst: Instance, node_set_mask):
    s, d = inst.ei
    return node_set_mask[s] & node_set_mask[d]


def logit_grads(S: Setup, inst: Instance, x=None, wrt_h0=False):
    """d logit(target) / d x  (and d / d edge multiplier). With wrt_h0: gradient w.r.t. input embeddings."""
    x = (inst.x if x is None else x).detach()
    w = torch.ones(inst.e, device=x.device, requires_grad=True)
    if wrt_h0:
        h0 = S.net.input_embed(x).detach().requires_grad_(True)
        lg = S.net(x, inst.ei, deg=inst.deg, w=w, h0=h0)[0]
        g_h0, g_w = torch.autograd.grad(lg, [h0, w], allow_unused=True)
        return h0.detach(), g_h0, (torch.zeros_like(w) if g_w is None else g_w)
    xg = x.clone().requires_grad_(True)
    lg = S.net(xg, inst.ei, deg=inst.deg, w=w)[0]
    g_x, g_w = torch.autograd.grad(lg, [xg, w], allow_unused=True)
    return g_x, (torch.zeros_like(w) if g_w is None else g_w)


def _norm(a):
    m = float(a.max()) if a.numel() else 0.0
    return a / m if m > 0 else a


# ------------------------------------------------------------------ reference pool (component 1)
class ReferencePool:
    """Legitimate transactions from the validation period that the model classifies as legitimate.
    All of them precede every test-period target, so a reference never comes from the target's future."""

    def __init__(self, S: Setup, size=2000, seed=0):
        self.S = S
        va = S.g["val_idx"].numpy()
        y = S.g["y"].numpy()
        legit = va[(y[va] == 0) & (S.probs[va] < S.threshold)]
        rng = np.random.default_rng(seed)
        self.ids = np.sort(rng.choice(legit, size=min(size, len(legit)), replace=False))
        self.z = F.normalize(S.emb[torch.from_numpy(self.ids)], dim=1)
        self._cache = {}

    def nearest(self, inst, m):
        """m most similar references by cosine similarity of the final-layer embedding (computed from the
        target's own subgraph, so a perturbed target gets its own references)."""
        z = F.normalize(target_embedding(self.S, inst)[None], dim=1)
        sim = (self.z @ z.T).squeeze(1)
        top = torch.topk(sim, min(m, len(self.ids))).indices.numpy()
        return [int(self.ids[i]) for i in top], [float(sim[i]) for i in top]

    def ref_instance(self, rid):
        if rid not in self._cache:
            self._cache[rid] = make_instance(self.S, rid)
        return self._cache[rid]

    def _ref_layers(self, rid):
        key = ("layers", rid)
        if key not in self._cache:
            R = self.ref_instance(rid)
            with torch.no_grad():
                _, _, _, Hs = self.S.net(R.x, R.ei, deg=R.deg, return_layers=True)
            self._cache[key] = [h.detach() for h in Hs]
        return self._cache[key]

    def counterpart_messages(self, inst: Instance, rid):
        """Legitimate counterpart of every edge's message, per layer: the message that the reference's nodes at the
        same hop distance as the edge's sender send on average (in the layer's message space)."""
        R = self.ref_instance(rid)
        out = []
        src = inst.ei[0]
        hop_src = torch.as_tensor(inst.hop, device=inst.x.device)[src]
        for li, H in enumerate(self._ref_layers(rid)):
            M = self.S.net.message_space(li, H)
            allmean = M.mean(0)
            table = torch.stack([M[torch.as_tensor(R.hop == h, device=M.device)].mean(0)
                                 if (R.hop == h).any() else allmean for h in range(int(inst.hop.max()) + 1)])
            out.append(table[hop_src])
        return out

    def counterpart(self, inst: Instance, rid):
        """Legitimate counterpart of every node of the target subgraph: the reference transaction itself for
        the target, and the mean of the reference's nodes at the same hop distance for the other nodes."""
        R = self.ref_instance(rid)
        xt = torch.empty_like(inst.x)
        allmean = R.x.mean(0)
        for h in np.unique(inst.hop):
            sel = torch.as_tensor(inst.hop == h, device=inst.x.device)
            rsel = torch.as_tensor(R.hop == h, device=R.x.device)
            xt[sel] = R.x[rsel].mean(0) if bool(rsel.any()) else allmean
        return xt


# ------------------------------------------------------------------ ours: components 2-4
def prune(S: Setup, inst: Instance, cg_v, cg_e, cg_x, tau=0.05, k_frac=0.2, use_budget=True, prune_features=True):
    """Algorithm 2: remove elements in ascending importance while |f(G_i) - f(G_s)| < tau and |G_s| > k."""
    n, E, d = inst.n, inst.e, inst.d
    dev = inst.x.device
    node_keep = torch.ones(n, dtype=torch.bool, device=dev)
    edge_keep = torch.ones(E, dtype=torch.bool, device=dev)
    feat_keep = torch.ones(d, dtype=torch.bool, device=dev)
    budget = int(math.ceil(k_frac * (n + E))) if use_budget else 0
    k_nodes = max(1, int(math.ceil(k_frac * n))) if use_budget else 1
    k_edges = int(math.ceil(k_frac * E)) if use_budget else 0
    k_feats = max(1, int(math.ceil(k_frac * d))) if use_budget else 1
    v, e, x = _norm(cg_v.clone()), _norm(cg_e.clone()), _norm(cg_x.clone())
    rank = [("n", i, float(v[i])) for i in range(1, n)] + [("e", i, float(e[i])) for i in range(E)]
    if prune_features:
        rank += [("f", i, float(x[i])) for i in range(d)]
    rank.sort(key=lambda t: t[2])
    p0 = inst.p
    src, dst = inst.ei
    n_forward = 0
    for kind, i, _ in rank:
        if kind == "n":
            if int(node_keep.sum()) <= k_nodes:
                continue
            node_keep[i] = False
        elif kind == "e":
            if int(edge_keep.sum()) <= k_edges:
                continue
            edge_keep[i] = False
        else:
            if int(feat_keep.sum()) <= k_feats:
                continue
            feat_keep[i] = False
        eff = edge_keep & node_keep[src] & node_keep[dst]
        p_s = prob_single(S, inst, inst.x * feat_keep.float()[None], eff)
        n_forward += 1
        vs = torch.zeros(n, dtype=torch.bool, device=dev)
        vs[0] = True
        vs[src[eff]] = True
        vs[dst[eff]] = True
        size = int(vs.sum()) + int(eff.sum())
        if not (abs(p0 - p_s) < tau and size > budget):
            if kind == "n":
                node_keep[i] = True
            elif kind == "e":
                edge_keep[i] = True
            else:
                feat_keep[i] = True
    eff = edge_keep & node_keep[src] & node_keep[dst]
    return node_keep, eff, feat_keep, n_forward


def contrast_scores(S: Setup, inst: Instance, pool: ReferencePool, ref_ids, mode="grad", contrastive=True,
                    signed=True, seed=0):
    """Contrastive attribution (component 2) averaged over the references (component 4).

    For each element, the score estimates how much the target's fraud logit would fall if that element were
    switched to its state in the legitimate reference (Mill's method of difference: change one factor, keep the
    rest, observe the outcome):
      node v     : sum_k df/dx_vk (x_vk - x~_vk), x~ = reference counterpart features (hop-matched)
      feature k  : sum_v df/dx_vk (x_vk - x~_vk)
      edge e=u->v: sum_l <df/dm_e^l, m_e^l - m~_e^l>, m_e^l = message sent on e at layer l,
                   m~_e^l = the message the reference's nodes at the same hop send at layer l
    signed=True keeps only evidence FOR fraud (positive part); signed=False uses absolute values.
    contrastive=False replaces the references by zero (the training mean): plain gradient x input.
    mode 'exact' : the same switches computed exactly (one forward pass per element) instead of by gradients.
    mode 'random': random scores (ablation without attribution)."""
    src, dst = inst.ei
    dev = inst.x.device
    E, L = inst.e, S.layers
    if mode == "random":
        rng = torch.Generator().manual_seed(seed + inst.gid)
        v, x = torch.rand(inst.n, generator=rng).to(dev), torch.rand(inst.d, generator=rng).to(dev)
        return v, torch.rand(E, generator=rng).to(dev), x
    act = torch.relu if signed else torch.abs
    xg = inst.x.detach().clone().requires_grad_(True)
    D = S.emb.size(1)
    offs = [torch.zeros(E, D, device=dev, requires_grad=True) for _ in range(L)]
    lg, _, _, Hs = S.net(xg, inst.ei, deg=inst.deg, offsets=offs, return_layers=True)
    msgs = [S.net.message_space(li, Hs[li].detach())[src].detach() for li in range(L)]
    if mode == "grad":
        grads = torch.autograd.grad(lg[0], [xg] + offs)
        g_x, g_off = grads[0], grads[1:]
    V = torch.zeros(inst.n, device=dev)
    Ed = torch.zeros(E, device=dev)
    Xf = torch.zeros(inst.d, device=dev)
    for rid in ref_ids:
        if contrastive:
            xt, mt = pool.counterpart(inst, rid), pool.counterpart_messages(inst, rid)
        else:
            xt, mt = torch.zeros_like(inst.x), [torch.zeros_like(m) for m in msgs]
        if mode == "grad":
            c = g_x * (inst.x - xt)
            v, xf = act(c.sum(1)), act(c.sum(0))
            e = act(sum((g_off[li] * (msgs[li] - mt[li])).sum(1) for li in range(L))) if E else torch.zeros(0, device=dev)
        else:  # exact switches
            xs = inst.x[None].repeat(inst.n, 1, 1)
            idx = torch.arange(inst.n, device=dev)
            xs[idx, idx] = xt
            pn = prob_variants(S, inst, xs)
            xf_var = inst.x[None].repeat(inst.d, 1, 1)
            k = torch.arange(inst.d, device=dev)
            xf_var[k, :, k] = xt[:, k].T
            pf = prob_variants(S, inst, xf_var)
            pe = _exact_message_switch(S, inst, [mt[li] - msgs[li] for li in range(L)])
            v, xf, e = act(inst.p - pn), act(inst.p - pf), act(inst.p - pe)
        V += _norm(v); Ed += _norm(e); Xf += _norm(xf)
    m = len(ref_ids)
    return V / m, Ed / m, Xf / m


@torch.no_grad()
def _exact_message_switch(S, inst, delta, chunk=32):
    """Fraud probability when the messages of ONE edge (all layers) are replaced by their counterparts, for every
    edge. delta: list per layer of [E, D] = counterpart - actual message."""
    E, n, dev = inst.e, inst.n, inst.x.device
    out = []
    for s0 in range(0, E, chunk):
        s1 = min(E, s0 + chunk)
        b = s1 - s0
        off = (torch.arange(b, device=dev) * n)[:, None]
        src = (inst.ei[0][None] + off).reshape(-1)
        dst = (inst.ei[1][None] + off).reshape(-1)
        offsets = []
        for dl in delta:
            o = torch.zeros(b, E, dl.size(1), device=dev)
            o[torch.arange(b, device=dev), torch.arange(s0, s1, device=dev)] = dl[s0:s1]
            offsets.append(o.reshape(b * E, -1))
        lg = S.net(inst.x.repeat(b, 1), torch.stack([src, dst]), deg=inst.deg.repeat(b), offsets=offsets)
        out.append(torch.sigmoid(lg.view(b, n)[:, 0]))
    return torch.cat(out) if out else torch.zeros(0, device=dev)


def ours(S: Setup, inst: Instance, pool: ReferencePool, m=3, tau=0.05, k_frac=0.2, contrastive=True, signed=True,
         mode="grad", use_budget=True, prune_features=True, use_pruning=True, seed=0):
    """Contrastive method-of-difference explainer (components 1-4).
    use_pruning=False: skip Algorithm 2 and take the highest-scoring edges within the same element budget."""
    t0 = time.perf_counter()
    refs = pool.nearest(inst, m)
    ref_ids = refs[0][:m]
    cg_v, cg_e, cg_x = contrast_scores(S, inst, pool, ref_ids, mode, contrastive, signed, seed)
    t_attr = time.perf_counter() - t0
    if use_pruning:
        node_keep, eff, feat_keep, nf = prune(S, inst, cg_v, cg_e, cg_x, tau, k_frac, use_budget, prune_features)
    else:
        eff = budget_edges(inst, cg_e.cpu().numpy(), k_frac)
        node_keep = torch.ones(inst.n, dtype=torch.bool, device=inst.x.device)
        feat_keep = torch.ones(inst.d, dtype=torch.bool, device=inst.x.device)
        nf = 0
    return Explanation("ours", cg_v.cpu().numpy(), cg_e.cpu().numpy(), cg_x.cpu().numpy(), eff, feat_keep,
                       time.perf_counter() - t0,
                       {"refs": ref_ids, "ref_sims": refs[1][:m], "n_forward": nf, "attr_seconds": t_attr,
                        "node_keep": node_keep.cpu().numpy()})


# ------------------------------------------------------------------ GNNExplainer
def gnnexplainer(S: Setup, inst: Instance, k_frac=0.2, epochs=100, lr=0.01, seed=0,
                 edge_size=0.005, edge_ent=1.0, feat_size=1.0, feat_ent=0.1):
    t0 = time.perf_counter()
    torch.manual_seed(seed)
    dev = inst.x.device
    n, E, d = inst.n, inst.e, inst.d
    std = torch.nn.init.calculate_gain("relu") * math.sqrt(2.0 / (2 * n))
    ep = torch.nn.Parameter(torch.randn(E, device=dev) * std)
    fp = torch.nn.Parameter(torch.randn(1, d, device=dev) * 0.1)
    opt = torch.optim.Adam([ep, fp], lr=lr)
    target = torch.tensor(1.0 if inst.p >= S.threshold else 0.0, device=dev)
    for _ in range(epochs):
        opt.zero_grad()
        mk, fm = ep.sigmoid(), fp.sigmoid()
        lg = S.net(inst.x * fm, inst.ei, deg=inst.deg, w=mk)[0]
        loss = F.binary_cross_entropy_with_logits(lg, target)
        ent = -mk * torch.log(mk + EPS) - (1 - mk) * torch.log(1 - mk + EPS)
        loss = loss + edge_size * mk.sum() + edge_ent * ent.mean()
        fent = -fm * torch.log(fm + EPS) - (1 - fm) * torch.log(1 - fm + EPS)
        loss = loss + feat_size * fm.mean() + feat_ent * fent.mean()
        loss.backward()
        opt.step()
    es = ep.detach().sigmoid()
    fs = fp.detach().sigmoid().squeeze(0)
    src, dst = inst.ei
    ns = scatter_sum(es, dst, n) + scatter_sum(es, src, n)
    ekeep = budget_edges(inst, es.cpu().numpy(), k_frac)
    return Explanation("gnnexplainer", ns.cpu().numpy(), es.cpu().numpy(), fs.cpu().numpy(), ekeep,
                       torch.ones(d, dtype=torch.bool, device=dev), time.perf_counter() - t0)


# ------------------------------------------------------------------ PGExplainer
class PGExplainer:
    def __init__(self, S: Setup, epochs=30, lr=0.003, temp=(5.0, 2.0), bias=0.01, edge_size=0.05, edge_ent=1.0,
                 seed=0):
        torch.manual_seed(seed)
        self.S, self.epochs, self.lr, self.temp, self.bias = S, epochs, lr, temp, bias
        self.edge_size, self.edge_ent, self.seed = edge_size, edge_ent, seed
        H = S.emb.size(1)
        self.mlp = torch.nn.Sequential(torch.nn.Linear(3 * H, 64), torch.nn.ReLU(), torch.nn.Linear(64, 1)).to(S.device)
        self.train_seconds = 0.0

    def _z(self, inst):
        with torch.no_grad():
            _, _, z = self.S.net(inst.x, inst.ei, deg=inst.deg, return_all=True)
        return z

    def _logits(self, inst, z):
        s, d = inst.ei
        return self.mlp(torch.cat([z[s], z[d], z[0].expand(inst.e, -1)], dim=1)).squeeze(-1)

    def fit(self, instances):
        t0 = time.perf_counter()
        opt = torch.optim.Adam(self.mlp.parameters(), lr=self.lr)
        rng = np.random.default_rng(self.seed)
        zs = [self._z(i) for i in instances]
        for epoch in range(self.epochs):
            t = self.temp[0] * (self.temp[1] / self.temp[0]) ** (epoch / self.epochs)
            for j in rng.permutation(len(instances)):
                inst, z = instances[j], zs[j]
                if inst.e == 0:
                    continue
                opt.zero_grad()
                lo = self._logits(inst, z)
                eps = (1 - 2 * self.bias) * torch.rand_like(lo) + self.bias
                mk = ((eps.log() - (1 - eps).log() + lo) / t).sigmoid()
                lg = self.S.net(inst.x, inst.ei, deg=inst.deg, w=mk)[0]
                target = torch.tensor(1.0 if inst.p >= self.S.threshold else 0.0, device=lg.device)
                loss = F.binary_cross_entropy_with_logits(lg, target)
                ent = -mk * torch.log(mk + EPS) - (1 - mk) * torch.log(1 - mk + EPS)
                loss = loss + self.edge_size * mk.sum() + self.edge_ent * ent.mean()
                loss.backward()
                opt.step()
        self.train_seconds = time.perf_counter() - t0
        return self

    def explain(self, inst, k_frac=0.2):
        t0 = time.perf_counter()
        with torch.no_grad():
            es = self._logits(inst, self._z(inst)).sigmoid() if inst.e else torch.zeros(0, device=inst.x.device)
        src, dst = inst.ei
        ns = scatter_sum(es, dst, inst.n) + scatter_sum(es, src, inst.n)
        ekeep = budget_edges(inst, es.cpu().numpy(), k_frac)
        return Explanation("pgexplainer", ns.cpu().numpy(), es.cpu().numpy(), None, ekeep,
                           torch.ones(inst.d, dtype=torch.bool, device=inst.x.device), time.perf_counter() - t0)


# ------------------------------------------------------------------ Grad-CAM
def gradcam(S: Setup, inst: Instance, k_frac=0.2):
    t0 = time.perf_counter()
    h0, g, _ = logit_grads(S, inst, wrt_h0=True)
    alpha = g.mean(0)
    cam = F.relu((h0 * alpha[None]).sum(1))
    src, dst = inst.ei
    es = 0.5 * (cam[src] + cam[dst])
    ekeep = budget_edges(inst, es.cpu().numpy(), k_frac)
    return Explanation("gradcam", cam.cpu().numpy(), es.cpu().numpy(), None, ekeep,
                       torch.ones(inst.d, dtype=torch.bool, device=inst.x.device), time.perf_counter() - t0)


def random_expl(S: Setup, inst: Instance, k_frac=0.2, seed=0):
    t0 = time.perf_counter()
    rng = np.random.default_rng(seed + inst.gid)
    es = rng.random(inst.e)
    ns = rng.random(inst.n)
    return Explanation("random", ns, es, None, budget_edges(inst, es, k_frac),
                       torch.ones(inst.d, dtype=torch.bool, device=inst.x.device), time.perf_counter() - t0)


# ------------------------------------------------------------------ SubgraphX (node classification)
class _TreeNode:
    __slots__ = ("coal", "children", "W", "N", "P")

    def __init__(self, coal):
        self.coal = coal
        self.children = None
        self.W = 0.0
        self.N = 0
        self.P = None


def subgraphx(S: Setup, inst: Instance, k_frac=0.2, rollouts=20, expand_atoms=6, sample_num=50, c_puct=10.0,
              min_frac=0.05, seed=0, budgets=(0.05, 0.1, 0.2, 0.3, 0.5)):
    t0 = time.perf_counter()
    rng = np.random.default_rng(seed + inst.gid)
    n = inst.n
    dev = inst.x.device
    src, dst = (t.cpu().numpy() for t in inst.ei)
    nbr = [set() for _ in range(n)]
    for a, b in zip(src, dst):
        nbr[a].add(b); nbr[b].add(a)
    L = S.layers

    def component(coal):
        # connected component (undirected, induced) that contains the target node 0
        coal = set(coal)
        seen, stack = {0}, [0]
        while stack:
            u = stack.pop()
            for v in nbr[u]:
                if v in coal and v not in seen:
                    seen.add(v); stack.append(v)
        return frozenset(seen)

    def local_players(coal):
        frontier, seen = set(coal), set(coal)
        for _ in range(L):
            nxt = set()
            for u in frontier:
                nxt |= nbr[u]
            nxt -= seen
            seen |= nxt
            frontier = nxt
        return [u for u in seen if u not in coal]

    def shapley(coals):
        """Monte-Carlo L-hop Shapley value of each coalition (zero-filling of excluded nodes)."""
        masks_in, masks_ex = [], []
        for coal in coals:
            players = local_players(coal)
            cl = np.fromiter(coal, dtype=np.int64)
            for _ in range(sample_num):
                perm = rng.permutation(len(players) + 1)  # index len(players) = the coalition as one player
                pos = int(np.flatnonzero(perm == len(players))[0])
                before = [players[i] for i in perm[:pos]]
                ex = np.zeros(n, dtype=bool)
                ex[before] = True
                inc = ex.copy()
                inc[cl] = True
                masks_in.append(inc); masks_ex.append(ex)
        mi = torch.as_tensor(np.stack(masks_in), device=dev)
        me = torch.as_tensor(np.stack(masks_ex), device=dev)
        x = inst.x[None]
        p_in = prob_variants(S, inst, x * mi[..., None].float())
        p_ex = prob_variants(S, inst, x * me[..., None].float())
        return (p_in - p_ex).view(len(coals), sample_num).mean(1).cpu().numpy()

    min_atoms = max(2, int(math.ceil(min_frac * n)))
    root = _TreeNode(component(range(n)))
    root.P = float(shapley([root.coal])[0])
    table = {root.coal: root}

    def expand(node):
        coal = node.coal
        # high-to-low degree order inside the coalition (DIG 'high2low'); the target is never removed
        cand = sorted((u for u in coal if u != 0), key=lambda u: -len(nbr[u] & coal))[:expand_atoms]
        kids, new = [], []
        for u in cand:
            c = component(coal - {u})
            if c == coal:
                continue
            if c not in table:
                table[c] = _TreeNode(c)
                new.append(table[c])
            if table[c] not in kids:
                kids.append(table[c])
        if new:
            vals = shapley([k.coal for k in new])
            for k, v in zip(new, vals):
                k.P = float(v)
        node.children = kids

    for _ in range(rollouts):
        path, cur = [root], root
        while len(cur.coal) > min_atoms:
            if cur.children is None:
                expand(cur)
            if not cur.children:
                break
            tot = sum(c.N for c in cur.children)
            cur = max(cur.children, key=lambda c: (c.W / c.N if c.N else 0.0)
                      + c_puct * c.P * math.sqrt(tot) / (1 + c.N))
            path.append(cur)
        v = cur.P
        for nd in path:
            nd.N += 1
            nd.W += v

    explored = [nd for nd in table.values() if nd.P is not None]

    def size_of(coal):
        m = np.zeros(n, dtype=bool)
        m[list(coal)] = True
        return int(m.sum() + (m[src] & m[dst]).sum())

    def best(max_size):
        ok = [nd for nd in explored if size_of(nd.coal) <= max_size]
        if not ok:
            ok = [min(explored, key=lambda nd: len(nd.coal))]
        return max(ok, key=lambda nd: nd.P)

    def to_masks(coal):
        m = torch.zeros(n, dtype=torch.bool, device=dev)
        m[torch.as_tensor(sorted(coal), device=dev)] = True
        return m, edges_within(inst, m)

    per_budget = {}
    for b in budgets:
        nd = best(int(math.ceil(b * (n + inst.e))))
        per_budget[b] = to_masks(nd.coal)[1]
    nd = best(int(math.ceil(k_frac * (n + inst.e))))
    nmask, ekeep = to_masks(nd.coal)
    node_score = np.zeros(n)
    for nd2 in explored:  # node score = best Shapley value of an explored subgraph containing the node
        for u in nd2.coal:
            node_score[u] = max(node_score[u], nd2.P)
    es = 0.5 * (node_score[src] + node_score[dst]) + ekeep.cpu().numpy().astype(float)
    return Explanation("subgraphx", node_score, es, None, ekeep, torch.ones(inst.d, dtype=torch.bool, device=dev),
                       time.perf_counter() - t0, {"per_budget": per_budget, "tree_size": len(explored)})
