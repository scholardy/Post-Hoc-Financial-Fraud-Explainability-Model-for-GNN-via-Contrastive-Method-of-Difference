"""Shared machinery for explaining the trained transaction-level GNNs.

* load_setup(): rebuild the cached causal transaction graph, load a trained GCN / GraphSAGE / GAT checkpoint,
  compute every transaction's fraud probability and final-layer embedding on the full graph.
* Instance: the L-hop computation subgraph of one target transaction (incoming edges only, because messages
  flow from earlier to later transactions). For an L-layer GNN this subgraph determines the target's
  prediction exactly; `check_exact` verifies that against the full-graph output.
* MaskedGNN: a functional forward pass that re-uses the checkpoint's weights and supports
  - soft edge masks (messages are multiplied by the mask, as in PyTorch Geometric's explain API),
  - hard edge removal (the edge is deleted: GCN degrees, GraphSAGE means and GAT softmaxes are recomputed),
  - feature masks (a masked feature is set to 0 = its training-period mean, features are standardised),
  - batches of B variants of the same subgraph in one call.
"""
import os
import sys
from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn.functional as F

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from lsgat import checkpoint as lsgat_ckpt  # noqa: E402
from lsgat.data.graph import load_or_build  # noqa: E402
from lsgat.models import build_model  # noqa: E402
from lsgat.train import graph_input  # noqa: E402

MODEL_DISPLAY = {"gcn": "GCN", "sage": "GraphSAGE", "gat": "GAT"}


def scatter_sum(src, index, n):
    out = torch.zeros((n,) + src.shape[1:], dtype=src.dtype, device=src.device)
    return out.index_add_(0, index, src)


def scatter_softmax(e, index, n):
    """softmax of e grouped by index (e: [E, H])."""
    mx = torch.full((n,) + e.shape[1:], -1e30, dtype=e.dtype, device=e.device)
    mx = mx.scatter_reduce(0, index.view(-1, *([1] * (e.dim() - 1))).expand_as(e), e, reduce="amax",
                           include_self=True)
    ex = torch.exp(e - mx[index])
    den = scatter_sum(ex, index, n)
    return ex / (den[index] + 1e-16)


class MaskedGNN(torch.nn.Module):
    """Forward pass of a trained lsgat GCN / SAGE / GAT on an explicit edge list."""

    def __init__(self, model, kind):
        super().__init__()
        assert kind in ("gcn", "sage", "gat"), kind
        self.m = model.eval()
        self.kind = kind
        for p in self.m.parameters():
            p.requires_grad_(False)

    def input_embed(self, x):
        return F.relu(self.m.inp(x))

    def message_space(self, layer, h):
        """Map layer-input node states to the space in which messages are sent (GCN/GAT: W h, SAGE: h)."""
        if self.kind == "sage":
            return h
        return self.m.convs[layer].lin(h)

    def propagate(self, h, src, dst, n, w=None, deg=None, off=None):
        """One message-passing layer. w: per-edge multiplier (None = 1). deg: in-degree + 1 (GCN only).
        off: [E, D] offset added to every edge's message in message space (used for message-level
        contrastive gradients; zero offsets leave the output unchanged)."""
        kind = self.kind
        conv = self.m.convs[self._layer]
        if kind == "gcn":
            hw = conv.lin(h)
            dis = deg.pow(-0.5)
            coef = dis[src] * dis[dst]
            if w is not None:
                coef = coef * w
            ms = hw[src] if off is None else hw[src] + off
            out = scatter_sum(ms * coef[:, None], dst, n) + hw * (1.0 / deg)[:, None]
            return F.relu(out + conv.bias)
        if kind == "sage":
            ms = h[src] if off is None else h[src] + off
            msg = ms if w is None else ms * w[:, None]
            cnt = scatter_sum(torch.ones_like(src, dtype=h.dtype), dst, n).clamp(min=1.0)
            agg = scatter_sum(msg, dst, n) / cnt[:, None]
            return F.relu(conv.lin_l(agg) + conv.lin_r(h))
        H, C = conv.heads, conv.out_channels  # GAT with self loops
        xs = conv.lin(h).view(-1, H, C)
        a_s = (xs * conv.att_src).sum(-1)
        a_d = (xs * conv.att_dst).sum(-1)
        loop = torch.arange(n, device=h.device)
        s2, d2 = torch.cat([src, loop]), torch.cat([dst, loop])
        e = F.leaky_relu(a_s[s2] + a_d[d2], conv.negative_slope)
        alpha = scatter_softmax(e, d2, n)
        if w is not None:
            alpha = alpha * torch.cat([w, torch.ones(n, dtype=w.dtype, device=w.device)])[:, None]
        xm = xs[s2]
        if off is not None:  # offsets on the value vectors of the real edges (attention scores unchanged)
            xm = xm + torch.cat([off.view(-1, H, C), torch.zeros(n, H, C, dtype=xs.dtype, device=xs.device)])
        out = scatter_sum(xm * alpha[..., None], d2, n).reshape(n, H * C) + conv.bias
        return F.elu(out)

    def forward(self, x, edge_index, deg=None, w=None, return_all=False, h0=None, offsets=None,
                return_layers=False):
        """x: [n, d]; edge_index: [2, E] (src -> dst); deg: [n] in-degree+1 (GCN); w: [E] edge multipliers;
        offsets: list (one per layer) of [E, D] message offsets.
        Returns logits for every node ([n]); with return_all also (h0, final embeddings);
        with return_layers also the list of layer-input node states."""
        n = x.size(0)
        src, dst = edge_index[0], edge_index[1]
        h = self.input_embed(x) if h0 is None else h0
        h_in = h
        layer_inputs = []
        for li in range(len(self.m.convs)):
            self._layer = li
            layer_inputs.append(h)
            h = self.propagate(h, src, dst, n, w=w, deg=deg, off=None if offsets is None else offsets[li])
        logits = self.m.head(h)
        if return_layers:
            return logits, h_in, h, layer_inputs
        if return_all:
            return logits, h_in, h
        return logits


@dataclass
class Setup:
    ds: str
    model_name: str
    seed: int
    ck: dict
    g: dict
    net: MaskedGNN
    probs: np.ndarray            # full-graph fraud probability of every transaction
    emb: torch.Tensor            # full-graph final-layer embedding of every transaction (cpu)
    threshold: float
    in_ptr: np.ndarray           # CSR of incoming edges, grouped by destination
    in_src: np.ndarray
    in_eid: np.ndarray
    deg_full: np.ndarray         # in-degree + 1 on the full graph (GCN normalisation)
    device: torch.device
    layers: int


@dataclass
class Instance:
    gid: int                     # global node id of the target transaction
    nodes: np.ndarray            # global ids of subgraph nodes; nodes[0] == gid
    hop: np.ndarray              # hop distance to the target (0 = target)
    x: torch.Tensor              # [n, d] features (device)
    ei: torch.Tensor             # [2, E] local edge index (src -> dst)
    etype: np.ndarray            # [E] relation id
    deg: torch.Tensor            # [n] full-graph in-degree + 1, float (device)
    p: float = 0.0               # fraud probability of the target
    logit: float = 0.0
    extra: dict = field(default_factory=dict)

    @property
    def n(self):
        return self.x.size(0)

    @property
    def e(self):
        return self.ei.size(1)

    @property
    def d(self):
        return self.x.size(1)


_GRAPHS = {}


def get_graph(cfg, ds, device):
    if ds not in _GRAPHS:
        _GRAPHS.clear()  # keep one dataset in memory at a time
        _GRAPHS[ds] = load_or_build(cfg, ds, device)[0]
    return _GRAPHS[ds]


def load_setup(cfg, ds, model_name, seed, device, models_dir=None):
    models_dir = models_dir or cfg["paths"]["models_dir"]
    ck = lsgat_ckpt.load(os.path.join(models_dir, "main", ds, f"{model_name}_s{seed}.pt"))
    g = get_graph(cfg, ds, device)
    assert list(g["feature_names"]) == ck["feature_names"], "feature set differs from training"
    model = build_model(ck["model"], ck["in_dim"], ck["model_cfg"]).to(device)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    n = g["x"].size(0)
    x = g["x"].to(device)
    # full-graph probabilities with the original PyG model (exactly as in training / predict.py)
    with torch.no_grad():
        logits_ref = model(x, graph_input(ck["model"], g["edge_index"], n, device), None)
        probs = torch.sigmoid(logits_ref).float().cpu().numpy()
    net = MaskedGNN(model, ck["model"]).to(device)
    src, dst = g["edge_index"].numpy()
    order = np.argsort(dst, kind="stable")
    in_src, in_eid = src[order], order
    in_ptr = np.zeros(n + 1, dtype=np.int64)
    np.cumsum(np.bincount(dst, minlength=n), out=in_ptr[1:])
    deg_full = np.bincount(dst, minlength=n).astype(np.float32) + 1.0
    with torch.no_grad():
        ei_full = g["edge_index"].to(device)
        lg, _, z = net(x, ei_full, deg=torch.from_numpy(deg_full).to(device), return_all=True)
        p2 = torch.sigmoid(lg).cpu().numpy()
    err = float(np.abs(p2 - probs).max())
    assert err < 1e-4, f"masked forward differs from the PyG model on the full graph: {err}"
    return Setup(ds, model_name, seed, ck, g, net, probs, z.cpu(), float(ck["threshold"]), in_ptr, in_src,
                 in_eid, deg_full, device, int(ck["model_cfg"]["layers"]))


def make_instance(S: Setup, gid: int, hops=None) -> Instance:
    """Incoming L-hop computation subgraph of transaction gid (L = number of GNN layers by default)."""
    L = hops or S.layers
    dist = {gid: 0}
    frontier = [gid]
    nodes = [gid]
    for d in range(1, L + 1):
        nxt = []
        for v in frontier:
            for u in S.in_src[S.in_ptr[v]:S.in_ptr[v + 1]]:
                u = int(u)
                if u not in dist:
                    dist[u] = d
                    nodes.append(u)
                    nxt.append(u)
        frontier = nxt
    nodes = np.asarray(nodes, dtype=np.int64)
    loc = {int(v): i for i, v in enumerate(nodes)}
    src_l, dst_l, eids = [], [], []
    for v in nodes:
        if dist[int(v)] >= L:
            continue  # edges into frontier nodes cannot reach the target within L layers
        a, b = S.in_ptr[v], S.in_ptr[v + 1]
        for u, eid in zip(S.in_src[a:b], S.in_eid[a:b]):
            src_l.append(loc[int(u)]); dst_l.append(loc[int(v)]); eids.append(eid)
    ei = torch.tensor([src_l, dst_l], dtype=torch.long).reshape(2, -1)
    et = S.g["edge_type"].numpy()[np.asarray(eids, dtype=np.int64)] if eids else np.zeros(0, dtype=np.int64)
    inst = Instance(gid=int(gid), nodes=nodes, hop=np.array([dist[int(v)] for v in nodes]),
                    x=S.g["x"][torch.from_numpy(nodes)].to(S.device), ei=ei.to(S.device), etype=et,
                    deg=torch.from_numpy(S.deg_full[nodes]).to(S.device))
    with torch.no_grad():
        lg = S.net(inst.x, inst.ei, deg=inst.deg)[0]
    inst.logit = float(lg)
    inst.p = float(torch.sigmoid(lg))
    return inst


@torch.no_grad()
def target_embedding(S: Setup, inst: Instance):
    """Final-layer embedding of the target computed on its subgraph (identical to the full-graph embedding)."""
    _, _, z = S.net(inst.x, inst.ei, deg=inst.deg, return_all=True)
    return z[0].cpu()


def perturbed(S: Setup, inst: Instance, sigma, seed):
    """Copy of the instance with Gaussian noise (std sigma, in standardised units) on every node's features."""
    gen = torch.Generator().manual_seed(seed)
    noise = torch.randn(inst.x.shape, generator=gen).to(inst.x.device) * sigma
    new = Instance(inst.gid, inst.nodes, inst.hop, inst.x + noise, inst.ei, inst.etype, inst.deg)
    with torch.no_grad():
        lg = S.net(new.x, new.ei, deg=new.deg)[0]
    new.logit, new.p = float(lg), float(torch.sigmoid(lg))
    return new


def check_exact(S: Setup, inst: Instance, tol=1e-4):
    return abs(inst.p - float(S.probs[inst.gid])) < tol


# ------------------------------------------------------------------ batched evaluation of variants
def _batched_graph(inst: Instance, edge_keep):
    """edge_keep: [B, E] bool. Returns block-diagonal (src, dst, deg) for B copies with hard edge removal."""
    B = edge_keep.size(0)
    n, E = inst.n, inst.e
    dev = inst.x.device
    off = (torch.arange(B, device=dev) * n)[:, None]
    src = (inst.ei[0][None, :] + off)[edge_keep]
    dst = (inst.ei[1][None, :] + off)[edge_keep]
    # GCN: degrees after removing edges (in-degree + 1 minus removed incoming edges)
    removed = scatter_sum((~edge_keep).float().reshape(-1), (inst.ei[1][None, :] + off).reshape(-1), B * n)
    deg = inst.deg.repeat(B) - removed
    return src, dst, deg


@torch.no_grad()
def prob_variants(S: Setup, inst: Instance, x_var=None, edge_keep=None, chunk=256):
    """Fraud probability of the target under B variants.
    x_var: [B, n, d] features (None = original); edge_keep: [B, E] bool (None = all edges)."""
    B = x_var.size(0) if x_var is not None else edge_keep.size(0)
    out = []
    for s in range(0, B, chunk):
        e = min(B, s + chunk)
        b = e - s
        xv = inst.x[None].expand(b, -1, -1) if x_var is None else x_var[s:e]
        ek = torch.ones(b, inst.e, dtype=torch.bool, device=inst.x.device) if edge_keep is None else edge_keep[s:e]
        src, dst, deg = _batched_graph(inst, ek)
        lg = S.net(xv.reshape(b * inst.n, -1), torch.stack([src, dst]), deg=deg)
        out.append(torch.sigmoid(lg.view(b, inst.n)[:, 0]))
    return torch.cat(out)


def prob_single(S, inst, x=None, edge_keep=None):
    xv = None if x is None else x[None]
    ek = None if edge_keep is None else edge_keep[None]
    if xv is None and ek is None:
        return inst.p
    return float(prob_variants(S, inst, xv, ek)[0])
