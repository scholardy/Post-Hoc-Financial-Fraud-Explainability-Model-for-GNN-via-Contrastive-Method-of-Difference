"""Explanation-quality metrics (paper Sec. 4.4). All probabilities are the model's fraud probability for the target.

For an explanation with edge set E_s (and node set V_s = target + endpoints of E_s):
  fidelity      = 1 - |f(G) - f(G_s)| / f(G)           (sufficiency; higher is better, Eq. 12)
  fid_minus     = f(G) - f(G_s)                          (signed sufficiency gap)
  fid_plus      = f(G) - f(G \\ E_s)                     (necessity: drop when the explanation is removed)
  sparsity      = 1 - (|V_s|/|V| + |E_s|/|E|) / 2        (Eq. 13)
  disc_power    = f(G) - f(G_cf), where G_cf replaces the explanation by its legitimate counterpart:
                  the features of V_s take the values of the nearest legitimate reference (hop-matched) and
                  the edges E_s are removed (the reference does not contain them).          (Eq. 15)
  flip          = 1 if f(G_cf) falls below the model's decision threshold
"""
import numpy as np
import torch
from scipy.stats import spearmanr

from .core import prob_single, prob_variants


def node_set(inst, edge_keep):
    s, d = inst.ei
    m = torch.zeros(inst.n, dtype=torch.bool, device=inst.x.device)
    m[0] = True
    if edge_keep.any():
        m[s[edge_keep]] = True
        m[d[edge_keep]] = True
    return m


def quality(S, inst, edge_keep, x_ref):
    """x_ref: [n, d] legitimate counterpart features (same reference for every method)."""
    vs = node_set(inst, edge_keep)
    n, E = inst.n, inst.e
    x_cf = torch.where(vs[:, None], x_ref, inst.x)
    xv = torch.stack([inst.x, inst.x, x_cf])
    ek = torch.stack([edge_keep, ~edge_keep, ~edge_keep])
    p_s, p_nec, p_cf = prob_variants(S, inst, xv, ek).cpu().numpy().tolist()
    p = inst.p
    return {
        "p": p, "p_s": p_s, "p_nec": p_nec, "p_cf": p_cf,
        "fidelity": 1.0 - abs(p - p_s) / max(p, 1e-12),
        "fid_minus": p - p_s,
        "fid_plus": p - p_nec,
        "sparsity": 1.0 - (int(vs.sum()) / n + (int(edge_keep.sum()) / E if E else 0.0)) / 2.0,
        "n_nodes": int(vs.sum()), "n_edges": int(edge_keep.sum()),
        "disc_power": p - p_cf,
        "flip": float(p_cf < S.threshold),
    }


def _minmax(a):
    a = np.asarray(a, dtype=float)
    lo, hi = a.min() if a.size else 0.0, a.max() if a.size else 0.0
    return (a - lo) / (hi - lo) if hi > lo else np.zeros_like(a)


def stability(inst, runs):
    """runs: list of Explanations of the same instance (first = original input, rest = perturbed / reseeded).
    Returns Jaccard of the explanation edge sets, Spearman correlation of edge scores, edit distance
    (|E_s symmetric-difference E_s'| + |V_s symmetric-difference V_s'|) against the original, and the
    variance-based stability of Eq. 14 over all runs."""
    base = runs[0]
    be = base.edge_keep.cpu().numpy()
    bv = node_set(inst, base.edge_keep).cpu().numpy()
    jac, rho, ed = [], [], []
    for r in runs[1:]:
        e = r.edge_keep.cpu().numpy()
        v = node_set(inst, r.edge_keep).cpu().numpy()
        u = (be | e).sum()
        jac.append((be & e).sum() / u if u else 1.0)
        a, b = np.asarray(base.edge_score, float), np.asarray(r.edge_score, float)
        if a.size > 1 and a.std() > 0 and b.std() > 0:
            rho.append(float(spearmanr(a, b).statistic))
        else:
            rho.append(1.0 if np.allclose(a, b) else 0.0)
        ed.append(int((be ^ e).sum() + (bv ^ v).sum()))
    S = np.stack([_minmax(r.edge_score) for r in runs]) if inst.e else np.zeros((len(runs), 1))
    stab = 1.0 - float(((S - S.mean(0, keepdims=True)) ** 2).mean())
    return {"jaccard": float(np.mean(jac)), "spearman": float(np.mean(rho)), "edit_distance": float(np.mean(ed)),
            "stability": stab}
