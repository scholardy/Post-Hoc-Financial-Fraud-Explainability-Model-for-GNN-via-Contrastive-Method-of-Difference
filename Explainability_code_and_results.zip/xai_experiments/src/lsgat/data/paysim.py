"""PaySim synthetic mobile-money transactions (Kaggle ealaxi/paysim1)."""
import numpy as np
import pandas as pd

from ..config import resolve_path
from . import RawDataset, signed_log, subsample

BAL = ["oldbalanceOrg", "newbalanceOrig", "oldbalanceDest", "newbalanceDest"]


def load_paysim(cfg_ds: dict, seed: int = 0) -> RawDataset:
    path = resolve_path(cfg_ds["raw"]["csv"])
    df = pd.read_csv(path, nrows=cfg_ds.get("nrows"))
    types = cfg_ds.get("types")
    if types:
        df = df[df["type"].isin(types)]
    df = df.sort_values("step", kind="stable").reset_index(drop=True)
    df = subsample(df, "isFraud", cfg_ds.get("max_nodes"), cfg_ds.get("sample_mode", "head"), seed)
    df = df.reset_index(drop=True)

    f = {}
    f["amt_log"] = np.log1p(df["amount"].astype("float64"))
    for c in BAL:
        f[c] = signed_log(df[c].astype("float64"))
    for t in (types or sorted(df["type"].unique())):
        f[f"type_{t}"] = (df["type"] == t).astype("float32")
    hour = df["step"] % 24
    f["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    f["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    # isFlaggedFraud is the simulator's rule output, not a raw attribute -> excluded.

    return RawDataset(
        name="paysim",
        features=pd.DataFrame(f).astype("float32"),
        y=df["isFraud"].values.astype(np.int64),
        t=df["step"].values.astype(np.float64),
        group_keys={"shared origin account": df["nameOrig"], "shared destination account": df["nameDest"]},
        notes={"source_file": path.replace("\\", "/").split("/")[-1], "source_rows": int(len(df))},
    )
