"""ULB Credit Card Fraud (Kaggle mlg-ulb/creditcardfraud). No entity IDs: relations are
feature-space kNN and temporal adjacency."""
import numpy as np
import pandas as pd

from ..config import resolve_path
from . import RawDataset, subsample

V = [f"V{i}" for i in range(1, 29)]


def load_creditcard(cfg_ds: dict, seed: int = 0) -> RawDataset:
    path = resolve_path(cfg_ds["raw"]["csv"])
    df = pd.read_csv(path, nrows=cfg_ds.get("nrows"))
    df = df.sort_values("Time", kind="stable").reset_index(drop=True)
    df = subsample(df, "Class", cfg_ds.get("max_nodes"), cfg_ds.get("sample_mode", "head"), seed)
    df = df.reset_index(drop=True)

    f = df[V].astype("float64").copy()
    f["amt_log"] = np.log1p(df["Amount"].astype("float64"))
    hour = (df["Time"] / 3600.0) % 24
    f["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    f["hour_cos"] = np.cos(2 * np.pi * hour / 24)

    return RawDataset(
        name="creditcard",
        features=f.astype("float32"),
        y=df["Class"].values.astype(np.int64),
        t=df["Time"].values.astype(np.float64),
        group_keys={"temporal adjacency": pd.Series(np.zeros(len(df), dtype=np.int64))},
        knn_cols=V,
        notes={"source_rows": int(len(df))},
    )
