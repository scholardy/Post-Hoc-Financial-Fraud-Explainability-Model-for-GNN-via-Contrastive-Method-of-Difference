"""Candidate sets C(v) for the sparse attention module (paper Sec. III, 'hybrid approach').

C(v) = up to ceil(k/2) graph neighbours of v (random, fixed seed)
       + the most cosine-similar transactions in feature space to fill up to k
       + v itself.

Causal protocol (default): a transaction may only use transactions that arrived BEFORE it.
  * graph-neighbour candidates come from incoming edges, which only point from earlier to later transactions;
  * similarity candidates are searched among the `window` transactions immediately preceding v
    (never v itself, never a later transaction).
Transductive protocol (earlier version, kept for comparison): the similarity search used v's own window of
`window` transactions plus the previous one, which includes later transactions.
"""
import math

import numpy as np
import torch
import torch.nn.functional as F


@torch.no_grad()
def cosine_topk(Z: np.ndarray, k: int, device, window=None, block: int = 1024, causal: bool = True) -> np.ndarray:
    """For each row i (rows are in time order), indices of the k most cosine-similar rows, padded with -1.

    causal=True : only rows j < i are eligible; with `window`, only i - window <= j < i.
    causal=False: legacy transductive search - all rows (window=None) or i's own window block plus the
                  previous block (can include later rows).
    """
    n = Z.shape[0]
    X = F.normalize(torch.as_tensor(Z, dtype=torch.float32, device=device), dim=1)
    out = np.full((n, k), -1, dtype=np.int64)
    if causal:
        for qs in range(0, n, block):
            qe = min(n, qs + block)
            cs = 0 if window is None else max(0, qs - window)
            keys = X[cs:qe]
            sim = X[qs:qe] @ keys.T  # [q, keys]
            qi = torch.arange(qs, qe, device=device)[:, None]
            kj = torch.arange(cs, qe, device=device)[None, :]
            bad = kj >= qi  # self or future
            if window is not None:
                bad |= kj < (qi - window)  # outside the look-back window
            sim.masked_fill_(bad, -float("inf"))
            kk = min(k, keys.shape[0])
            if kk <= 0:
                continue
            vals, idx = sim.topk(kk, dim=1)
            idx = idx + cs
            idx[torch.isinf(vals)] = -1  # fewer than k earlier transactions available
            out[qs:qe, :kk] = idx.cpu().numpy()
        return out

    w = window or n
    for ws in range(0, n, w):
        we = min(n, ws + w)
        cs = 0 if window is None else max(0, ws - w)
        ce = n if window is None else we
        keys = X[cs:ce]
        kk = min(k, keys.shape[0] - 1)
        if kk <= 0:
            continue
        for qs in range(ws, we, block):
            qe = min(we, qs + block)
            sim = X[qs:qe] @ keys.T
            rows = torch.arange(qe - qs, device=device)
            sim[rows, rows + (qs - cs)] = -float("inf")  # exclude self
            idx = sim.topk(kk, dim=1).indices + cs
            out[qs:qe, :kk] = idx.cpu().numpy()
    return out


def dedupe_edges(src, dst, etype, n):
    """Remove duplicate (src, dst) pairs, keeping the smallest edge type."""
    order = np.lexsort((etype, dst, src))
    src, dst, etype = src[order], dst[order], etype[order]
    key = src.astype(np.int64) * n + dst
    first = np.ones(len(key), dtype=bool)
    first[1:] = key[1:] != key[:-1]
    return src[first], dst[first], etype[first]


def build_candidates(edge_index: np.ndarray, edge_type: np.ndarray, n: int, sim: np.ndarray,
                     k: int, n_rel: int, seed: int = 0, mode: str = "hybrid"):
    """Returns (cand_index [2, M] as (src=u, dst=v), cand_type [M]).
    cand_type: 0..n_rel-1 = graph relation, n_rel = feature similarity, n_rel+1 = self.

    mode: 'hybrid' (default: up to ceil(k/2) graph neighbours, filled to k with similar transactions),
          'graph'  (up to k graph neighbours only), 'sim' (k similar transactions only)."""
    assert mode in {"hybrid", "graph", "sim"}
    src, dst = edge_index
    k_g = {"hybrid": math.ceil(k / 2), "graph": k, "sim": 0}[mode]
    rng = np.random.default_rng(seed)
    E = len(src)
    if E and k_g > 0:
        perm = rng.permutation(E)
        order = perm[np.argsort(dst[perm], kind="stable")]
        d_sorted = dst[order]
        starts = np.searchsorted(d_sorted, np.arange(n))
        rank = np.arange(E) - starts[d_sorted]
        keep = rank < k_g
        g_src, g_dst, g_type = src[order][keep], d_sorted[keep], edge_type[order][keep]
    else:
        g_src = g_dst = g_type = np.zeros(0, dtype=np.int64)
    n_g = np.bincount(g_dst, minlength=n)

    if mode == "graph":
        s_src = s_dst = s_type = np.zeros(0, dtype=np.int64)
    else:
        ks = sim[:, :k]
        keep_s = (np.arange(ks.shape[1])[None, :] < (k - n_g)[:, None]) & (ks >= 0)
        s_dst = np.broadcast_to(np.arange(n)[:, None], ks.shape)[keep_s]
        s_src = ks[keep_s]
        s_type = np.full(len(s_src), n_rel, dtype=np.int64)

    self_idx = np.arange(n)
    c_src = np.concatenate([g_src, s_src, self_idx])
    c_dst = np.concatenate([g_dst, s_dst, self_idx])
    c_type = np.concatenate([g_type, s_type, np.full(n, n_rel + 1, dtype=np.int64)])
    c_src, c_dst, c_type = dedupe_edges(c_src, c_dst, c_type, n)
    return np.stack([c_src, c_dst]), c_type
