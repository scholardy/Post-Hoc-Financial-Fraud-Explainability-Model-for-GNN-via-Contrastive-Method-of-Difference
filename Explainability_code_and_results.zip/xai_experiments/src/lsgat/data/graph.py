"""Turn a RawDataset into a cached transaction graph.

Nodes  = transactions (sorted by time; ties keep the original arrival order).
Edges  = for every relation (shared card, shared device, ...), each transaction is linked to
         its previous r transactions with the same key (time-ordered chain).
         This keeps |E| = O(r |V|) even for huge groups (e.g. a popular email domain).
         protocol 'causal' (default): edges point from the earlier to the later transaction only, so a
           transaction can only receive information from transactions that arrived before it.
         protocol 'transductive' (earlier version): edges are symmetrised (later -> earlier as well).
Split  = temporal: first 60% train, next 20% validation, last 20% test.
Scaler and all data-driven preprocessing choices = fit on training rows only.
"""
import os
import time

import numpy as np
import pandas as pd
import torch

from .candidates import cosine_topk, dedupe_edges
from .creditcard import load_creditcard
from .ieee import load_ieee
from .paysim import load_paysim

LOADERS = {"ieee": load_ieee, "paysim": load_paysim, "creditcard": load_creditcard}


def temporal_split(n, train_frac, val_frac):
    a = int(round(n * train_frac))
    b = int(round(n * (train_frac + val_frac)))
    return np.arange(0, a), np.arange(a, b), np.arange(b, n)


def standardize(features: pd.DataFrame, train_idx):
    X = features.values.astype(np.float64)
    mu = np.nanmean(X[train_idx], axis=0)
    sd = np.nanstd(X[train_idx], axis=0)
    keep = np.isfinite(mu) & np.isfinite(sd) & (sd > 1e-8)  # drop columns constant on train
    X, mu, sd = X[:, keep], mu[keep], sd[keep]
    Z = (X - mu) / sd
    Z[~np.isfinite(Z)] = 0.0  # missing -> train mean
    Z = np.clip(Z, -10, 10).astype(np.float32)
    names = [c for c, k in zip(features.columns, keep) if k]
    return Z, names


def chain_edges(codes: np.ndarray, r: int):
    """codes[i] = entity id of row i (-1 = none). Rows are in time order.
    Returns (src, dst) linking each row to its previous r rows with the same code."""
    ids = np.flatnonzero(codes >= 0)
    c = codes[ids]
    o = np.lexsort((ids, c))
    c, ids = c[o], ids[o]
    src, dst = [], []
    for j in range(1, r + 1):
        same = c[j:] == c[:-j]
        src.append(ids[j:][same])
        dst.append(ids[:-j][same])
    return np.concatenate(src), np.concatenate(dst)


def protocol_of(cfg):
    p = cfg.get("protocol", "causal")
    assert p in {"causal", "transductive"}, p
    return p


def build_graph(cfg: dict, name: str, device, chain_r=None) -> dict:
    protocol = protocol_of(cfg)
    causal = protocol == "causal"
    cfg_ds = dict(cfg["datasets"][name])
    cfg_ds["_train_frac"] = cfg["split"]["train"]  # loaders take data-driven choices from the training period only
    cfg_ds["_causal"] = causal
    if chain_r is not None:
        cfg_ds["chain_r"] = chain_r
    t0 = time.perf_counter()
    raw = LOADERS[name](cfg_ds, seed=0)
    t_load = time.perf_counter() - t0

    t1 = time.perf_counter()
    n = len(raw.y)
    tr, va, te = temporal_split(n, cfg["split"]["train"], cfg["split"]["val"])
    Z, feat_names = standardize(raw.features, tr)

    rel_names, srcs, dsts, types = [], [], [], []
    r = cfg_ds.get("chain_r", 3)
    for rel, keys in raw.group_keys.items():
        codes = pd.factorize(keys.reset_index(drop=True), use_na_sentinel=True)[0]
        later, earlier = chain_edges(codes, r)
        srcs.append(earlier); dsts.append(later); types.append(np.full(len(later), len(rel_names)))
        rel_names.append(rel)
    if raw.knn_cols:
        cols = [feat_names.index(c) for c in raw.knn_cols if c in feat_names]
        nb = cosine_topk(Z[:, cols], cfg_ds.get("knn_k", 5), device, causal=causal)
        d = np.repeat(np.arange(n), nb.shape[1]).reshape(n, -1)
        m = nb >= 0
        srcs.append(nb[m]); dsts.append(d[m]); types.append(np.full(int(m.sum()), len(rel_names)))
        rel_names.append("feature kNN")
    if causal:
        # message flows src -> dst; src is always the earlier transaction
        e_src, e_dst = np.concatenate(srcs), np.concatenate(dsts)
        e_src, e_dst = np.minimum(e_src, e_dst), np.maximum(e_src, e_dst)
        et = np.concatenate(types).astype(np.int64)
    else:
        e_src = np.concatenate(srcs + dsts)
        e_dst = np.concatenate(dsts + srcs)
        et = np.concatenate(types + types).astype(np.int64)
    nz = e_src != e_dst
    src, dst, et = dedupe_edges(e_src[nz], e_dst[nz], et[nz], n)
    if causal:
        assert (src < dst).all(), "causal graph must only contain earlier -> later edges"
    t_graph = time.perf_counter() - t1
    links = len(src) if causal else len(src) // 2  # undirected links (each stored once when causal)

    y = raw.y
    stats = {
        "dataset": name,
        "display": cfg_ds.get("display", name),
        "nodes": int(n),
        "protocol": protocol,
        "edges_undirected": int(links),
        "edges_directed_stored": int(len(src)),
        "edges_by_relation": {rel: int((et == i).sum() // (1 if causal else 2)) for i, rel in enumerate(rel_names)},
        "avg_degree": float(2 * links / max(n, 1)),
        "features": int(Z.shape[1]),
        "frauds": int(y.sum()),
        "fraud_rate": float(y.mean()),
        "split_sizes": {"train": len(tr), "val": len(va), "test": len(te)},
        "split_frauds": {"train": int(y[tr].sum()), "val": int(y[va].sum()), "test": int(y[te].sum())},
        "time_range": [float(raw.t.min()), float(raw.t.max())],
        "seconds_load": t_load,
        "seconds_graph": t_graph,
        "notes": raw.notes,
    }
    return {
        "x": torch.from_numpy(Z),
        "y": torch.from_numpy(y),
        "t": torch.from_numpy(raw.t),
        "edge_index": torch.from_numpy(np.stack([src, dst])),
        "edge_type": torch.from_numpy(et),
        "relation_names": rel_names,
        "feature_names": feat_names,
        "train_idx": torch.from_numpy(tr),
        "val_idx": torch.from_numpy(va),
        "test_idx": torch.from_numpy(te),
        "protocol": protocol,
        "stats": stats,
    }


def prefix_subgraph(g: dict, sim: np.ndarray, n_keep: int, cfg: dict):
    """Induced subgraph on the earliest n_keep transactions (used for the scalability study).
    Split is re-done temporally (60/20/20) inside the prefix; features keep the global scaling."""
    n = g["x"].size(0)
    if n_keep is None or n_keep >= n:
        return g, sim
    src, dst = g["edge_index"].numpy()
    m = (src < n_keep) & (dst < n_keep)
    tr, va, te = temporal_split(n_keep, cfg["split"]["train"], cfg["split"]["val"])
    s = sim[:n_keep].copy()
    s[s >= n_keep] = -1
    sub = {k: v for k, v in g.items()}
    sub.update({
        "x": g["x"][:n_keep], "y": g["y"][:n_keep], "t": g["t"][:n_keep],
        "edge_index": g["edge_index"][:, torch.from_numpy(m)],
        "edge_type": g["edge_type"][torch.from_numpy(m)],
        "train_idx": torch.from_numpy(tr), "val_idx": torch.from_numpy(va), "test_idx": torch.from_numpy(te),
    })
    return sub, s


def graph_path(cfg, name, chain_r=None):
    suffix = "" if chain_r is None else f"_r{chain_r}"
    return os.path.join(cfg["paths"]["processed_dir"], f"{name}{suffix}_{protocol_of(cfg)}_graph.pt")


def sim_path(cfg, name):
    return os.path.join(cfg["paths"]["processed_dir"],
                        f"{name}_{protocol_of(cfg)}_w{cfg['model']['sim_window']}_sim_top{cfg['model']['k_max_cache']}.npy")


def load_or_build(cfg, name, device, rebuild=False, chain_r=None):
    """Cached graph + cached similarity top-K (K = k_max_cache) for candidate selection.
    chain_r overrides the number of chain links per relation (graph-density study);
    node features/splits are identical, so the similarity cache is shared."""
    if chain_r == cfg["datasets"][name].get("chain_r", 3):
        chain_r = None
    gp, sp = graph_path(cfg, name, chain_r), sim_path(cfg, name)
    os.makedirs(os.path.dirname(gp), exist_ok=True)
    if rebuild or not os.path.exists(gp):
        g = build_graph(cfg, name, device, chain_r=chain_r)
        torch.save(g, gp)
    else:
        g = torch.load(gp, weights_only=False)
    if rebuild or not os.path.exists(sp):
        t0 = time.perf_counter()
        sim = cosine_topk(g["x"].numpy(), cfg["model"]["k_max_cache"], device, window=cfg["model"]["sim_window"],
                          causal=protocol_of(cfg) == "causal")
        np.save(sp, sim)
        g["stats"]["seconds_similarity_topk"] = time.perf_counter() - t0
        torch.save(g, gp)
    else:
        sim = np.load(sp)
    return g, sim
