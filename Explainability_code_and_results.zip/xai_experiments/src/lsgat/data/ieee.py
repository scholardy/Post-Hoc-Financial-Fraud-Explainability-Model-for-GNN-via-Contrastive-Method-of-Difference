"""IEEE-CIS Fraud Detection (Kaggle competition, train_transaction + train_identity)."""
import numpy as np
import pandas as pd

from ..config import resolve_path
from . import RawDataset, signed_log, subsample

C_COLS = [f"C{i}" for i in range(1, 15)]
D_COLS = [f"D{i}" for i in range(1, 16)]
M_BIN = [f"M{i}" for i in (1, 2, 3, 5, 6, 7, 8, 9)]
BASE = ["TransactionID", "isFraud", "TransactionDT", "TransactionAmt", "ProductCD",
        "card1", "card2", "card3", "card4", "card5", "card6", "addr1", "addr2",
        "dist1", "dist2", "P_emaildomain", "R_emaildomain", "M4"] + C_COLS + D_COLS + M_BIN
ID_COLS = ["TransactionID", "DeviceType", "DeviceInfo", "id_30", "id_31", "id_33"]


def _join(df, cols):
    out = df[cols[0]].map(str)
    for c in cols[1:]:
        out = out + "|" + df[c].map(str)
    return out


def load_ieee(cfg_ds: dict, seed: int = 0) -> RawDataset:
    tpath = resolve_path(cfg_ds["raw"]["transaction"])
    ipath = resolve_path(cfg_ds["raw"]["identity"])
    header = pd.read_csv(tpath, nrows=0).columns
    v_cols = [c for c in header if c.startswith("V")]
    dtypes = {c: "float32" for c in v_cols + C_COLS + D_COLS}
    df = pd.read_csv(tpath, usecols=BASE + v_cols, nrows=cfg_ds.get("nrows"), dtype=dtypes)
    idn = pd.read_csv(ipath, usecols=ID_COLS)
    df = df.merge(idn, on="TransactionID", how="left")
    df = df.sort_values("TransactionDT", kind="stable").reset_index(drop=True)
    df = subsample(df, "isFraud", cfg_ds.get("max_nodes"), cfg_ds.get("sample_mode", "head"), seed)
    df = df.reset_index(drop=True)
    # data-driven preprocessing choices use the training period only (first train_frac of the time-ordered rows)
    n_tr = max(1, int(round(len(df) * cfg_ds.get("_train_frac", 1.0))))
    train_rows = df.iloc[:n_tr]

    # keep only V columns that are almost always present in the training period (no labels used)
    miss = train_rows[v_cols].isna().mean()
    v_keep = [c for c in v_cols if miss[c] <= cfg_ds.get("v_max_missing", 0.01)]
    df = df.drop(columns=[c for c in v_cols if c not in v_keep])

    f = {}
    amt = df["TransactionAmt"].astype("float64")
    f["amt_log"] = np.log1p(amt)
    f["amt_cents"] = (amt - np.floor(amt)).round(3)
    hour = (df["TransactionDT"] / 3600.0) % 24
    f["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    f["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    for c in ["dist1", "dist2"]:
        f[c] = np.log1p(df[c].astype("float64"))
        f[f"{c}_missing"] = df[c].isna().astype("float32")
    for c in C_COLS:
        f[c] = np.log1p(df[c].clip(lower=0).astype("float64"))
    for c in D_COLS:
        f[c] = signed_log(df[c].astype("float64"))
        f[f"{c}_missing"] = df[c].isna().astype("float32")
    for c in M_BIN:
        f[c] = df[c].map({"T": 1.0, "F": -1.0}).fillna(0.0)
    for c in v_keep:
        f[c] = signed_log(df[c].astype("float64"))

    def onehot(col, values, prefix):
        for v in values:
            f[f"{prefix}_{v}"] = (df[col] == v).astype("float32")

    onehot("ProductCD", ["W", "C", "R", "H", "S"], "product")
    onehot("card4", ["visa", "mastercard", "american express", "discover"], "card4")
    onehot("card6", ["debit", "credit"], "card6")
    onehot("M4", ["M0", "M1", "M2"], "M4")
    onehot("DeviceType", ["desktop", "mobile"], "device")
    top_email = train_rows["P_emaildomain"].value_counts().index[:10].tolist()
    onehot("P_emaildomain", top_email, "pemail")
    f["has_identity"] = (df["DeviceType"].notna() | df["DeviceInfo"].notna()).astype("float32")
    f["email_match"] = (df["P_emaildomain"] == df["R_emaildomain"]).astype("float32")

    card_key = _join(df, ["card1", "card2", "card3", "card4", "card5", "card6"])
    addr_email = _join(df, ["addr1", "P_emaildomain"]).where(df["addr1"].notna() & df["P_emaildomain"].notna())
    device = _join(df, ["DeviceInfo", "id_30", "id_31", "id_33"]).where(df["DeviceInfo"].notna())

    return RawDataset(
        name="ieee",
        features=pd.DataFrame(f).astype("float32"),
        y=df["isFraud"].values.astype(np.int64),
        t=df["TransactionDT"].values.astype(np.float64),
        group_keys={"shared card": card_key, "shared address+email": addr_email, "shared device": device},
        notes={"source_rows": int(len(df)), "v_columns_kept": len(v_keep)},
    )
