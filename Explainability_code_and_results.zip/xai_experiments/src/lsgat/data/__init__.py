from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np
import pandas as pd


@dataclass
class RawDataset:
    """Output of a dataset loader, before graph construction.

    Rows are sorted by time, so row order == time order.
    features: numeric columns only (NaN allowed); never contains IDs or labels.
    group_keys: relation name -> entity key per row (NaN = row has no such entity).
        Each relation becomes time-ordered chain edges between rows sharing a key.
    knn_cols: if set, an extra 'feature kNN' relation is built on these columns.
    """
    name: str
    features: pd.DataFrame
    y: np.ndarray
    t: np.ndarray
    group_keys: Dict[str, pd.Series]
    knn_cols: List[str] = field(default_factory=list)
    notes: Dict[str, object] = field(default_factory=dict)


def signed_log(s):
    return np.sign(s) * np.log1p(np.abs(s))


def subsample(df: pd.DataFrame, label_col: str, max_nodes, mode: str, seed: int = 0) -> pd.DataFrame:
    """Reduce rows to max_nodes. 'head' keeps the earliest rows (df must be time-sorted),
    'random' keeps a uniform sample, 'random_keep_fraud' keeps all frauds plus random legit rows.
    Row order (time order) is preserved in every mode."""
    if not max_nodes or len(df) <= max_nodes:
        return df
    rng = np.random.default_rng(seed)
    if mode == "head":
        return df.iloc[:max_nodes]
    if mode == "random":
        keep = np.sort(rng.choice(len(df), size=max_nodes, replace=False))
        return df.iloc[keep]
    if mode == "random_keep_fraud":
        pos = np.flatnonzero(df[label_col].values == 1)
        neg = np.flatnonzero(df[label_col].values == 0)
        n_neg = max(0, max_nodes - len(pos))
        keep = np.sort(np.concatenate([pos, rng.choice(neg, size=n_neg, replace=False)]))
        return df.iloc[keep]
    raise ValueError(mode)
