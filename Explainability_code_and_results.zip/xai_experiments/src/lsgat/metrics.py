"""Threshold selection (on validation) and test metrics."""
import numpy as np
from sklearn.metrics import (average_precision_score, confusion_matrix, precision_recall_curve,
                             roc_auc_score)


def best_f1_threshold(y, p):
    """Threshold maximising F1 on (y, p). Falls back to 0.5 if y has no positives."""
    if y.sum() == 0 or y.sum() == len(y):
        return 0.5
    prec, rec, thr = precision_recall_curve(y, p)
    f1 = 2 * prec[:-1] * rec[:-1] / np.maximum(prec[:-1] + rec[:-1], 1e-12)
    return float(thr[int(np.argmax(f1))])


def compute_metrics(y, p, thr):
    y = np.asarray(y).astype(int)
    p = np.asarray(p, dtype=np.float64)
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    both = 0 < y.sum() < len(y)
    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "accuracy": float((tp + tn) / len(y)),
        "roc_auc": float(roc_auc_score(y, p)) if both else float("nan"),
        "pr_auc": float(average_precision_score(y, p)) if both else float("nan"),
        "tp": int(tp), "fp": int(fp), "fn": int(fn), "tn": int(tn),
        "threshold": float(thr),
        "n": int(len(y)), "positives": int(y.sum()),
    }


def evaluate_split_probs(y_all, p_all, val_idx, test_idx, thr=None):
    """Tune threshold on validation (unless given), report validation + test metrics."""
    yv, pv = y_all[val_idx], p_all[val_idx]
    if thr is None:
        thr = best_f1_threshold(yv, pv)
    return {"val": compute_metrics(yv, pv, thr), "test": compute_metrics(y_all[test_idx], p_all[test_idx], thr)}
