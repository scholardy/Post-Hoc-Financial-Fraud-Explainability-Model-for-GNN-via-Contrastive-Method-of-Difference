"""Config loading: configs/experiments.json, optionally overlaid with smoke.json or pilot.json."""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _deep_merge(base: dict, over: dict) -> dict:
    for k, v in over.items():
        if k.startswith("_"):
            continue
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = copy.deepcopy(v)
    return base


def load_config(profile: str = "full") -> dict:
    """profile: 'full' (default), 'smoke' (local CPU test) or 'pilot' (Kaggle timing run)."""
    with open(ROOT / "configs" / "experiments.json") as f:
        cfg = json.load(f)
    if profile != "full":
        with open(ROOT / "configs" / f"{profile}.json") as f:
            _deep_merge(cfg, json.load(f))
    cfg["profile"] = profile
    for key, rel in cfg["paths"].items():
        p = Path(rel)
        cfg["paths"][key] = str(p if p.is_absolute() else ROOT / p)
    return cfg


def resolve_path(candidates):
    """Return the first existing path from a list (relative paths are resolved against ROOT)."""
    for c in candidates:
        p = Path(c)
        if not p.is_absolute():
            p = ROOT / p
        if p.exists():
            return str(p)
    # Kaggle fallback: datasets may be mounted under a different folder name
    kaggle = Path("/kaggle/input")
    if kaggle.exists():
        for c in candidates:
            hits = sorted(kaggle.rglob(Path(c).name))
            if hits:
                return str(hits[0])
    raise FileNotFoundError(f"None of these files exist: {candidates}")
