"""LS-GAT: Linear + Sparse Graph Attention for fraud detection (experiment package)."""
