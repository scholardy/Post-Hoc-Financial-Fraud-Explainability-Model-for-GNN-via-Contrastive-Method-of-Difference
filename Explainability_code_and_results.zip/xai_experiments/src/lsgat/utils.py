"""Small helpers: seeding, devices, JSON I/O, environment info."""
import json
import os
import platform
import random
import time

import numpy as np
import torch


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device(pref: str = "auto") -> torch.device:
    if pref == "cpu" or not torch.cuda.is_available():
        return torch.device("cpu")
    return torch.device("cuda")


def sync(device):
    if device.type == "cuda":
        torch.cuda.synchronize()


class Timer:
    def __init__(self, device=None):
        self.device = device

    def __enter__(self):
        if self.device is not None:
            sync(self.device)
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        if self.device is not None:
            sync(self.device)
        self.seconds = time.perf_counter() - self.t0


def _default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, torch.Tensor):
        return o.detach().cpu().tolist()
    raise TypeError(f"not JSON serialisable: {type(o)}")


def save_json(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=2, default=_default)
    os.replace(tmp, path)


def load_json(path):
    with open(path) as f:
        return json.load(f)


def env_info(device) -> dict:
    import sklearn
    try:
        import torch_geometric
        pyg = torch_geometric.__version__
    except Exception:
        pyg = None
    info = {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "torch_geometric": pyg,
        "sklearn": sklearn.__version__,
        "platform": platform.platform(),
        "cpu": platform.processor(),
        "cpu_count": os.cpu_count(),
        "device": str(device),
    }
    if device.type == "cuda":
        info["gpu"] = torch.cuda.get_device_name(device)
    return info
