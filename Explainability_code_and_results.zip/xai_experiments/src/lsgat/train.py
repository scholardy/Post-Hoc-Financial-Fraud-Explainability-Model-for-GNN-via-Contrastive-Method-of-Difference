"""Training / evaluation loops shared by every model.

GNNs: full-batch, Adam + cosine annealing, focal loss, early stopping on validation PR-AUC
      (best weights deep-copied), decision threshold tuned on validation, metrics on test.
Tabular: fit on train rows, threshold tuned on validation, metrics on test.
"""
import copy
import time

import numpy as np
import torch
from sklearn.metrics import average_precision_score

from .losses import focal_loss
from .metrics import evaluate_split_probs
from .models import build_model, uses_candidates
from .models.tabular import fit_predict, make_tabular, n_params
from .profiling import PeakMemory
from .utils import set_seed, sync


SPARSE_ADJ_MODELS = {"gcn", "sage", "lsgat", "lsgat_l", "lsgat_s", "lsgat_f", "lsgat_noego"}


def graph_input(name, edge_index, n, device):
    """GCN/GraphSAGE-style propagation (incl. LS-GAT's linear branch) uses a sparse adjacency matrix
    (PyG's memory-efficient SpMM path); GAT needs per-edge attention, so it gets the edge list."""
    edge_index = edge_index.to(device)
    if name in SPARSE_ADJ_MODELS:
        from torch_geometric.utils import to_torch_csr_tensor
        # PyG expects the transposed adjacency adj_t[target, source]; this matters for directed (causal) graphs
        return to_torch_csr_tensor(edge_index.flip(0), size=(n, n))
    return edge_index


def count_params(model):
    return int(sum(p.numel() for p in model.parameters() if p.requires_grad))


@torch.no_grad()
def predict(model, x, ei, ci, keep_attention=False):
    model.eval()
    if keep_attention:
        logits = model(x, ei, ci, keep_attention=True)
    else:
        logits = model(x, ei, ci)
    return torch.sigmoid(logits).float().cpu().numpy()


def train_gnn(name, g, cfg, seed, device, cand_index=None, edge_index=None, y_train=None,
              fixed_epochs=None, warmup=0, return_model=False):
    """Train one GNN. `fixed_epochs` (efficiency study) disables validation/early stopping."""
    set_seed(seed)
    tc = cfg["train"]
    x = g["x"].to(device)
    y = g["y"].numpy()
    ei_list = edge_index if edge_index is not None else g["edge_index"]
    ei = graph_input(name, ei_list, x.size(0), device)
    ci = cand_index.to(device) if (uses_candidates(name) and cand_index is not None) else None
    if uses_candidates(name) and ci is None:
        raise ValueError(f"{name} needs candidate sets")
    y_fit = torch.as_tensor(y_train if y_train is not None else y, device=device).float()
    tr = g["train_idx"].to(device)
    va, te = g["val_idx"].numpy(), g["test_idx"].numpy()

    model = build_model(name, x.size(1), cfg["model"]).to(device)
    params = count_params(model)
    max_epochs = fixed_epochs or tc["max_epochs"]
    # L2 (weight decay) on weights only; the fusion gate and biases are not decayed
    decay = [p for n, p in model.named_parameters() if p.ndim > 1 and "beta" not in n]
    no_decay = [p for n, p in model.named_parameters() if p.ndim <= 1 or "beta" in n]
    opt = torch.optim.Adam([{"params": decay, "weight_decay": tc["weight_decay"]},
                            {"params": no_decay, "weight_decay": 0.0}], lr=tc["lr"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max_epochs)

    epoch_times, history = [], []
    best_ap, best_state, best_epoch, wait = -1.0, None, -1, 0
    t_start = time.perf_counter()
    with PeakMemory(device) as mem:
        for epoch in range(max_epochs):
            model.train()
            sync(device)
            t0 = time.perf_counter()
            opt.zero_grad(set_to_none=True)
            logits = model(x, ei, ci)
            loss = focal_loss(logits[tr], y_fit[tr], tc["focal_alpha"], tc["focal_gamma"])
            loss.backward()
            opt.step()
            sched.step()
            sync(device)
            epoch_times.append(time.perf_counter() - t0)
            if fixed_epochs:
                continue
            p = predict(model, x, ei, ci)
            ap = average_precision_score(y[va], p[va]) if y[va].sum() > 0 else 0.0
            history.append({"epoch": epoch, "loss": float(loss.item()), "val_pr_auc": float(ap)})
            if ap > best_ap + 1e-6:
                best_ap, best_epoch, wait = ap, epoch, 0
                best_state = copy.deepcopy({k: v.detach().cpu() for k, v in model.state_dict().items()})
            else:
                wait += 1
                if wait >= tc["patience"]:
                    break
    total_train = time.perf_counter() - t_start
    if best_state is not None:
        model.load_state_dict(best_state)

    sync(device)
    t0 = time.perf_counter()
    probs = predict(model, x, ei, ci, keep_attention=name.startswith("lsgat"))
    sync(device)
    inference = time.perf_counter() - t0

    et = np.array(epoch_times[warmup:] if len(epoch_times) > warmup else epoch_times)
    res = {
        "model": name, "seed": seed, "params": params,
        "epochs_run": len(epoch_times), "best_epoch": best_epoch,
        "time_per_epoch_mean": float(et.mean()), "time_per_epoch_std": float(et.std()),
        "total_train_seconds": float(total_train), "inference_seconds": float(inference),
        "peak_mem_mb": float(mem.peak_mb), "peak_mem_above_base_mb": float(mem.peak_above_base_mb),
        "num_edges_directed": int(ei_list.size(1)),
        "num_candidates": int(ci.size(1)) if ci is not None else None,
        "history": history,
    }
    if not fixed_epochs:
        res.update(evaluate_split_probs(y, probs, va, te))
    if name.startswith("lsgat") and model.beta() is not None:
        b = model.beta().detach().cpu().numpy()
        res["beta"] = {"mean": float(b.mean()), "std": float(b.std()), "min": float(b.min()),
                       "max": float(b.max()), "values": b.tolist()}
    if return_model:
        return res, model, probs
    return res


def run_tabular(name, g, cfg, seed, device, return_model=False):
    X = g["x"].numpy()
    y = g["y"].numpy()
    tr, va, te = g["train_idx"].numpy(), g["val_idx"].numpy(), g["test_idx"].numpy()
    n_pos = int(y[tr].sum())
    model = make_tabular(name, seed, cfg["tabular"], device.type == "cuda", n_pos, len(tr) - n_pos)
    with PeakMemory(torch.device("cpu")) as mem:
        t0 = time.perf_counter()
        probs = fit_predict(model, name, X, y, tr, va)
        total = time.perf_counter() - t0
    res = {"model": name, "seed": seed, "params": n_params(model, name),
           "total_train_seconds": float(total), "peak_mem_mb": float(mem.peak_mb),
           "peak_mem_above_base_mb": float(mem.peak_above_base_mb)}
    res.update(evaluate_split_probs(y, probs, va, te))
    if return_model:
        return res, model
    return res
