"""LS-GAT: Linear-Sparse Graph Attention Network (paper Sec. III, Eqs. 1-5).

  Linear branch  (Eq. 1): H^{l+1} = relu( D^-1/2 (A+I) D^-1/2 H^l W^l )          cost O(|E| d)
  Sparse branch (Eqs. 2-4): attention only over a fixed candidate set C(v), |C(v)| <= k+1
      e_vu   = LeakyReLU( a^T [ W_q h_v || W_k h_u ] )
      a_vu   = softmax_{u in C(v)} e_vu
      h_v'   = elu( sum_u a_vu W_v h_u )                                          cost O(k |V| d)
  Fusion (Eq. 5): z = beta * H_lin + (1 - beta) * H_sparse, beta = sigmoid(learnable vector in R^d)

Ego connection: every layer of both branches also adds a separate linear transform of the node's own
representation (as GraphSAGE's root weight), so a transaction's own evidence is not diluted by legitimate
neighbours - important on heterophilous fraud graphs (Zhu et al., 2020).

Variants (ablation): full (learnable beta), fixed (beta = 0.5), linear (H_lin only), sparse (H_sparse only),
and ego=False (full model without the ego connection).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.utils import softmax

from .gnn_baselines import Head


class FusedAttentionAggregate(torch.autograd.Function):
    """out[v] = sum_{u in C(v)} alpha_vu * V[u], computed in edge chunks.

    Mathematically identical to `zeros.index_add_(0, dst, V[src] * alpha)`, but never stores the
    [M, heads, d_head] message tensor (M = number of candidate pairs): backward recomputes what it needs
    from (alpha, V). Peak memory is O(M * heads + n * d) instead of O(M * d)."""

    CHUNK = 1 << 20

    @staticmethod
    def forward(ctx, alpha, v, src, dst):
        n, H, D = v.shape
        out = v.new_zeros(n, H, D)
        for s in range(0, src.numel(), FusedAttentionAggregate.CHUNK):
            e = slice(s, s + FusedAttentionAggregate.CHUNK)
            out.index_add_(0, dst[e], v[src[e]] * alpha[e].unsqueeze(-1))
        ctx.save_for_backward(alpha, v, src, dst)
        return out

    @staticmethod
    def backward(ctx, g):
        alpha, v, src, dst = ctx.saved_tensors
        g_alpha = torch.empty_like(alpha) if ctx.needs_input_grad[0] else None
        g_v = torch.zeros_like(v) if ctx.needs_input_grad[1] else None
        for s in range(0, src.numel(), FusedAttentionAggregate.CHUNK):
            e = slice(s, s + FusedAttentionAggregate.CHUNK)
            gd = g[dst[e]]  # [c, H, D]
            if g_alpha is not None:
                g_alpha[e] = (gd * v[src[e]]).sum(-1)
            if g_v is not None:
                g_v.index_add_(0, src[e], gd * alpha[e].unsqueeze(-1))
        return g_alpha, g_v, None, None


class SparseAttention(nn.Module):
    def __init__(self, dim, heads, dropout, negative_slope=0.2):
        super().__init__()
        assert dim % heads == 0
        self.h, self.dh = heads, dim // heads
        self.W_q = nn.Linear(dim, dim, bias=False)
        self.W_k = nn.Linear(dim, dim, bias=False)
        self.W_v = nn.Linear(dim, dim, bias=False)
        # a^T [q || k] = a_q . q + a_k . k  (per head)
        self.a_q = nn.Parameter(torch.empty(heads, self.dh))
        self.a_k = nn.Parameter(torch.empty(heads, self.dh))
        nn.init.xavier_uniform_(self.a_q)
        nn.init.xavier_uniform_(self.a_k)
        self.dropout = dropout
        self.negative_slope = negative_slope

    def forward(self, h, cand_index):
        n = h.size(0)
        src, dst = cand_index  # message u=src -> v=dst
        q = self.W_q(h).view(n, self.h, self.dh)
        k = self.W_k(h).view(n, self.h, self.dh)
        v = self.W_v(h).view(n, self.h, self.dh)
        sq = (q * self.a_q).sum(-1)  # [n, H]
        sk = (k * self.a_k).sum(-1)
        e = F.leaky_relu(sq[dst] + sk[src], self.negative_slope)  # [M, H]
        alpha = softmax(e, dst, num_nodes=n)  # normalised over C(v)
        a = F.dropout(alpha, self.dropout, self.training)
        out = FusedAttentionAggregate.apply(a, v, src, dst)
        return out.reshape(n, self.h * self.dh), alpha


class LSGAT(nn.Module):
    def __init__(self, in_dim, hidden, layers, dropout, heads=4, variant="full", ego=True):
        super().__init__()
        assert variant in {"full", "fixed", "linear", "sparse"}
        self.variant = variant
        self.ego = ego
        self.dropout = dropout
        self.inp = nn.Linear(in_dim, hidden)
        self.use_lin = variant != "sparse"
        self.use_sp = variant != "linear"
        if self.use_lin:
            self.lin_convs = nn.ModuleList([GCNConv(hidden, hidden, cached=True) for _ in range(layers)])
            if ego:
                self.lin_ego = nn.ModuleList([nn.Linear(hidden, hidden, bias=False) for _ in range(layers)])
        if self.use_sp:
            self.sp_layers = nn.ModuleList([SparseAttention(hidden, heads, dropout) for _ in range(layers)])
            if ego:
                self.sp_ego = nn.ModuleList([nn.Linear(hidden, hidden, bias=False) for _ in range(layers)])
        if variant == "full":
            self.beta_logit = nn.Parameter(torch.zeros(hidden))  # sigmoid(0) = 0.5 at init
        self.head = Head(hidden, dropout)
        self.last_attention = None

    def beta(self):
        if self.variant == "full":
            return torch.sigmoid(self.beta_logit)
        if self.variant == "fixed":
            return torch.full((self.inp.out_features,), 0.5, device=self.inp.weight.device)
        return None

    def forward(self, x, edge_index, cand_index=None, keep_attention=False):
        h0 = F.dropout(F.relu(self.inp(x)), self.dropout, self.training)
        if self.use_lin:
            hl = h0
            for i, conv in enumerate(self.lin_convs):
                m = conv(hl, edge_index)
                if self.ego:
                    m = m + self.lin_ego[i](hl)
                hl = F.dropout(F.relu(m), self.dropout, self.training)
        if self.use_sp:
            hs = h0
            for i, layer in enumerate(self.sp_layers):
                m, alpha = layer(hs, cand_index)
                if self.ego:
                    m = m + self.sp_ego[i](hs)
                hs = F.dropout(F.elu(m), self.dropout, self.training)
            if keep_attention:
                self.last_attention = alpha.detach()  # last sparse layer, [M, H]
        if self.variant == "linear":
            z = hl
        elif self.variant == "sparse":
            z = hs
        else:
            b = self.beta()
            z = b * hl + (1 - b) * hs
        return self.head(z)
