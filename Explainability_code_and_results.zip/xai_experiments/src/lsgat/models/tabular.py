"""Feature-only baselines (no graph): Logistic Regression, Random Forest, XGBoost."""
import numpy as np


def make_tabular(name, seed, cfg_tab, use_gpu, n_pos, n_neg):
    if name == "lr":
        from sklearn.linear_model import LogisticRegression
        return LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
    if name == "rf":
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(n_estimators=cfg_tab["rf_trees"], class_weight="balanced_subsample",
                                      n_jobs=-1, random_state=seed)
    if name == "xgb":
        from xgboost import XGBClassifier
        return XGBClassifier(
            n_estimators=cfg_tab["xgb_estimators"], learning_rate=0.05, max_depth=8,
            subsample=0.8, colsample_bytree=0.8, tree_method="hist",
            device="cuda" if use_gpu else "cpu", eval_metric="aucpr",
            early_stopping_rounds=cfg_tab["xgb_early_stopping"], random_state=seed, n_jobs=-1,
        )
    raise ValueError(name)


def fit_predict(model, name, X, y, tr, va):
    if name == "xgb":
        model.fit(X[tr], y[tr], eval_set=[(X[va], y[va])], verbose=False)
    else:
        model.fit(X[tr], y[tr])
    return model.predict_proba(X)[:, 1]


def n_params(model, name):
    if name == "lr":
        return int(np.prod(model.coef_.shape) + model.intercept_.size)
    if name == "rf":
        return int(sum(est.tree_.node_count for est in model.estimators_))
    if name == "xgb":
        return int(sum(t.count(chr(10)) for t in model.get_booster().get_dump()))  # total tree nodes
    return None
