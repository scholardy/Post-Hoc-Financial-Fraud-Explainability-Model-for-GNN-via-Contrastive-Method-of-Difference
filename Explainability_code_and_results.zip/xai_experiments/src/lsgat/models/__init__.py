from .gnn_baselines import GAT, GCN, MLP, SAGE, GATEgo
from .lsgat import LSGAT

GNN_MODELS = {"gcn", "sage", "gat", "lsgat", "lsgat_l", "lsgat_s", "lsgat_f", "lsgat_noego",
              "mlp", "gat_ego", "lsgat_l_pm", "lsgat_s_graph", "lsgat_s_sim"}
TABULAR_MODELS = {"lr", "rf", "xgb"}

DISPLAY = {
    "lr": "LR", "rf": "Random Forest", "xgb": "XGBoost",
    "gcn": "GCN", "sage": "GraphSAGE", "gat": "GAT",
    "lsgat": "LS-GAT", "lsgat_l": "LS-GAT-L", "lsgat_s": "LS-GAT-S", "lsgat_f": "LS-GAT-F",
    "lsgat_noego": "LS-GAT-NE",
    "mlp": "MLP (ego only, no graph)", "gat_ego": "GAT + ego", "lsgat_l_pm": "LS-GAT-L (param.-matched)",
    "lsgat_s_graph": "LS-GAT-S (graph candidates)", "lsgat_s_sim": "LS-GAT-S (similarity candidates)",
}

# variant -> (LS-GAT branch configuration, ego connection)
_LSGAT = {"lsgat": ("full", True), "lsgat_l": ("linear", True), "lsgat_s": ("sparse", True),
          "lsgat_f": ("fixed", True), "lsgat_noego": ("full", False), "lsgat_l_pm": ("linear", True),
          "lsgat_s_graph": ("sparse", True), "lsgat_s_sim": ("sparse", True)}


def count_params(model):
    return int(sum(p.numel() for p in model.parameters() if p.requires_grad))


def matched_hidden(in_dim, cfg_model):
    """Hidden size for the linear-only variant whose parameter count is closest to the full LS-GAT's."""
    target = count_params(LSGAT(in_dim, cfg_model["hidden"], cfg_model["layers"], cfg_model["dropout"],
                                heads=cfg_model["lsgat_heads"], variant="full"))
    best = min(range(cfg_model["hidden"], 4 * cfg_model["hidden"] + 1, 4),
               key=lambda h: abs(count_params(LSGAT(in_dim, h, cfg_model["layers"], 0.0, variant="linear")) - target))
    return best


def build_model(name: str, in_dim: int, cfg_model: dict):
    h, L, p = cfg_model["hidden"], cfg_model["layers"], cfg_model["dropout"]
    if name == "gcn":
        return GCN(in_dim, h, L, p)
    if name == "sage":
        return SAGE(in_dim, h, L, p)
    if name == "gat":
        return GAT(in_dim, h, L, p, heads=cfg_model["gat_heads"])
    if name == "gat_ego":
        return GATEgo(in_dim, h, L, p, heads=cfg_model["gat_heads"])
    if name == "mlp":
        return MLP(in_dim, h, L, p)
    if name in _LSGAT:
        variant, ego = _LSGAT[name]
        if name == "lsgat_l_pm":
            h = matched_hidden(in_dim, cfg_model)
        return LSGAT(in_dim, h, L, p, heads=cfg_model["lsgat_heads"], variant=variant, ego=ego)
    raise ValueError(name)


def uses_candidates(name: str) -> bool:
    return name in {"lsgat", "lsgat_s", "lsgat_f", "lsgat_noego", "lsgat_s_graph", "lsgat_s_sim"}


def candidate_mode(name: str) -> str:
    return {"lsgat_s_graph": "graph", "lsgat_s_sim": "sim"}.get(name, "hybrid")


def uses_graph(name: str) -> bool:
    return name in GNN_MODELS and name != "mlp"
