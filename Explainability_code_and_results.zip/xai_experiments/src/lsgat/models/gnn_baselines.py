"""GNN baselines. All share: input projection -> L message-passing layers -> the same MLP head."""
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, GCNConv, SAGEConv


class Head(nn.Module):
    def __init__(self, hidden, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 1))

    def forward(self, z):
        return self.net(z).squeeze(-1)


class _Base(nn.Module):
    def __init__(self, in_dim, hidden, dropout):
        super().__init__()
        self.inp = nn.Linear(in_dim, hidden)
        self.head = Head(hidden, dropout)
        self.dropout = dropout

    def encode_input(self, x):
        return F.dropout(F.relu(self.inp(x)), self.dropout, self.training)


class GCN(_Base):
    """Kipf & Welling (2017): H' = relu(D^-1/2 (A+I) D^-1/2 H W)."""

    def __init__(self, in_dim, hidden, layers, dropout):
        super().__init__(in_dim, hidden, dropout)
        self.convs = nn.ModuleList([GCNConv(hidden, hidden, cached=True) for _ in range(layers)])

    def forward(self, x, edge_index, cand_index=None):
        h = self.encode_input(x)
        for conv in self.convs:
            h = F.dropout(F.relu(conv(h, edge_index)), self.dropout, self.training)
        return self.head(h)


class SAGE(_Base):
    """Hamilton et al. (2017), mean aggregator."""

    def __init__(self, in_dim, hidden, layers, dropout):
        super().__init__(in_dim, hidden, dropout)
        self.convs = nn.ModuleList([SAGEConv(hidden, hidden, aggr="mean") for _ in range(layers)])

    def forward(self, x, edge_index, cand_index=None):
        h = self.encode_input(x)
        for conv in self.convs:
            h = F.dropout(F.relu(conv(h, edge_index)), self.dropout, self.training)
        return self.head(h)


class GAT(_Base):
    """Velickovic et al. (2018): full attention over every neighbour, `heads` heads (concatenated)."""

    def __init__(self, in_dim, hidden, layers, dropout, heads=8):
        super().__init__(in_dim, hidden, dropout)
        self.convs = nn.ModuleList(
            [GATConv(hidden, hidden // heads, heads=heads, dropout=dropout) for _ in range(layers)]
        )

    def forward(self, x, edge_index, cand_index=None):
        h = self.encode_input(x)
        for conv in self.convs:
            h = F.dropout(F.elu(conv(h, edge_index)), self.dropout, self.training)
        return self.head(h)


class MLP(_Base):
    """Ego-feature baseline: the same input encoder, per-layer ego transform and head as LS-GAT, but no graph."""

    def __init__(self, in_dim, hidden, layers, dropout):
        super().__init__(in_dim, hidden, dropout)
        self.layers = nn.ModuleList([nn.Linear(hidden, hidden) for _ in range(layers)])

    def forward(self, x, edge_index=None, cand_index=None):
        h = self.encode_input(x)
        for lin in self.layers:
            h = F.dropout(F.relu(lin(h)), self.dropout, self.training)
        return self.head(h)


class GATEgo(_Base):
    """GAT with the same ego connection as LS-GAT (full attention over all neighbours + separate self transform).
    Isolates 'sparse vs full attention' from the effect of the ego connection."""

    def __init__(self, in_dim, hidden, layers, dropout, heads=8):
        super().__init__(in_dim, hidden, dropout)
        self.convs = nn.ModuleList(
            [GATConv(hidden, hidden // heads, heads=heads, dropout=dropout) for _ in range(layers)])
        self.ego = nn.ModuleList([nn.Linear(hidden, hidden, bias=False) for _ in range(layers)])

    def forward(self, x, edge_index, cand_index=None):
        h = self.encode_input(x)
        for conv, ego in zip(self.convs, self.ego):
            h = F.dropout(F.elu(conv(h, edge_index) + ego(h)), self.dropout, self.training)
        return self.head(h)
