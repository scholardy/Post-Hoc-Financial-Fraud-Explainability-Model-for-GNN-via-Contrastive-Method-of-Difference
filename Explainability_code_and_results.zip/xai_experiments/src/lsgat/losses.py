"""Focal loss (paper Eq. 6). L2 regularisation (Eq. 7) is applied through the optimiser's weight decay."""
import torch
import torch.nn.functional as F


def focal_loss(logits, targets, alpha=0.75, gamma=2.0):
    targets = targets.float()
    ce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
    p = torch.sigmoid(logits)
    p_t = p * targets + (1 - p) * (1 - targets)
    alpha_t = alpha * targets + (1 - alpha) * (1 - targets)
    return (alpha_t * (1 - p_t).pow(gamma) * ce).mean()
