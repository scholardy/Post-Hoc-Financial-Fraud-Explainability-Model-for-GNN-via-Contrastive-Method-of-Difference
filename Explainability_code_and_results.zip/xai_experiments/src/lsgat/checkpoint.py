"""Model checkpoints (.pt) for every trained GNN, plus XGBoost models (.json).

A checkpoint is a plain dict saved with torch.save:
  format, model, dataset, stage, seed, job, protocol, k, candidate_mode, in_dim, model_cfg,
  feature_names, relation_names, threshold (validation-tuned), test_metrics, val_metrics, state_dict
`scripts/predict.py` reloads a checkpoint, rebuilds the graph and reproduces test_metrics.
"""
import os

import torch

FORMAT = "lsgat-checkpoint-v1"


def model_path(cfg, job, ext=".pt"):
    return os.path.join(cfg["paths"]["models_dir"], job["stage"], job["ds"], f"{job['id']}{ext}")


def save_gnn(cfg, job, model, res, g, k, cand_mode):
    path = model_path(cfg, job)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    ckpt = {
        "format": FORMAT,
        "model": job["model"], "dataset": job["ds"], "stage": job["stage"], "seed": job["seed"], "job": job,
        "protocol": g.get("protocol", "transductive"), "k": k, "candidate_mode": cand_mode,
        "in_dim": int(g["x"].size(1)), "model_cfg": dict(cfg["model"]), "train_cfg": dict(cfg["train"]),
        "feature_names": list(g["feature_names"]), "relation_names": list(g["relation_names"]),
        "threshold": res.get("val", {}).get("threshold"),
        "test_metrics": res.get("test"), "val_metrics": res.get("val"),
        "params": res.get("params"),
        "state_dict": {k_: v.detach().cpu() for k_, v in model.state_dict().items()},
    }
    tmp = path + ".tmp"
    torch.save(ckpt, tmp)
    os.replace(tmp, path)
    return path


def save_tabular(cfg, job, model):
    """XGBoost -> portable .json. LR / RF are not saved (RF forests are several GB)."""
    if job["model"] != "xgb":
        return None
    path = model_path(cfg, job, ".xgb.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    model.save_model(path)
    return path


def load(path, map_location="cpu"):
    ckpt = torch.load(path, map_location=map_location, weights_only=False)
    assert ckpt.get("format") == FORMAT, f"not an LS-GAT checkpoint: {path}"
    return ckpt
