"""Perturbations for the robustness study (paper Table 4)."""
import numpy as np
import torch

from .data.candidates import dedupe_edges


def feature_noise(x: torch.Tensor, sigma: float, seed: int) -> torch.Tensor:
    """Gaussian noise on standardised features of all nodes (applied at inference time)."""
    g = torch.Generator(device="cpu").manual_seed(seed)
    return x + sigma * torch.randn(x.shape, generator=g).to(x.device, x.dtype)


def edge_perturb(edge_index: np.ndarray, edge_type: np.ndarray, n: int, frac: float, seed: int, random_type: int,
                 directed: bool = False):
    """Remove `frac` of the links at random and add the same number of random links.
    directed=True (causal graphs): links are stored once, earlier -> later, and random links are added the same way."""
    rng = np.random.default_rng(seed)
    src, dst = edge_index
    one = np.ones(len(src), dtype=bool) if directed else src < dst
    us, ud, ut = src[one], dst[one], edge_type[one]
    m = len(us)
    n_change = int(round(frac * m))
    keep = np.ones(m, dtype=bool)
    keep[rng.choice(m, size=n_change, replace=False)] = False
    a = rng.integers(0, n, size=n_change)
    b = rng.integers(0, n, size=n_change)
    ok = a != b
    a, b = np.minimum(a[ok], b[ok]), np.maximum(a[ok], b[ok])  # earlier -> later
    s = np.concatenate([us[keep], a])
    d = np.concatenate([ud[keep], b])
    t = np.concatenate([ut[keep], np.full(len(a), random_type)]).astype(np.int64)
    if not directed:
        s, d, t = np.concatenate([s, d]), np.concatenate([d, s]), np.concatenate([t, t])
    s, d, t = dedupe_edges(s, d, t, n)
    return np.stack([s, d]), t


def label_noise(y: np.ndarray, train_idx: np.ndarray, frac: float, seed: int) -> np.ndarray:
    """Flip `frac` of the training frauds to legit and the same number of training legit to fraud
    (class prior unchanged). Validation and test labels stay clean."""
    rng = np.random.default_rng(seed)
    y = y.copy()
    pos = train_idx[y[train_idx] == 1]
    neg = train_idx[y[train_idx] == 0]
    k = int(round(frac * len(pos)))
    y[rng.choice(pos, size=k, replace=False)] = 0
    y[rng.choice(neg, size=k, replace=False)] = 1
    return y
