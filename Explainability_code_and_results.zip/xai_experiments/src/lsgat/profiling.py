"""Peak-memory measurement. GPU: torch.cuda.max_memory_allocated. CPU: sampled process RSS above baseline."""
import threading
import time

import torch


class PeakMemory:
    def __init__(self, device, interval=0.02):
        self.device = device
        self.interval = interval
        self.peak_mb = None

    def __enter__(self):
        if self.device.type == "cuda":
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats(self.device)
            self.base = torch.cuda.memory_allocated(self.device)
        else:
            import psutil
            self.proc = psutil.Process()
            self.base = self.proc.memory_info().rss
            self.max_rss = self.base
            self._stop = threading.Event()
            self._t = threading.Thread(target=self._sample, daemon=True)
            self._t.start()
        return self

    def _sample(self):
        while not self._stop.is_set():
            self.max_rss = max(self.max_rss, self.proc.memory_info().rss)
            time.sleep(self.interval)

    def __exit__(self, *exc):
        if self.device.type == "cuda":
            torch.cuda.synchronize()
            peak = torch.cuda.max_memory_allocated(self.device)
            self.peak_mb = peak / 2**20
            self.peak_above_base_mb = (peak - self.base) / 2**20
        else:
            self._stop.set()
            self._t.join()
            self.max_rss = max(self.max_rss, self.proc.memory_info().rss)
            self.peak_mb = self.max_rss / 2**20
            self.peak_above_base_mb = (self.max_rss - self.base) / 2**20
